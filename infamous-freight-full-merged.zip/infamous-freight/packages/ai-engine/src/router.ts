import { INTENTS } from "./intents";
import type { AiModelAdapter, RoutedIntent, IntentName } from "./types";
import { z } from "zod";

/**
 * We force the model to output strict JSON with this schema.
 * The API then validates args against the chosen intent schema (zod).
 */
const zModelOutput = z.object({
  intent: z.enum(["create_shipment","update_shipment_status","create_shipment_checkout","quote_profitability"]),
  confidence: z.number().min(0).max(1),
  args: z.unknown(),
  rationale: z.string().optional(),
});

export async function routeIntent(opts: {
  input: string;
  model: AiModelAdapter;
}): Promise<RoutedIntent> {
  const toolSpec = INTENTS.map(i => ({
    name: i.name,
    description: i.description,
    argsSchema: i.schema.toString(), // just for debugging; not relied on
  }));

  const prompt = [
    "You are an AI dispatcher for a freight platform.",
    "Your task: map the user input to ONE intent and provide args.",
    "Return ONLY strict JSON matching:",
    JSON.stringify({
      intent: "create_shipment | update_shipment_status | create_shipment_checkout | quote_profitability",
      confidence: 0.0,
      args: { "/* intent args */": "..." },
      rationale: "optional short reason"
    }, null, 2),
    "Rules:",
    "- If unsure, choose the closest intent with lower confidence and minimal args.",
    "- Never include extra keys outside the JSON object.",
    "",
    "Available intents:",
    JSON.stringify(toolSpec, null, 2),
    "",
    "User input:",
    opts.input
  ].join("\n");

  const raw = await opts.model(prompt);
  let parsed: any;
  try {
    parsed = JSON.parse(raw);
  } catch {
    // best effort fallback: try to extract first JSON object
    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) throw new Error("AI output was not valid JSON");
    parsed = JSON.parse(match[0]);
  }

  const out = zModelOutput.parse(parsed);
  return { intent: out.intent as IntentName, confidence: out.confidence, args: out.args, rationale: out.rationale };
}

export function validateArgs(intent: IntentName, args: unknown) {
  const def = INTENTS.find(i => i.name === intent);
  if (!def) throw new Error(`Unknown intent: ${intent}`);
  return def.schema.parse(args);
}

export function isRoleAllowed(intent: IntentName, role: string) {
  const def = INTENTS.find(i => i.name === intent);
  if (!def) return false;
  return def.rolesAllowed.includes(role as any);
}
