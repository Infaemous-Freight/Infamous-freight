import { z } from "zod";
import { zCreateShipment, zUpdateShipmentStatus, zCreateShipmentCheckout } from "@infamous/shared";
import type { IntentDefinition } from "./types";

export const INTENTS = [
  {
    name: "create_shipment",
    description: "Create/post a shipment with origin, destination, and priceUsdCents.",
    schema: zCreateShipment,
    rolesAllowed: ["OWNER","DISPATCHER","BROKER"],
  },
  {
    name: "update_shipment_status",
    description: "Update shipment status (PENDING/IN_TRANSIT/DELIVERED).",
    schema: zUpdateShipmentStatus,
    rolesAllowed: ["OWNER","DISPATCHER","DRIVER","BROKER"],
  },
  {
    name: "create_shipment_checkout",
    description: "Create a Stripe checkout session for a shipment (charges shipment price + platform fee).",
    schema: zCreateShipmentCheckout,
    rolesAllowed: ["OWNER","DISPATCHER","BROKER"],
  },
  {
    name: "quote_profitability",
    description: "Estimate profitability given rateUsdCents, miles, mpg, fuelPrice, tolls, otherCosts.",
    schema: z.object({
      rateUsdCents: z.number().int().nonnegative(),
      miles: z.number().finite().positive(),
      mpg: z.number().finite().positive().max(25),
      fuelPrice: z.number().finite().positive(),
      tolls: z.number().finite().nonnegative().default(0),
      otherCosts: z.number().finite().nonnegative().default(0),
    }),
    rolesAllowed: ["OWNER","DISPATCHER","BROKER","DRIVER"],
  },
] as const satisfies readonly IntentDefinition<any>[];
