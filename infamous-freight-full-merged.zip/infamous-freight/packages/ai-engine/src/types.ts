import type { z } from "zod";

export type IntentName =
  | "create_shipment"
  | "update_shipment_status"
  | "create_shipment_checkout"
  | "quote_profitability";

export type IntentDefinition<TSchema extends z.ZodTypeAny> = {
  name: IntentName;
  description: string;
  schema: TSchema;
  rolesAllowed: ("OWNER"|"DISPATCHER"|"DRIVER"|"BROKER")[];
};

export type RoutedIntent = {
  intent: IntentName;
  confidence: number; // 0..1
  args: unknown;
  rationale?: string;
};

export type AiModelAdapter = (prompt: string) => Promise<string>;
