export type Role = 'ADMIN' | 'DISPATCHER' | 'DRIVER';

export type ShipmentStatus = 'PENDING' | 'IN_TRANSIT' | 'DELIVERED';

export type JwtUser = {
  userId: string;
  orgId: string;
  role: Role;
  email: string;
};

export type CreateShipmentInput = {
  origin: string;
  destination: string;
  price: number;
};

export type UpdateShipmentStatusInput = {
  status: ShipmentStatus;
};
