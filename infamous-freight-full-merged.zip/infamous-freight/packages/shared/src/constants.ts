export const APP_NAME = "INFÆMOUS FREIGHT";
export const AI_MAX_TOKENS = 600;
