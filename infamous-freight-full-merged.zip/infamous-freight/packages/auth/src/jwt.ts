import jwt from "jsonwebtoken";

export type JwtClaims = {
  sub: string; // userId
  organizationId: string;
  role: "OWNER" | "DISPATCHER" | "DRIVER" | "BROKER";
};

export function signJwt(claims: JwtClaims, privateKeyPem: string, expiresIn = "1h") {
  return jwt.sign(claims, privateKeyPem, { algorithm: "RS256", expiresIn });
}

export function verifyJwt(token: string, publicKeyPem: string): JwtClaims {
  const decoded = jwt.verify(token, publicKeyPem, { algorithms: ["RS256"] });
  return decoded as JwtClaims;
}
