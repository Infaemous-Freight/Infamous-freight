import type { Request, Response, NextFunction } from "express";
import { verifyJwt, type JwtClaims } from "./jwt";

declare global {
  namespace Express {
    interface Request {
      user?: JwtClaims;
    }
  }
}

export function authMiddleware(opts: { publicKeyPem: string }) {
  return (req: Request, res: Response, next: NextFunction) => {
    const auth = req.headers.authorization || "";
    const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
    if (!token) return res.status(401).json({ error: "Missing bearer token" });
    try {
      req.user = verifyJwt(token, opts.publicKeyPem);
      next();
    } catch {
      return res.status(401).json({ error: "Invalid token" });
    }
  };
}

export function requireRole(roles: JwtClaims["role"][]) {
  return (req: Request, res: Response, next: NextFunction) => {
    const role = req.user?.role;
    if (!role) return res.status(401).json({ error: "Unauthenticated" });
    if (!roles.includes(role)) return res.status(403).json({ error: "Forbidden" });
    next();
  };
}
