# INFÆMOUS FREIGHT — Full Stack Monorepo (All-In)

This repo is an **end-to-end, enterprise-leaning** freight & logistics automation platform:
- **API**: Express 5 + Prisma + Postgres + Redis + Socket.io + RBAC + Audit Logs + Rate Limiting
- **Web**: Next.js (App Router) dashboard with auth + load board + realtime updates
- **Mobile**: Expo Router app (starter) for drivers/dispatchers
- **AI**: Command endpoint (OpenAI-compatible) for operational actions
- **Payments**: Stripe Checkout session creation
- **Infra**: Docker Compose + Kubernetes manifests + GitHub Actions CI + k6 smoke test

> This is a production-grade **foundation**: secure-by-default patterns, multi-tenant isolation, and clear extension points.

---

## Quick Start (Local)

### 1) Prereqs
- Node 20+
- pnpm 9+
- Docker Desktop (for Postgres + Redis)

### 2) Start infra
```bash
docker compose up -d db redis
```

### 3) Install deps
```bash
pnpm i
```

### 4) Configure env
Copy env templates:
```bash
cp apps/api/.env.example apps/api/.env
cp apps/web/.env.example apps/web/.env
```

### 5) Generate keys (JWT RS256)
```bash
pnpm --filter @infamous/api gen:keys
```

### 6) Migrate DB
```bash
pnpm db:migrate
```

### 7) Run everything
```bash
pnpm dev
```

- API: http://localhost:4000
- Web: http://localhost:3000

---

## Core Concepts

### Multi-tenant isolation
All data access for tenant-owned resources uses `organizationId` scoping from the validated JWT.

### RBAC
User role is embedded in token and re-checked against DB. Helper `requireRole()` is used per route.

### Audit Logs
Any sensitive mutating action writes an `AuditLog` record.

### Realtime tracking
Socket.io publishes shipment status events to the tenant room: `org:<orgId>`.

---

## Deploy

### Docker
```bash
docker compose up -d
```

### Kubernetes
Manifests are in `infra/k8s/*` (includes postgres/redis/api/web + basic ingress stubs).

---

## Load Testing (k6)
```bash
pnpm k6:local
```

---

## Modules
- `apps/api`: REST + realtime + auth + AI + payments
- `apps/web`: Dashboard, load board
- `apps/mobile`: Expo app starter
- `packages/shared`: Types + Zod schemas used across apps
