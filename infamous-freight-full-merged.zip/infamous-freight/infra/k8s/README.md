# Kubernetes Manifests (Starter)
This folder is intentionally minimal. Add:
- deployments/services for api + web
- ingress
- external secrets
- postgres/redis via managed services in production
