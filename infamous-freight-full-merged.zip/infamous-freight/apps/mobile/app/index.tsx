import { View, Text } from 'react-native';

export default function Home() {
  return (
    <View style={{ flex: 1, padding: 20, justifyContent: 'center' }}>
      <Text style={{ fontSize: 26, fontWeight: '700' }}>INFÆMOUS FREIGHT</Text>
      <Text style={{ marginTop: 8 }}>
        Mobile starter. Next: driver tracking, proof-of-delivery, and push notifications.
      </Text>
    </View>
  );
}
