'use client';

import { useState } from 'react';
import { api } from './lib/client';

export default function Home() {
  return (
    <div className="container">
      <div className="card">
        <h1 className="h1">INFÆMOUS FREIGHT</h1>
        <p className="small">AI-Powered Freight & Logistics Automation Platform</p>
        <div className="row" style={{ marginTop: 12 }}>
          <a className="btn" href="/auth">Sign in / Register</a>
          <a className="btn" href="/dashboard">Dashboard</a>
        </div>
      </div>
    </div>
  );
}
