import './globals.css';

export const metadata = {
  title: 'INFÆMOUS FREIGHT',
  description: 'AI-Powered Freight & Logistics Automation Platform',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
