'use client';

import { useEffect, useMemo, useState } from 'react';
import { api, API_URL } from '../lib/client';
import { io } from 'socket.io-client';

type Shipment = {
  id: string;
  origin: string;
  destination: string;
  status: string;
  price: number;
  createdAt: string;
};

export default function Dashboard() {
  const [shipments, setShipments] = useState<Shipment[]>([]);
  const [origin, setOrigin] = useState('Dallas, TX');
  const [destination, setDestination] = useState('Atlanta, GA');
  const [price, setPrice] = useState(1250);
  const [statusMsg, setStatusMsg] = useState<string>('');

  async function refresh() {
    const data = await api('/shipments');
    setShipments(data);
  }

  useEffect(() => {
    refresh().catch(() => {});

    const token = localStorage.getItem('token');
    const socket = io(API_URL, { auth: { token } });

    socket.on('connected', (x: any) => setStatusMsg(`Realtime connected for org ${x.orgId}`));
    socket.on('shipment:created', (s: Shipment) => {
      setShipments((prev) => [s, ...prev]);
    });
    socket.on('shipment:status', (s: Shipment) => {
      setShipments((prev) => prev.map((p) => (p.id === s.id ? s : p)));
    });

    return () => socket.disconnect();
  }, []);

  async function createShipment() {
    const s = await api('/shipments', {
      method: 'POST',
      body: JSON.stringify({ origin, destination, price }),
    });
    setShipments((prev) => [s, ...prev]);
  }

  async function updateStatus(id: string, status: string) {
    const s = await api(`/shipments/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
    setShipments((prev) => prev.map((p) => (p.id === id ? s : p)));
  }

  async function createCheckout() {
    const data = await api('/payments/checkout', {
      method: 'POST',
      body: JSON.stringify({ amountUsdCents: 5000, description: 'Infæmous Freight Load' }),
    });
    window.location.href = data.url;
  }

  async function aiCommand(cmd: string) {
    const data = await api('/ai/command', { method: 'POST', body: JSON.stringify({ command: cmd }) });
    alert(data.raw);
  }

  return (
    <div className="container">
      <div className="card">
        <h1 className="h1">Dispatch Dashboard</h1>
        <p className="small">{statusMsg || 'Realtime connecting…'}</p>
        <div className="row" style={{ marginTop: 12 }}>
          <button className="btn" onClick={() => (localStorage.removeItem('token'), (location.href = '/'))}>
            Sign out
          </button>
          <button className="btn" onClick={createCheckout}>Collect Payment</button>
          <button className="btn" onClick={() => aiCommand('Create a shipment from Chicago to Miami for $1800')}>AI Command</button>
        </div>
      </div>

      <div className="card" style={{ marginTop: 16 }}>
        <h2 className="h2">Create Shipment (Load Board)</h2>
        <div className="row">
          <input className="input" value={origin} onChange={(e) => setOrigin(e.target.value)} />
          <input className="input" value={destination} onChange={(e) => setDestination(e.target.value)} />
          <input className="input" type="number" value={price} onChange={(e) => setPrice(Number(e.target.value))} />
          <button className="btn" onClick={createShipment}>Post Load</button>
          <button className="btn" onClick={refresh}>Refresh</button>
        </div>
      </div>

      <div className="card" style={{ marginTop: 16 }}>
        <h2 className="h2">Shipments</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Route</th>
              <th>Status</th>
              <th>Price</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {shipments.map((s) => (
              <tr key={s.id}>
                <td>{s.origin} → {s.destination}</td>
                <td><span className="badge">{s.status}</span></td>
                <td>${(s.price / 100).toFixed(2)}</td>
                <td>
                  <div className="row">
                    <button className="btn" onClick={() => updateStatus(s.id, 'IN_TRANSIT')}>In Transit</button>
                    <button className="btn" onClick={() => updateStatus(s.id, 'DELIVERED')}>Delivered</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
