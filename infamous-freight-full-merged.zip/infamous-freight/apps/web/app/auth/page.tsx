'use client';

import { useState } from 'react';
import { api } from '../lib/client';

export default function AuthPage() {
  const [mode, setMode] = useState<'login' | 'register'>('register');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [org, setOrg] = useState('Infæmous Freight');
  const [err, setErr] = useState<string | null>(null);

  async function submit() {
    setErr(null);
    try {
      const body = mode === 'register' ? { email, password, organizationName: org } : { email, password };
      const data = await api(`/auth/${mode}`, { method: 'POST', body: JSON.stringify(body) });
      localStorage.setItem('token', data.token);
      location.href = '/dashboard';
    } catch (e: any) {
      setErr(e.message);
    }
  }

  return (
    <div className="container">
      <div className="card">
        <h1 className="h1">{mode === 'register' ? 'Create your tenant' : 'Sign in'}</h1>
        <div className="row">
          <button className="btn" onClick={() => setMode('register')}>Register</button>
          <button className="btn" onClick={() => setMode('login')}>Login</button>
        </div>

        <div style={{ marginTop: 16 }} className="row">
          <input className="input" placeholder="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input className="input" placeholder="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          {mode === 'register' && (
            <input className="input" placeholder="organization" value={org} onChange={(e) => setOrg(e.target.value)} />
          )}
          <button className="btn" onClick={submit}>Submit</button>
        </div>

        {err && <p className="small" style={{ color: '#ff8a8a' }}>{err}</p>}
        <p className="small" style={{ marginTop: 12 }}>
          Token stored in <code>localStorage</code> for dev convenience. For production, switch to HttpOnly cookies.
        </p>
      </div>
    </div>
  );
}
