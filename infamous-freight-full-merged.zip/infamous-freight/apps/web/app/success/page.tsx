export default function Success(){return <div className='container'><div className='card'><h1 className='h1'>Payment Success</h1></div></div>}
