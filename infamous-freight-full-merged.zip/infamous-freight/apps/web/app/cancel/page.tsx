export default function Cancel(){return <div className='container'><div className='card'><h1 className='h1'>Payment Cancelled</h1></div></div>}
