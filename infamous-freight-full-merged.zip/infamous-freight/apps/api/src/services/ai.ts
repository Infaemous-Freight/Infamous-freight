import OpenAI from 'openai';
import { env } from '../config';

const client = new OpenAI({ apiKey: env.OPENAI_API_KEY });

export async function runAiCommand(command: string) {
  const resp = await client.chat.completions.create({
    model: env.OPENAI_MODEL,
    messages: [
      {
        role: 'system',
        content:
          'You are Infæmous Freight Ops AI. Convert user commands into short actionable JSON: {action, params}. If unclear, return {action:"clarify", params:{question}}.',
      },
      { role: 'user', content: command },
    ],
    temperature: 0.2,
  });

  const text = resp.choices[0]?.message?.content ?? '';
  return { raw: text };
}
