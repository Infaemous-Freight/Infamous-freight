import OpenAI from "openai";
import { env } from "../config";
import { routeIntent, validateArgs, isRoleAllowed, type IntentName } from "@infamous/ai-engine";
import { prisma } from "../prisma";
import { auditLog } from "../audit";
import { createCheckoutSession } from "./stripe";

type AuthedUser = { userId: string; orgId: string; role: string };

function strictPrompt(input: string) {
  return [
    "You are Infæmous Freight Ops AI.",
    "Return ONLY valid JSON (no markdown).",
    "The JSON MUST match:",
    "{",
    '  "intent": "create_shipment | update_shipment_status | create_shipment_checkout | quote_profitability",',
    '  "confidence": 0.0,',
    '  "args": { "/* intent args */": "..." },',
    '  "rationale": "optional short reason"',
    "}",
    "",
    "Args requirements by intent:",
    "- create_shipment: {origin, destination, priceUsdCents}",
    "- update_shipment_status: {shipmentId, status}",
    "- create_shipment_checkout: {shipmentId}",
    "- quote_profitability: {rateUsdCents, miles, mpg, fuelPrice, tolls?, otherCosts?}",
    "",
    "Rules:",
    "- If details are missing, choose the closest intent with confidence <= 0.4 and best-effort args.",
    "- Output MUST be a single JSON object.",
    "",
    "User input:",
    input,
  ].join("\n");
}

function makeModelAdapter() {
  const key = env.OPENAI_API_KEY;
  const enabled = !!key && key.startsWith("sk-") && !key.includes("change_me") && !key.includes("change-me");

  if (!enabled) {
    return async (prompt: string) => {
      // Minimal heuristic fallback for local dev when no OpenAI key is configured.
      const lower = prompt.toLowerCase();
      if (lower.includes("checkout") || lower.includes("pay")) {
        return JSON.stringify({
          intent: "create_shipment_checkout",
          confidence: 0.5,
          args: { shipmentId: "00000000-0000-0000-0000-000000000000" },
          rationale: "Mock adapter: asked for checkout/payment.",
        });
      }
      if (lower.includes("delivered") || lower.includes("in transit") || lower.includes("status")) {
        return JSON.stringify({
          intent: "update_shipment_status",
          confidence: 0.5,
          args: { shipmentId: "00000000-0000-0000-0000-000000000000", status: "IN_TRANSIT" },
        });
      }
      return JSON.stringify({
        intent: "create_shipment",
        confidence: 0.5,
        args: { origin: "OKC", destination: "Dallas", priceUsdCents: 250000 },
      });
    };
  }

  const client = new OpenAI({ apiKey: key });
  return async (prompt: string) => {
    const resp = await client.chat.completions.create({
      model: env.OPENAI_MODEL,
      temperature: 0.1,
      messages: [
        { role: "system", content: "Return only valid JSON. No markdown." },
        { role: "user", content: prompt },
      ],
    });
    return resp.choices[0]?.message?.content ?? "";
  };
}

export async function handleAiCommand(opts: {
  input: string;
  user: AuthedUser;
  dryRun: boolean;
}) {
  const model = makeModelAdapter();

  const routed = await routeIntent({
    input: opts.input,
    model: async (prompt: string) => model(prompt),
  } as any);

  const intent = routed.intent as IntentName;

  if (!isRoleAllowed(intent, opts.user.role)) {
    await auditLog({
      organizationId: opts.user.orgId,
      actorUserId: opts.user.userId,
      action: "AI_INTENT_FORBIDDEN",
      entityType: "AI",
      metadata: { input: opts.input, intent },
    });
    return { ok: false as const, error: "FORBIDDEN_INTENT", intent };
  }

  const parsedArgs = validateArgs(intent, routed.args);

  if (opts.dryRun) {
    await auditLog({
      organizationId: opts.user.orgId,
      actorUserId: opts.user.userId,
      action: "AI_INTENT_DRY_RUN",
      entityType: "AI",
      metadata: { input: opts.input, intent, args: parsedArgs, confidence: routed.confidence },
    });
    return { ok: true as const, dryRun: true as const, intent, confidence: routed.confidence, args: parsedArgs };
  }

  const result = await executeIntent({ intent, args: parsedArgs, user: opts.user });

  await auditLog({
    organizationId: opts.user.orgId,
    actorUserId: opts.user.userId,
    action: "AI_INTENT_EXECUTED",
    entityType: "AI",
    entityId: result?.entityId,
    metadata: { input: opts.input, intent, args: parsedArgs, confidence: routed.confidence, result },
  });

  return { ok: true as const, dryRun: false as const, intent, confidence: routed.confidence, args: parsedArgs, result };
}

async function executeIntent(opts: {
  intent: IntentName;
  args: any;
  user: AuthedUser;
}) {
  const { intent, args, user } = opts;

  switch (intent) {
    case "create_shipment": {
      const shipment = await prisma.shipment.create({
        data: {
          origin: args.origin,
          destination: args.destination,
          price: args.priceUsdCents,
          organizationId: user.orgId,
        },
      });
      return { entityId: shipment.id, shipment };
    }

    case "update_shipment_status": {
      const shipment = await prisma.shipment.update({
        where: { id: args.shipmentId } as any,
        data: { status: args.status },
      });
      if (shipment.organizationId !== user.orgId) throw new Error("FORBIDDEN");
      return { entityId: shipment.id, shipment };
    }

    case "create_shipment_checkout": {
      const shipment = await prisma.shipment.findFirst({
        where: { id: args.shipmentId, organizationId: user.orgId },
      });
      if (!shipment) throw new Error("SHIPMENT_NOT_FOUND");

      const platformFeeBps = 200; // 2%
      const fee = Math.round((shipment.price * platformFeeBps) / 10000);
      const total = shipment.price + fee;

      const url = await createCheckoutSession({
        amountUsdCents: total,
        description: `Shipment ${shipment.id} (includes ${fee}c platform fee)`,
      });

      return { entityId: shipment.id, checkoutUrl: url, price: shipment.price, fee, total };
    }

    case "quote_profitability": {
      const fuelGallons = args.miles / args.mpg;
      const fuelCost = fuelGallons * args.fuelPrice;
      const totalCosts = fuelCost + (args.tolls ?? 0) + (args.otherCosts ?? 0);
      const rateUsd = args.rateUsdCents / 100;
      const profitUsd = rateUsd - totalCosts;
      const marginPct = rateUsd === 0 ? 0 : (profitUsd / rateUsd) * 100;

      return {
        entityId: undefined,
        quote: { rateUsd, fuelCost, totalCosts, profitUsd, marginPct },
      };
    }

    default:
      throw new Error("UNKNOWN_INTENT");
  }
}
