import Stripe from 'stripe';
import { env } from '../config';

export const stripe = new Stripe(env.STRIPE_SECRET_KEY, { apiVersion: '2023-10-16' });

export async function createCheckoutSession(params: { amountUsdCents: number; description: string }) {
  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    payment_method_types: ['card'],
    line_items: [
      {
        price_data: {
          currency: 'usd',
          product_data: { name: params.description },
          unit_amount: params.amountUsdCents,
        },
        quantity: 1,
      },
    ],
    success_url: env.STRIPE_SUCCESS_URL,
    cancel_url: env.STRIPE_CANCEL_URL,
  });

  return session.url;
}
