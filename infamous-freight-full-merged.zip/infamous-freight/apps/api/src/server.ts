import http from 'node:http';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { env } from './config';
import { httpLogger, logger } from './logger';
import { globalRateLimit } from './security/rate-limit';
import { healthRouter } from './routes/health';
import { authRouter } from './routes/auth';
import { aiRouter } from './routes/ai';
import { paymentsRouter } from './routes/payments';
import { shipmentsRouter } from './routes/shipments';
import { createSocketServer } from './realtime/socket';

const app = express();
app.use(httpLogger);
app.use(cors({ origin: '*', credentials: false }));
app.use(helmet());
app.use(express.json({ limit: '1mb' }));
app.use(globalRateLimit);

app.get('/', (_req, res) => res.json({ ok: true, name: 'INFÆMOUS FREIGHT API' }));
app.use('/health', healthRouter);
app.use('/auth', authRouter);
app.use('/ai', aiRouter);
app.use('/payments', paymentsRouter);

const server = http.createServer(app);
const io = createSocketServer(server);

app.use('/shipments', shipmentsRouter(io));

server.listen(env.PORT, () => {
  logger.info({ port: env.PORT }, 'API listening');
});
