import { Router } from 'express';
import { authMiddleware, type AuthedRequest } from '../security/auth-middleware';
import { aiCommandSchema } from '@infamous/shared';
import { handleAiCommand } from '../services/ai-intents';

export const aiRouter = Router();

/**
 * POST /ai/command
 * Body: { command: string, dryRun?: boolean }
 */
aiRouter.post('/command', authMiddleware, async (req: AuthedRequest, res) => {
  const parsed = aiCommandSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'INVALID_INPUT', details: parsed.error.flatten() });

  const out = await handleAiCommand({
    input: parsed.data.command,
    dryRun: parsed.data.dryRun ?? false,
    user: {
      userId: req.user!.userId,
      orgId: req.user!.orgId,
      role: req.user!.role,
    },
  });

  return res.json(out);
});
