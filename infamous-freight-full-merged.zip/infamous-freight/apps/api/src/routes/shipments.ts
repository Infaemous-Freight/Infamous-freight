import { Router } from 'express';
import { prisma } from '../prisma';
import { authMiddleware, type AuthedRequest } from '../security/auth-middleware';
import { requireRole } from '../security/rbac';
import { createShipmentSchema, updateShipmentStatusSchema } from '@infamous/shared';
import { auditLog } from '../audit';

export function shipmentsRouter(io: any) {
  const r = Router();

  r.get('/', authMiddleware, async (req: AuthedRequest, res) => {
    const shipments = await prisma.shipment.findMany({
      where: { organizationId: req.user!.orgId },
      orderBy: { createdAt: 'desc' },
    });
    return res.json(shipments);
  });

  r.post('/', authMiddleware, requireRole(['ADMIN', 'DISPATCHER']), async (req: AuthedRequest, res) => {
    const parsed = createShipmentSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'INVALID_INPUT', details: parsed.error.flatten() });

    const shipment = await prisma.shipment.create({
      data: {
        origin: parsed.data.origin,
        destination: parsed.data.destination,
        price: Math.round(parsed.data.price * 100),
        organizationId: req.user!.orgId,
      },
    });

    await auditLog({
      organizationId: req.user!.orgId,
      actorUserId: req.user!.userId,
      action: 'CREATE_SHIPMENT',
      entityType: 'Shipment',
      entityId: shipment.id,
      metadata: { origin: shipment.origin, destination: shipment.destination, price: shipment.price },
    });

    io.to(`org:${req.user!.orgId}`).emit('shipment:created', shipment);
    return res.status(201).json(shipment);
  });

  r.patch('/:id/status', authMiddleware, requireRole(['ADMIN', 'DISPATCHER', 'DRIVER']), async (req: AuthedRequest, res) => {
    const parsed = updateShipmentStatusSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'INVALID_INPUT', details: parsed.error.flatten() });

    const shipment = await prisma.shipment.findFirst({
      where: { id: req.params.id, organizationId: req.user!.orgId },
    });
    if (!shipment) return res.status(404).json({ error: 'NOT_FOUND' });

    const updated = await prisma.shipment.update({
      where: { id: shipment.id },
      data: { status: parsed.data.status },
    });

    await auditLog({
      organizationId: req.user!.orgId,
      actorUserId: req.user!.userId,
      action: 'UPDATE_SHIPMENT_STATUS',
      entityType: 'Shipment',
      entityId: updated.id,
      metadata: { status: updated.status },
    });

    io.to(`org:${req.user!.orgId}`).emit('shipment:status', updated);
    return res.json(updated);
  });

  return r;
}
