import { Router } from 'express';
import bcrypt from 'bcrypt';
import { prisma } from '../prisma';
import { signToken } from '../security/jwt';
import { registerSchema, loginSchema } from '@infamous/shared';

export const authRouter = Router();

authRouter.post('/register', async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'INVALID_INPUT', details: parsed.error.flatten() });

  const { email, password, organizationName } = parsed.data;

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) return res.status(409).json({ error: 'EMAIL_IN_USE' });

  const org = await prisma.organization.create({ data: { name: organizationName } });
  const passwordHash = await bcrypt.hash(password, 12);

  const user = await prisma.user.create({
    data: { email, passwordHash, role: 'ADMIN', organizationId: org.id },
  });

  const token = signToken({ userId: user.id, orgId: org.id, role: user.role as any, email: user.email });
  return res.json({ token });
});

authRouter.post('/login', async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'INVALID_INPUT', details: parsed.error.flatten() });

  const { email, password } = parsed.data;
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) return res.status(401).json({ error: 'INVALID_CREDENTIALS' });

  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error: 'INVALID_CREDENTIALS' });

  const token = signToken({
    userId: user.id,
    orgId: user.organizationId,
    role: user.role as any,
    email: user.email,
  });

  return res.json({ token });
});
