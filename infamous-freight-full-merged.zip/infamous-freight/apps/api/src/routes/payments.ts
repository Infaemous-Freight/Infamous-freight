import { Router } from 'express';
import { authMiddleware, type AuthedRequest } from '../security/auth-middleware';
import { stripeCheckoutSchema } from '@infamous/shared';
import { createCheckoutSession } from '../services/stripe';
import { auditLog } from '../audit';

export const paymentsRouter = Router();

paymentsRouter.post('/checkout', authMiddleware, async (req: AuthedRequest, res) => {
  const parsed = stripeCheckoutSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'INVALID_INPUT', details: parsed.error.flatten() });

  const url = await createCheckoutSession(parsed.data);

  await auditLog({
    organizationId: req.user!.orgId,
    actorUserId: req.user!.userId,
    action: 'CREATE_CHECKOUT_SESSION',
    entityType: 'Stripe',
    metadata: parsed.data,
  });

  return res.json({ url });
});
