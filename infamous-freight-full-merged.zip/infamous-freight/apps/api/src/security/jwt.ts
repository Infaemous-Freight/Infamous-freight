import fs from 'node:fs';
import jwt from 'jsonwebtoken';
import { env } from '../config';
import type { JwtUser } from '@infamous/shared';

function readKey(path: string) {
  return fs.readFileSync(path, 'utf-8');
}

const privateKey = () => readKey(env.JWT_PRIVATE_KEY_PATH);
const publicKey = () => readKey(env.JWT_PUBLIC_KEY_PATH);

export function signToken(user: JwtUser) {
  return jwt.sign(user, privateKey(), {
    algorithm: 'RS256',
    issuer: env.JWT_ISSUER,
    audience: env.JWT_AUDIENCE,
    expiresIn: env.JWT_EXPIRES_IN,
  });
}

export function verifyToken(token: string) {
  return jwt.verify(token, publicKey(), {
    algorithms: ['RS256'],
    issuer: env.JWT_ISSUER,
    audience: env.JWT_AUDIENCE,
  }) as JwtUser;
}
