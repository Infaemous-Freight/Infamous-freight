import type { Response, NextFunction } from 'express';
import type { Role } from '@infamous/shared';
import type { AuthedRequest } from './auth-middleware';

export function requireRole(roles: Role[]) {
  return (req: AuthedRequest, res: Response, next: NextFunction) => {
    const role = req.user?.role;
    if (!role) return res.status(401).json({ error: 'UNAUTHORIZED' });
    if (!roles.includes(role)) return res.status(403).json({ error: 'FORBIDDEN' });
    return next();
  };
}
