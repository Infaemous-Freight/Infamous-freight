import type { Request, Response, NextFunction } from 'express';
import { verifyToken } from './jwt';

export type AuthedRequest = Request & { user?: ReturnType<typeof verifyToken> };

export function authMiddleware(req: AuthedRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  const token = header?.startsWith('Bearer ') ? header.slice('Bearer '.length) : undefined;
  if (!token) return res.status(401).json({ error: 'UNAUTHORIZED' });

  try {
    req.user = verifyToken(token);
    return next();
  } catch {
    return res.status(401).json({ error: 'INVALID_TOKEN' });
  }
}
