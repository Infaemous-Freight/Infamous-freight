const fs = require('fs');
const path = require('path');
const { generateKeyPairSync } = require('crypto');

const dir = path.join(__dirname, '..', 'keys');
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

const { privateKey, publicKey } = generateKeyPairSync('rsa', {
  modulusLength: 2048,
  publicKeyEncoding: { type: 'spki', format: 'pem' },
  privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
});

fs.writeFileSync(path.join(dir, 'private.pem'), privateKey);
fs.writeFileSync(path.join(dir, 'public.pem'), publicKey);
console.log('✅ JWT keys written to apps/api/keys');
