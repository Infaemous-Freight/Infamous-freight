import { PrismaClient } from "@prisma/client";
import { signJwt } from "@infamous/auth";

const prisma = new PrismaClient();

async function main() {
  const org = await prisma.organization.upsert({
    where: { name: "Infamous Demo Org" },
    update: {},
    create: { name: "Infamous Demo Org" },
  });

  const user = await prisma.user.upsert({
    where: { email: "owner@infamous.local" },
    update: {},
    create: {
      email: "owner@infamous.local",
      passwordHash: "dev-only",
      role: "OWNER",
      organizationId: org.id,
    },
  });

  const priv = process.env.JWT_PRIVATE_KEY_PEM || "";
  const token = priv ? signJwt({ sub: user.id, organizationId: org.id, role: "OWNER" }, priv, "7d") : "SET_JWT_PRIVATE_KEY_PEM";
  console.log("Seeded org/user.");
  console.log("Dev token (Bearer):", token);
}

main().finally(async () => prisma.$disconnect());
