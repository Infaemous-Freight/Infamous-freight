# Infæmous Freight

<p align="center">
  <strong>AI-Native Freight Intelligence Platform</strong><br>
  Transforming the $900B+ global logistics industry
</p>

<p align="center">
  <a href="https://infamousfreight.com">
    <img src="https://img.shields.io/badge/Live%20Site-infamousfreight.com-blue" alt="Live Site">
  </a>
  <a href="https://infamous-freight-api.fly.dev/api/health">
    <img src="https://img.shields.io/badge/API%20Status-Online-brightgreen" alt="API Status">
  </a>
  <a href="https://github.com/MrMiless44/Infamous-freight/actions">
    <img src="https://github.com/MrMiless44/Infamous-freight/workflows/CI/CD%20Pipeline/badge.svg" alt="CI/CD">
  </a>
  <img src="https://img.shields.io/badge/Coverage-86%25-brightgreen" alt="Coverage">
  <img src="https://img.shields.io/badge/Tests-827%20passing-brightgreen" alt="Tests">
  <img src="https://img.shields.io/badge/License-Proprietary-red" alt="License">
</p>

---

## 🚀 Deployment Status

| Component | Platform | Status | URL |
|-----------|----------|--------|-----|
| **Web (Primary)** | Netlify | ✅ Online | [infamousfreight.com](https://infamousfreight.com) |
| **Web (Preview)** | Vercel | ✅ Online | [Preview](https://infamous-freight-enterprises.vercel.app) |
| **API** | Fly.io | ✅ Online | [infamous-freight-api.fly.dev](https://infamous-freight-api.fly.dev) |
| **Database** | Railway | ✅ Online | PostgreSQL 16 |
| **Backend Services** | Supabase | ✅ Online | Edge Functions |
| **Mobile** | Expo EAS | ✅ Online | OTA Updates Enabled |

**Overall Status: 100% Production Ready** 🎉

---

## 📋 Table of Contents

- [Quick Start](#quick-start)
- [Features](#features)
- [Architecture](#architecture)
- [Deployment](#deployment)
- [Documentation](#documentation)
- [Contributing](#contributing)
- [License](#license)

---

## 🏃 Quick Start

### Prerequisites

- Node.js 20+
- PostgreSQL 14+ (or Docker)
- pnpm 9.15.0+
- Git

### One-Command Setup

```bash
# Clone the repository
git clone https://github.com/MrMiless44/Infamous-freight.git
cd Infamous-freight

# Run automated setup
./setup.sh
```

### Manual Setup

```bash
# Install pnpm
curl -fsSL https://get.pnpm.io/install.sh | sh -
source ~/.bashrc

# Install dependencies
pnpm install

# Build shared package
pnpm --filter @infamous-freight/shared build

# Configure environment
cp .env.example .env.local
# Edit .env.local with your values

# Initialize database
cd apps/api
pnpm prisma:migrate:dev
pnpm prisma:seed

# Start development
pnpm dev  # Starts all services
```

### Development URLs

- **Web**: http://localhost:3000
- **API**: http://localhost:3001
- **API Docs**: http://localhost:3001/api/docs
- **Prisma Studio**: http://localhost:5555

---

## ✨ Features

### Core Capabilities

| Feature | Description |
|---------|-------------|
| **AI-Powered Dispatch** | Smart load scoring by profit/mile, route optimization |
| **Unified Freight OS** | Dispatch, finance, tracking, compliance—all integrated |
| **Financial Intelligence** | Automated invoice audits, real-time P&L per shipment |
| **Genesis AI Avatars** | Voice-driven fleet operations, 12+ languages |
| **Mobile-First** | iOS/Android native apps with offline mode |
| **Enterprise-Grade** | SOC 2 ready, GDPR/HIPAA compliant, 55+ countries |

### Platform Modules

```
📦 Shipment Management
   ├── GPS tracking & multi-modal support
   ├── Automated status updates
   ├── POD capture & digital BOL
   └── ETA prediction

🚛 Fleet Management
   ├── Driver analytics & vehicle tracking
   ├── Maintenance scheduling
   ├── HOS compliance
   └── Asset utilization

🧠 AI Decision Making
   ├── Load scoring algorithms
   ├── Dispatch automation
   ├── Risk prediction
   └── Capacity optimization

💰 Financial Engine
   ├── Invoice audits
   ├── Profitability tracking
   ├── Automated GL entry
   └── Factoring services
```

---

## 🏗️ Architecture

### Tech Stack

| Layer | Technologies |
|-------|-------------|
| **Frontend** | Next.js 14, React Native/Expo, TypeScript, Tailwind CSS |
| **Backend** | Express.js, Node.js 24, PostgreSQL 16, Redis 7 |
| **AI/ML** | OpenAI, Anthropic, Custom optimization engines |
| **Infrastructure** | Docker, Fly.io, Netlify, Vercel, Supabase |
| **Real-time** | Socket.io for live GPS tracking |

### Monorepo Structure

```
Infamous-freight/
├── apps/
│   ├── api/              # Express.js backend (Fly.io)
│   ├── web/              # Next.js 14 frontend (Netlify/Vercel)
│   └── mobile/           # React Native / Expo (iOS/Android)
├── packages/
│   └── shared/           # Shared TypeScript types & utilities
├── e2e/                  # Playwright E2E tests
├── scripts/              # Deployment & utility scripts
├── docs/                 # Documentation
└── netlify/              # Netlify functions & config
```

### Production Metrics

- ⚡ **API Response**: P95 < 1s
- 🟢 **Uptime SLA**: 99.9%
- 🧪 **Test Coverage**: 86%+
- ✅ **Unit Tests**: 827+ passing
- 🔒 **Security**: Zero vulnerabilities
- 🌍 **Regions**: Multi-region failover active

---

## 🚀 Deployment

### Quick Deploy (10 minutes)

```bash
# Validate secrets
./scripts/validate-secrets.sh

# Deploy all platforms
./scripts/deploy-to-world-100.sh
```

### Deployment Features

- ✅ Parallel deployment to 4 platforms
- ✅ Automated health checks
- ✅ Smoke tests with response time measurement
- ✅ Real-time deployment summaries
- ✅ Auto-rollback on failed health checks
- ✅ Slack/Discord notifications

### Platform-Specific Deployment

```bash
# Deploy API only
flyctl deploy --config apps/api/fly.toml

# Deploy Web to Netlify
netlify deploy --prod --dir=apps/web/.next

# Deploy Web to Vercel
vercel --prod

# Deploy via GitHub Actions
gh workflow run deploy-all.yml --ref main
```

---

## 📚 Documentation

| Document | Description |
|----------|-------------|
| [API Reference](docs/API_REFERENCE.md) | API endpoints, authentication, examples |
| [Deployment Guide](docs/DEPLOYMENT.md) | Complete deployment instructions |
| [Docker Guide](docs/DOCKER_COMPLETE.md) | Docker setup & configuration |
| [E2E Testing](docs/E2E_TESTING.md) | Playwright test setup |
| [Security](docs/SECURITY.md) | Security policies & best practices |
| [Contributing](CONTRIBUTING.md) | Contribution guidelines |

### Quick Links

- 🌐 [Live Demo](https://infamousfreight.com/demo)
- 📊 [Status Page](https://status.infamousfreight.com)
- 🐛 [Issue Tracker](https://github.com/MrMiless44/Infamous-freight/issues)
- 💬 [Discussions](https://github.com/MrMiless44/Infamous-freight/discussions)

---

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

```bash
# Create a feature branch
git checkout -b feature/your-feature

# Make your changes
# ...

# Run tests
pnpm test
pnpm e2e

# Commit and push
git commit -am 'Add feature'
git push origin feature/your-feature

# Open a pull request
```

---

## 📄 License

This project is proprietary software. All rights reserved.

Copyright © 2025 Infæmous Freight. All Rights Reserved.

See [LICENSE](LICENSE) and [LEGAL_NOTICE.md](LEGAL_NOTICE.md) for details.

---

## 🏢 Company

**Infæmous Freight**  
Founder: Santorio Djuan Miles  
Jurisdiction: Oklahoma, USA  

---

<p align="center">
  <sub>Built with ❤️ for the $900B+ logistics industry</sub>
</p>
