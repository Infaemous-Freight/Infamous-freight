# Infamous Freight Branding Guidelines

## Official Brand Standards

---

## Brand Name

### ✅ Correct Usage

**Primary Name**: `Infæmous Freight`

- Use the æ ligature (ash) character
- Capital "I" in Infæmous
- Capital "F" in Freight
- No spaces around the æ

### ❌ Incorrect Usage

| Incorrect | Reason |
|-----------|--------|
| `Infamous Freight` | Missing æ ligature |
| `infamous freight` | All lowercase |
| `INFAMOUS FREIGHT` | All uppercase |
| `Infamous-Freight` | Hyphenated |
| `InfamousFreight` | No space |
| `Infamous Freight Enterprises` | Old company name (deprecated) |
| `Infamous Freight Enterprises LLC` | Old legal name (deprecated) |

---

## Brand Assets

### Logo

**Primary Logo**: Full wordmark with æ ligature

```
┌─────────────────────────────────────┐
│                                     │
│   [Logo Icon]  Infæmous Freight     │
│                                     │
└─────────────────────────────────────┘
```

**Icon Only**: Truck/road symbol (for favicon, app icon)

**Logo Colors**:
- Primary Blue: `#2563EB` (RGB: 37, 99, 235)
- Dark Blue: `#1E40AF` (RGB: 30, 64, 175)
- Accent Purple: `#7C3AED` (RGB: 124, 58, 237)

### Typography

**Primary Font**: Inter
- Headlines: Inter Bold (700)
- Body: Inter Regular (400)
- UI Elements: Inter Medium (500)

**Monospace Font**: JetBrains Mono (for code, data)

### Color Palette

| Color | Hex | RGB | Usage |
|-------|-----|-----|-------|
| **Primary Blue** | `#2563EB` | 37, 99, 235 | Buttons, links, primary actions |
| **Dark Blue** | `#1E40AF` | 30, 64, 175 | Headers, emphasis |
| **Accent Purple** | `#7C3AED` | 124, 58, 237 | AI features, highlights |
| **Success Green** | `#10B981` | 16, 185, 129 | Success states, positive metrics |
| **Warning Yellow** | `#F59E0B` | 245, 158, 11 | Warnings, pending states |
| **Error Red** | `#EF4444` | 239, 68, 68 | Errors, critical alerts |
| **Neutral Gray** | `#6B7280` | 107, 114, 128 | Secondary text, borders |
| **Dark Gray** | `#1F2937` | 31, 41, 55 | Primary text |
| **Light Gray** | `#F3F4F6` | 243, 244, 246 | Backgrounds |
| **White** | `#FFFFFF` | 255, 255, 255 | Backgrounds, cards |

---

## Brand Voice

### Tone

- **Professional but approachable**: Expert without being stuffy
- **Confident**: We know logistics, and it shows
- **Innovative**: AI-first, future-focused
- **Empathetic**: We understand the challenges of trucking

### Messaging Pillars

1. **Profitability First**: Everything we do helps carriers earn more
2. **AI-Powered**: Smart automation that actually works
3. **Driver-Centric**: Built for the people who move America
4. **Enterprise-Grade**: Security and reliability you can trust

### Taglines

**Primary**: "The AI-Native Freight Intelligence Platform"

**Secondary**:
- "Maximize Profitability. Minimize Complexity."
- "The Operating System for Freight"
- "73% Faster Than Legacy TMS"

### Words to Use

✅ **Preferred**:
- AI-powered
- Intelligent
- Optimized
- Streamlined
- Profitable
- Unified
- Real-time
- Automated
- Driver-friendly

❌ **Avoid**:
- Disruptive (overused)
- Revolutionary (hyperbolic)
- Cheap (implies low quality)
- Simple (implies basic)
- Magic (implies not real)

---

## Application Guidelines

### Website

**Header**:
- Logo: Left-aligned
- Navigation: Center or right
- CTA Button: "Start Free Trial" (Primary Blue)

**Footer**:
- Full logo
- Copyright: `© 2025 Infæmous Freight. All Rights Reserved.`
- Links: Product, Company, Resources, Legal

### Marketing Materials

**Business Cards**:
```
┌─────────────────────────────────────┐
│                                     │
│   [Logo]  Infæmous Freight          │
│                                     │
│   Santorio Djuan Miles              │
│   Founder & CEO                     │
│                                     │
│   📧 santorio@infamousfreight.com   │
│   🌐 infamousfreight.com            │
│                                     │
└─────────────────────────────────────┘
```

**Email Signature**:
```
--
Santorio Djuan Miles
Founder & CEO, Infæmous Freight

🌐 https://infamousfreight.com
📧 santorio@infamousfreight.com
📱 +1 (555) 123-4567

[LinkedIn] [Twitter] [GitHub]
```

### Social Media

**Twitter/X**:
- Handle: `@InfamousFreight`
- Bio: "AI-Native Freight Intelligence Platform. Helping carriers maximize profitability through smart dispatch, automated billing, and real-time intelligence."

**LinkedIn**:
- Company: "Infæmous Freight"
- Tagline: "The Operating System for Freight"

**GitHub**:
- Organization: `Infamous-Freight`
- Repository naming: `kebab-case` (e.g., `infamous-freight-api`)

---

## Code & Technical

### Package Names

```json
{
  "name": "@infamous-freight/shared",
  "name": "@infamous-freight/api",
  "name": "@infamous-freight/web",
  "name": "@infamous-freight/mobile"
}
```

### Environment Variables

```bash
# Correct
INFAMOUS_FREIGHT_API_URL=https://api.infamousfreight.com
INFAMOUS_FREIGHT_API_KEY=xxx

# Incorrect (old naming)
INFAMOUS_FREIGHT_ENTERPRISES_API_URL=xxx
IFE_API_URL=xxx
```

### Database Names

```sql
-- Correct
database_name: infamous_freight_production
database_name: infamous_freight_staging

-- Incorrect
database_name: infamous_freight_enterprises
database_name: ife_production
```

### Docker Images

```bash
# Correct
ghcr.io/infamous-freight/api:latest
ghcr.io/infamous-freight/web:latest

# Incorrect
ghcr.io/infamous-freight-enterprises/api:latest
ghcr.io/ife/api:latest
```

---

## File Naming Conventions

### Repository Files

```
# Correct
README.md
CONTRIBUTING.md
LICENSE
CHANGELOG.md

# Incorrect
readme.md
Readme.md
README.markdown
```

### Documentation

```
docs/
  API_REFERENCE.md
  DEPLOYMENT.md
  SECURITY.md
  BRANDING_GUIDELINES.md
  
# Incorrect
docs/
  api-reference.md
  api_reference.md
  ApiReference.md
```

---

## Domain Names

### Primary Domains

| Domain | Purpose | Status |
|--------|---------|--------|
| `infamousfreight.com` | Primary website | ✅ Active |
| `infamousfreight.io` | API & developer docs | ✅ Active |
| `infamousfreight.app` | Mobile app deep links | ✅ Active |

### Deprecated Domains

| Domain | Status | Action |
|--------|--------|--------|
| `infamousfreightenterprises.com` | ❌ Deprecated | Redirect to primary |
| `ife-logistics.com` | ❌ Deprecated | Let expire |

---

## Trademark Usage

### ™ and ® Symbols

- Use ™ for unregistered trademarks
- Use ® only after registration is complete

**Current Status**:
- `Infæmous Freight™` - Trademark pending
- Logo™ - Trademark pending

### Third-Party Usage

For partners and integrators:

```
"Infæmous Freight" and the Infæmous Freight logo are trademarks 
of Infæmous Freight, Inc. Used with permission.
```

---

## Brand Checklist

### For New Content

- [ ] Use "Infæmous Freight" with æ ligature
- [ ] Check logo colors match brand palette
- [ ] Verify typography uses Inter
- [ ] Include proper trademark notice
- [ ] Review tone matches brand voice
- [ ] Check for deprecated terms

### For Code Changes

- [ ] Package names use `@infamous-freight` scope
- [ ] Environment variables use `INFAMOUS_FREIGHT_` prefix
- [ ] Database names use `infamous_freight_` prefix
- [ ] Docker images use `infamous-freight` namespace
- [ ] No references to old company name

### For Domain/DNS Changes

- [ ] Primary domain: `infamousfreight.com`
- [ ] API domain: `api.infamousfreight.com`
- [ ] Deprecated domains redirect to primary
- [ ] SSL certificates cover all active domains

---

## Enforcement

### Violations

If you find incorrect brand usage:

1. **Internal**: Notify marketing@infamousfreight.com
2. **External**: Contact legal@infamousfreight.com
3. **Urgent**: Escalate to CEO

### Review Process

All public-facing content must be reviewed by:
1. Content creator
2. Marketing team
3. Legal (for trademark-sensitive content)

---

## Resources

### Downloadable Assets

- [Logo Pack (SVG, PNG, PDF)](https://brand.infamousfreight.com/logo-pack.zip)
- [Color Palette (ASE, CLR)](https://brand.infamousfreight.com/colors.zip)
- [Typography (Inter, JetBrains Mono)](https://brand.infamousfreight.com/fonts.zip)
- [Presentation Templates](https://brand.infamousfreight.com/templates.zip)

### Brand Portal

**URL**: https://brand.infamousfreight.com

### Contact

- **Brand Questions**: marketing@infamousfreight.com
- **Legal/Trademark**: legal@infamousfreight.com
- **Press Inquiries**: press@infamousfreight.com

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 2.0.0 | 2025-02-24 | Rebranded to Infæmous Freight with æ ligature |
| 1.0.0 | 2024-12-01 | Initial brand guidelines for Infamous Freight Enterprises |

---

*© 2025 Infæmous Freight. All Rights Reserved.*  
*This document is confidential and proprietary.*
