# Security Advisory: Deploy Key Rotation

## ⚠️ URGENT: Deploy Key Exposed

**Date**: February 24, 2025  
**Severity**: HIGH  
**Status**: Action Required

---

## Summary

A deploy key was exposed in the PDF documentation file. This key must be rotated immediately to prevent unauthorized access to the repository.

---

## Affected Key

```
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAACAQC3aLpMerPLyF5wIIKDaRIW+qIlPH/bDlmwiCruY0DZOoHODup2eWvjuacoDY61LqCtyxUyetaQESJ5xqvZIIY7+ye6VG8RhsBVwGp9swX8IVdWmfrdRd9Di5Dwq/WXwD0E3qDx2nPvDzMLyMR/0OaXJmGZ49ggavrGhr4wV/tiGmLG2HKi4AZLDFZMzgCSOK+I4Guqwi0083P9B+bTDXgEiPotsJHNnPezXquoz5KViS1/S1jMqEMA62XpoyHzHLvI/5kcIiCOXJEPlYY9/XotGdQ+RyNJ/RKIHOJHawlZ3ImGqnE731QJTkebKJa+spHO8f3laCE5XKg7kGFpL0E7KN2ReS0hpqr83CyhNq8jnplpSLQeS1hfU5MlU0qsHQi8SQP/EhBoe1fFZlcoA4fuYtewL2NbvsZNqj7p0eU4zFBkMuytZ0+zZlKFJhd9bH7A6cXb2Hj0+oQFLXMNar9rxrfZg30YjyAw0ybRL0K9lemb+M7WqPwnyHia+PvKWoVhzpj8vGq5E3N3dvmW7m0lMRH06Gfh7xcQ85kSL35okmnY8qk3CebR/7G21yho0I9UVQxXWKivKXGc/1OqN8yCIYbMbf7uXTuOLgzooZFPshE2SaOXEfPI1/NcYQ6r07qbB+UGH+Kzg8GhzlCtaZ+6Nevds0f3aCmOkZzoDzYXDw==
```

---

## Immediate Actions Required

### Step 1: Revoke the Exposed Key (URGENT - Do Now)

1. Go to GitHub Repository Settings
2. Navigate to **Deploy keys**
3. Find the key matching the fingerprint
4. Click **Delete**

```bash
# Verify key fingerprint
ssh-keygen -lf <(echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAACAQC3aLpMerPLyF5wIIKDaRIW+qIlPH/bDlmwiCruY0DZOoHODup2eWvjuacoDY61LqCtyxUyetaQESJ5xqvZIIY7+ye6VG8RhsBVwGp9swX8IVdWmfrdRd9Di5Dwq/WXwD0E3qDx2nPvDzMLyMR/0OaXJmGZ49ggavrGhr4wV/tiGmLG2HKi4AZLDFZMzgCSOK+I4Guqwi0083P9B+bTDXgEiPotsJHNnPezXquoz5KViS1/S1jMqEMA62XpoyHzHLvI/5kcIiCOXJEPlYY9/XotGdQ+RyNJ/RKIHOJHawlZ3ImGqnE731QJTkebKJa+spHO8f3laCE5XKg7kGFpL0E7KN2ReS0hpqr83CyhNq8jnplpSLQeS1hfU5MlU0qsHQi8SQP/EhBoe1fFZlcoA4fuYtewL2NbvsZNqj7p0eU4zFBkMuytZ0+zZlKFJhd9bH7A6cXb2Hj0+oQFLXMNar9rxrfZg30YjyAw0ybRL0K9lemb+M7WqPwnyHia+PvKWoVhzpj8vGq5E3N3dvmW7m0lMRH06Gfh7xcQ85kSL35okmnY8qk3CebR/7G21yho0I9UVQxXWKivKXGc/1OqN8yCIYbMbf7uXTuOLgzooZFPshE2SaOXEfPI1/NcYQ6r07qbB+UGH+Kzg8GhzlCtaZ+6Nevds0f3aCmOkZzoDzYXDw==")
```

### Step 2: Generate New Deploy Key

```bash
# Generate new SSH key pair
ssh-keygen -t ed25519 -a 100 -f infamous-freight-deploy-key -C "deploy@infamousfreight.com"

# Output:
# - infamous-freight-deploy-key (private key)
# - infamous-freight-deploy-key.pub (public key)
```

### Step 3: Add New Key to GitHub

1. Go to GitHub Repository Settings
2. Navigate to **Deploy keys**
3. Click **Add deploy key**
4. Paste the contents of `infamous-freight-deploy-key.pub`
5. Enable **Allow write access** if needed for deployments
6. Click **Add key**

### Step 4: Update Netlify

1. Go to Netlify Dashboard → Site Settings
2. Navigate to **Build & deploy** → **Deploy key**
3. Click **Generate public deploy key**
4. Add the new key to GitHub

### Step 5: Update GitHub Secrets

```bash
# Add new private key to GitHub Secrets
gh secret set DEPLOY_PRIVATE_KEY < infamous-freight-deploy-key
```

### Step 6: Update CI/CD Workflows

Update `.github/workflows/ci-cd.yml` to use the new key:

```yaml
- name: Setup SSH
  uses: webfactory/ssh-agent@v0.9.0
  with:
    ssh-private-key: ${{ secrets.DEPLOY_PRIVATE_KEY }}
```

### Step 7: Verify Deployment

```bash
# Trigger a test deployment
gh workflow run ci-cd.yml --ref main

# Monitor the deployment
gh run watch
```

---

## Security Checklist

- [ ] Old deploy key revoked from GitHub
- [ ] New deploy key generated (Ed25519 recommended)
- [ ] New key added to GitHub Deploy keys
- [ ] Netlify deploy key updated
- [ ] GitHub Secrets updated
- [ ] CI/CD workflows updated
- [ ] Test deployment successful
- [ ] Old PDF documentation removed/updated
- [ ] Team notified of the change

---

## Prevention Measures

### 1. Pre-commit Hooks

Add to `.husky/pre-commit`:

```bash
#!/bin/sh
. "$(dirname "$0")/_/husky.sh"

# Scan for SSH keys
if git diff --cached --name-only | xargs grep -l "ssh-rsa\|ssh-ed25519\|BEGIN OPENSSH PRIVATE KEY" 2>/dev/null; then
  echo "ERROR: Potential SSH key detected in commit!"
  echo "Please remove the key and use GitHub Secrets instead."
  exit 1
fi

# Run existing checks
pnpm lint-staged
```

### 2. GitHub Secret Scanning

Enable GitHub secret scanning:

1. Go to Repository Settings → Security → Secret scanning
2. Enable **Secret scanning**
3. Enable **Push protection**

### 3. Documentation Policy

Add to `CONTRIBUTING.md`:

```markdown
## Security

⚠️ **NEVER commit secrets, API keys, or SSH keys to the repository!**

Use GitHub Secrets for:
- API keys
- Database credentials
- SSH keys
- OAuth tokens

If you accidentally commit a secret:
1. Rotate the secret immediately
2. Contact security@infamousfreight.com
3. Do NOT just delete the file - it's still in git history
```

### 4. Regular Audits

Schedule quarterly security audits:

```bash
# Scan repository for potential secrets
git log --all --full-history -- . | grep -E "(ssh-rsa|ssh-ed25519|BEGIN.*PRIVATE KEY|api[_-]?key|password|secret)"

# Use truffleHog for deep scanning
truffleHog git file://. --since-commit HEAD --only-verified
```

---

## Incident Response

### If the Key Was Compromised

1. **Immediate (0-1 hour)**:
   - Revoke the exposed key
   - Generate new key
   - Check access logs for unauthorized activity

2. **Short-term (1-24 hours)**:
   - Audit all recent commits
   - Check for unauthorized deployments
   - Review access logs
   - Notify team members

3. **Long-term (1-7 days)**:
   - Conduct security review
   - Update security policies
   - Implement additional safeguards
   - Document lessons learned

---

## Contact

- **Security Team**: security@infamousfreight.com
- **On-Call**: [PagerDuty/Opsgenie link]
- **Emergency**: +1-555-SECURITY

---

## References

- [GitHub Deploy Keys Documentation](https://docs.github.com/en/authentication/connecting-to-github-with-ssh/managing-deploy-keys)
- [OWASP Key Management Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Key_Management_Cheat_Sheet.html)
- [NIST SP 800-57: Key Management](https://csrc.nist.gov/publications/detail/sp/800-57-part-1/rev-5/final)

---

*This document is confidential and proprietary to Infamous Freight.*  
*Last Updated: February 24, 2025*
