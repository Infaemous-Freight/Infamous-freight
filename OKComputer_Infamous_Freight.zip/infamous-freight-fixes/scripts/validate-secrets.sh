#!/bin/bash

# Infamous Freight - Secrets Validation Script
# Validates that all required secrets are configured

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     Infamous Freight - Secrets Validation                  ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Required secrets for deployment
REQUIRED_SECRETS=(
    "FLY_API_TOKEN:Fly.io deployment"
    "NETLIFY_AUTH_TOKEN:Netlify deployment"
    "NETLIFY_SITE_ID:Netlify site identification"
    "VERCEL_TOKEN:Vercel deployment"
    "VERCEL_ORG_ID:Vercel organization"
    "VERCEL_PROJECT_ID:Vercel project"
    "GHCR_USERNAME:GitHub Container Registry"
    "GHCR_TOKEN:GitHub Container Registry"
)

# Optional secrets
OPTIONAL_SECRETS=(
    "SLACK_WEBHOOK_URL:Slack notifications"
    "TEAMS_WEBHOOK_URL:Microsoft Teams notifications"
    "CODECOV_TOKEN:Code coverage uploads"
    "TEST_EMAIL:E2E test credentials"
    "TEST_PASSWORD:E2E test credentials"
)

validate_secret() {
    local secret_name="$1"
    local secret_description="$2"
    
    if [ -z "${!secret_name}" ]; then
        echo -e "${RED}❌ $secret_name${NC} - $secret_description"
        return 1
    else
        echo -e "${GREEN}✅ $secret_name${NC} - $secret_description"
        return 0
    fi
}

echo -e "${YELLOW}Required Secrets:${NC}"
echo "────────────────────────────────────────────────────────────"

missing_required=0
for secret in "${REQUIRED_SECRETS[@]}"; do
    IFS=':' read -r name description <<< "$secret"
    if ! validate_secret "$name" "$description"; then
        missing_required=$((missing_required + 1))
    fi
done

echo ""
echo -e "${YELLOW}Optional Secrets:${NC}"
echo "────────────────────────────────────────────────────────────"

for secret in "${OPTIONAL_SECRETS[@]}"; do
    IFS=':' read -r name description <<< "$secret"
    validate_secret "$name" "$description" || true
done

echo ""
echo "────────────────────────────────────────────────────────────"

if [ $missing_required -eq 0 ]; then
    echo -e "${GREEN}✅ All required secrets are configured!${NC}"
    echo ""
    echo -e "${GREEN}You can now run: ./scripts/deploy-to-world-100.sh${NC}"
    exit 0
else
    echo -e "${RED}❌ $missing_required required secret(s) are missing!${NC}"
    echo ""
    echo -e "${YELLOW}To add secrets to GitHub:${NC}"
    echo "1. Go to your repository on GitHub"
    echo "2. Navigate to Settings → Secrets and variables → Actions"
    echo "3. Click 'New repository secret'"
    echo "4. Add each missing secret"
    echo ""
    echo -e "${YELLOW}To add secrets to Netlify:${NC}"
    echo "1. Go to your site dashboard on Netlify"
    echo "2. Navigate to Site settings → Environment variables"
    echo "3. Add the required environment variables"
    exit 1
fi
