#!/bin/bash

# Infamous Freight - 100% Worldwide Deployment Script
# This script deploys all platform components to production

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
API_URL="https://infamous-freight-api.fly.dev"
WEB_URL="https://infamousfreight.com"
VERCEL_URL="https://infamous-freight-enterprises.vercel.app"

# Progress tracking
TOTAL_STEPS=8
CURRENT_STEP=0

print_header() {
    echo -e "${BLUE}"
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║        Infamous Freight - 100% Deployment Script               ║"
    echo "║        Deploying to Production Worldwide                       ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_step() {
    CURRENT_STEP=$((CURRENT_STEP + 1))
    echo -e "${YELLOW}[${CURRENT_STEP}/${TOTAL_STEPS}]${NC} $1"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Step 1: Validate Environment
validate_environment() {
    print_step "Validating environment and secrets..."
    
    # Check required secrets
    local required_secrets=(
        "FLY_API_TOKEN"
        "NETLIFY_AUTH_TOKEN"
        "NETLIFY_SITE_ID"
        "VERCEL_TOKEN"
        "GHCR_USERNAME"
        "GHCR_TOKEN"
    )
    
    local missing_secrets=()
    
    for secret in "${required_secrets[@]}"; do
        if [ -z "${!secret}" ]; then
            missing_secrets+=("$secret")
        fi
    done
    
    if [ ${#missing_secrets[@]} -ne 0 ]; then
        print_error "Missing required secrets: ${missing_secrets[*]}"
        print_info "Please set these secrets in your GitHub repository settings"
        exit 1
    fi
    
    # Check tools
    if ! command -v flyctl &> /dev/null; then
        print_error "flyctl is not installed. Install with: curl -L https://fly.io/install.sh | sh"
        exit 1
    fi
    
    if ! command -v pnpm &> /dev/null; then
        print_error "pnpm is not installed. Install with: npm install -g pnpm"
        exit 1
    fi
    
    print_success "Environment validation passed"
}

# Step 2: Build Shared Package
build_shared() {
    print_step "Building shared package..."
    
    pnpm --filter @infamous-freight/shared build
    
    print_success "Shared package built successfully"
}

# Step 3: Deploy API to Fly.io
deploy_api() {
    print_step "Deploying API to Fly.io..."
    
    cd apps/api
    
    # Deploy to Fly.io
    flyctl deploy --config fly.toml --remote-only
    
    # Wait for deployment
    print_info "Waiting for API to be ready..."
    sleep 30
    
    # Health check
    local retries=0
    local max_retries=10
    
    while [ $retries -lt $max_retries ]; do
        if curl -sf "$API_URL/api/health" > /dev/null 2>&1; then
            print_success "API is healthy"
            break
        fi
        retries=$((retries + 1))
        print_info "Health check attempt $retries/$max_retries..."
        sleep 10
    done
    
    if [ $retries -eq $max_retries ]; then
        print_error "API health check failed after $max_retries attempts"
        exit 1
    fi
    
    cd ../..
    print_success "API deployed successfully to $API_URL"
}

# Step 4: Deploy Web to Netlify (Primary)
deploy_web_netlify() {
    print_step "Deploying Web to Netlify (Primary)..."
    
    # Build web app
    cd apps/web
    
    NEXT_PUBLIC_API_URL="$API_URL" \
    NEXT_PUBLIC_APP_ENV="production" \
    pnpm build
    
    # Deploy to Netlify
    if command -v netlify &> /dev/null; then
        netlify deploy --prod --dir=.next --site="$NETLIFY_SITE_ID"
    else
        print_info "Netlify CLI not installed, using GitHub Actions deployment"
    fi
    
    cd ../..
    print_success "Web deployed to Netlify: $WEB_URL"
}

# Step 5: Deploy Web to Vercel (Secondary)
deploy_web_vercel() {
    print_step "Deploying Web to Vercel (Secondary/Preview)..."
    
    cd apps/web
    
    if command -v vercel &> /dev/null; then
        vercel --prod --yes
    else
        print_info "Vercel CLI not installed, using GitHub Actions deployment"
    fi
    
    cd ../..
    print_success "Web deployed to Vercel: $VERCEL_URL"
}

# Step 6: Run Smoke Tests
run_smoke_tests() {
    print_step "Running smoke tests..."
    
    # Test API health
    if curl -sf "$API_URL/api/health" > /dev/null 2>&1; then
        print_success "API health check passed"
    else
        print_error "API health check failed"
        exit 1
    fi
    
    # Test Web availability
    if curl -sf "$WEB_URL" > /dev/null 2>&1; then
        print_success "Web availability check passed"
    else
        print_error "Web availability check failed"
        exit 1
    fi
    
    # Test API endpoints
    local endpoints=(
        "/api/health"
        "/api/billing"
    )
    
    for endpoint in "${endpoints[@]}"; do
        if curl -sf "$API_URL$endpoint" > /dev/null 2>&1; then
            print_success "Endpoint $endpoint is accessible"
        else
            print_error "Endpoint $endpoint is not accessible"
        fi
    done
    
    print_success "Smoke tests completed"
}

# Step 7: Publish Docker Images
publish_docker_images() {
    print_step "Publishing Docker images to GHCR..."
    
    # Login to GHCR
    echo "$GHCR_TOKEN" | docker login ghcr.io -u "$GHCR_USERNAME" --password-stdin
    
    # Build and push API image
    docker build -t "ghcr.io/$GHCR_USERNAME/infamous-freight-api:latest" -f apps/api/Dockerfile .
    docker push "ghcr.io/$GHCR_USERNAME/infamous-freight-api:latest"
    
    # Tag with version if available
    if [ -n "$GITHUB_SHA" ]; then
        docker tag "ghcr.io/$GHCR_USERNAME/infamous-freight-api:latest" \
                   "ghcr.io/$GHCR_USERNAME/infamous-freight-api:$GITHUB_SHA"
        docker push "ghcr.io/$GHCR_USERNAME/infamous-freight-api:$GITHUB_SHA"
    fi
    
    print_success "Docker images published to GHCR"
}

# Step 8: Send Notifications
send_notifications() {
    print_step "Sending deployment notifications..."
    
    # Slack notification
    if [ -n "$SLACK_WEBHOOK_URL" ]; then
        curl -X POST -H 'Content-type: application/json' \
            --data "{
                \"text\": \"🚀 Infamous Freight Deployment Complete\",
                \"blocks\": [
                    {
                        \"type\": \"header\",
                        \"text\": {
                            \"type\": \"plain_text\",
                            \"text\": \"✅ Deployment Successful\"
                        }
                    },
                    {
                        \"type\": \"section\",
                        \"fields\": [
                            {
                                \"type\": \"mrkdwn\",
                                \"text\": \"*API:* $API_URL\"
                            },
                            {
                                \"type\": \"mrkdwn\",
                                \"text\": \"*Web (Primary):* $WEB_URL\"
                            },
                            {
                                \"type\": \"mrkdwn\",
                                \"text\": \"*Web (Preview):* $VERCEL_URL\"
                            }
                        ]
                    }
                ]
            }" \
            "$SLACK_WEBHOOK_URL"
        print_success "Slack notification sent"
    fi
    
    # Teams notification
    if [ -n "$TEAMS_WEBHOOK_URL" ]; then
        curl -X POST -H 'Content-type: application/json' \
            --data "{
                \"@type\": \"MessageCard\",
                \"@context\": \"https://schema.org/extensions\",
                \"themeColor\": \"00FF00\",
                \"summary\": \"Infamous Freight Deployment Complete\",
                \"sections\": [{
                    \"activityTitle\": \"✅ Deployment Successful\",
                    \"facts\": [
                        {\"name\": \"API\", \"value\": \"$API_URL\"},
                        {\"name\": \"Web (Primary)\", \"value\": \"$WEB_URL\"},
                        {\"name\": \"Web (Preview)\", \"value\": \"$VERCEL_URL\"}
                    ]
                }]
            }" \
            "$TEAMS_WEBHOOK_URL"
        print_success "Teams notification sent"
    fi
}

# Print deployment summary
print_summary() {
    echo -e "${GREEN}"
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║              🎉 DEPLOYMENT COMPLETE! 🎉                        ║"
    echo "╠════════════════════════════════════════════════════════════════╣"
    echo "║  API:           $API_URL"
    echo "║  Web (Primary): $WEB_URL"
    echo "║  Web (Preview): $VERCEL_URL"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    echo -e "${BLUE}Deployment Status:${NC}"
    echo -e "  ✅ API (Fly.io):           100%"
    echo -e "  ✅ Web (Netlify):          100%"
    echo -e "  ✅ Web (Vercel):           100%"
    echo -e "  ✅ Docker Images:          100%"
    echo -e "  ✅ Smoke Tests:            100%"
    echo ""
    echo -e "${GREEN}Overall Status: 100% 🚀${NC}"
}

# Main execution
main() {
    print_header
    
    validate_environment
    build_shared
    deploy_api
    deploy_web_netlify
    deploy_web_vercel
    run_smoke_tests
    publish_docker_images
    send_notifications
    
    print_summary
}

# Run main function
main "$@"
