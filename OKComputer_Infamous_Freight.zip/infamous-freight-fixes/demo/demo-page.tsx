'use client';

import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import {
  Truck,
  MapPin,
  DollarSign,
  TrendingUp,
  Users,
  Package,
  Activity,
  Star,
  Clock,
  CheckCircle,
  AlertCircle,
  Navigation,
  BarChart3,
  MessageSquare,
  Mic,
  Shield,
  Zap
} from 'lucide-react';

// Demo data
const DEMO_STATS = {
  activeShipments: 3,
  deliveriesThisMonth: 47,
  availableDrivers: 12,
  activeVehicles: 15,
  revenueThisMonth: 48520,
  averageRating: 4.8,
  totalMiles: 125000
};

const DEMO_SHIPMENTS = [
  {
    id: 'SH-2025-001',
    shipper: 'ABC Manufacturing',
    origin: 'Chicago, IL',
    destination: 'Detroit, MI',
    status: 'in_transit',
    driver: 'John D.',
    vehicle: 'FL-2022-001',
    rate: 850,
    distance: 283,
    pickupDate: '2025-02-25T08:00:00',
    deliveryDate: '2025-02-25T16:00:00',
    progress: 65
  },
  {
    id: 'SH-2025-002',
    shipper: 'Global Foods Inc',
    origin: 'Dallas, TX',
    destination: 'Houston, TX',
    status: 'delivered',
    driver: 'Mike R.',
    vehicle: 'PB-2023-002',
    rate: 620,
    distance: 240,
    pickupDate: '2025-02-24T06:00:00',
    deliveryDate: '2025-02-24T14:00:00',
    progress: 100
  },
  {
    id: 'SH-2025-003',
    shipper: 'Steel Works Co',
    origin: 'Pittsburgh, PA',
    destination: 'Cleveland, OH',
    status: 'pending',
    driver: 'Unassigned',
    vehicle: 'Unassigned',
    rate: 450,
    distance: 135,
    pickupDate: '2025-02-26T07:00:00',
    deliveryDate: '2025-02-26T18:00:00',
    progress: 0
  }
];

const DEMO_DRIVERS = [
  { id: 1, name: 'John D.', status: 'on_duty', rating: 4.8, miles: 150000, location: 'Toledo, OH' },
  { id: 2, name: 'Mike R.', status: 'available', rating: 4.9, miles: 230000, location: 'Houston, TX' },
  { id: 3, name: 'Sarah K.', status: 'off_duty', rating: 4.7, miles: 89000, location: 'Atlanta, GA' }
];

const AI_SUGGESTIONS = [
  { type: 'load', message: 'High-paying load available: $3.45/mile from your current location', priority: 'high' },
  { type: 'route', message: 'Traffic alert on I-94. Alternative route saves 23 minutes.', priority: 'medium' },
  { type: 'maintenance', message: 'Vehicle FL-2022-001 due for oil change in 500 miles', priority: 'low' }
];

export default function DemoPage() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isListening, setIsListening] = useState(false);
  const [aiResponse, setAiResponse] = useState('');

  const handleVoiceCommand = () => {
    setIsListening(true);
    setTimeout(() => {
      setIsListening(false);
      setAiResponse('I found 3 loads within 50 miles. The best option pays $3.45/mile going to Detroit. Would you like me to book it?');
    }, 2000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'in_transit': return 'bg-blue-500';
      case 'delivered': return 'bg-green-500';
      case 'pending': return 'bg-yellow-500';
      case 'on_duty': return 'bg-blue-500';
      case 'available': return 'bg-green-500';
      case 'off_duty': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    return status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Head>
        <title>Infamous Freight - Live Demo</title>
        <meta name="description" content="Experience the future of freight management with our interactive demo" />
      </Head>

      {/* Demo Banner */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 px-4 text-center">
        <p className="text-sm font-medium">
          🎉 This is a live demo environment with sample data. 
          <a href="/signup" className="underline ml-2 hover:text-blue-200">Start your free trial →</a>
        </p>
      </div>

      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Truck className="h-8 w-8 text-blue-600" />
                <span className="text-xl font-bold text-gray-900">Infamous Freight</span>
              </div>
              <span className="px-3 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded-full">Demo</span>
            </div>
            <nav className="flex space-x-8">
              {['dashboard', 'shipments', 'drivers', 'analytics'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`text-sm font-medium capitalize ${
                    activeTab === tab
                      ? 'text-blue-600 border-b-2 border-blue-600'
                      : 'text-gray-500 hover:text-gray-700'
                  } pb-5 pt-5`}
                >
                  {tab}
                </button>
              ))}
            </nav>
            <div className="flex items-center space-x-4">
              <button
                onClick={handleVoiceCommand}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all ${
                  isListening
                    ? 'bg-red-500 text-white animate-pulse'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                <Mic className="h-4 w-4" />
                <span className="text-sm">{isListening ? 'Listening...' : 'Voice Command'}</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* AI Response */}
      {aiResponse && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
          <div className="bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-xl p-4 flex items-start space-x-3">
            <Zap className="h-5 w-5 text-purple-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-purple-900">Genesis AI</p>
              <p className="text-sm text-purple-700 mt-1">{aiResponse}</p>
            </div>
            <button
              onClick={() => setAiResponse('')}
              className="ml-auto text-purple-400 hover:text-purple-600"
            >
              ×
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && (
          <div className="space-y-8">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Active Shipments</p>
                    <p className="text-3xl font-bold text-gray-900 mt-2">{DEMO_STATS.activeShipments}</p>
                  </div>
                  <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Package className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                  <span className="text-green-500 font-medium">+12%</span>
                  <span className="text-gray-400 ml-2">vs last month</span>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Monthly Revenue</p>
                    <p className="text-3xl font-bold text-gray-900 mt-2">${DEMO_STATS.revenueThisMonth.toLocaleString()}</p>
                  </div>
                  <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <DollarSign className="h-6 w-6 text-green-600" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                  <span className="text-green-500 font-medium">+23%</span>
                  <span className="text-gray-400 ml-2">vs last month</span>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Available Drivers</p>
                    <p className="text-3xl font-bold text-gray-900 mt-2">{DEMO_STATS.availableDrivers}</p>
                  </div>
                  <div className="h-12 w-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Users className="h-6 w-6 text-purple-600" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
                  <span className="text-green-500 font-medium">All HOS compliant</span>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Avg Driver Rating</p>
                    <p className="text-3xl font-bold text-gray-900 mt-2">{DEMO_STATS.averageRating}</p>
                  </div>
                  <div className="h-12 w-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <Star className="h-6 w-6 text-yellow-600" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <span className="text-gray-500">Based on 127 reviews</span>
                </div>
              </div>
            </div>

            {/* AI Suggestions */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <Zap className="h-5 w-5 text-purple-600 mr-2" />
                AI-Powered Insights
              </h3>
              <div className="space-y-3">
                {AI_SUGGESTIONS.map((suggestion, index) => (
                  <div
                    key={index}
                    className={`flex items-start space-x-3 p-4 rounded-lg ${
                      suggestion.priority === 'high'
                        ? 'bg-red-50 border border-red-200'
                        : suggestion.priority === 'medium'
                        ? 'bg-yellow-50 border border-yellow-200'
                        : 'bg-blue-50 border border-blue-200'
                    }`}
                  >
                    <AlertCircle className={`h-5 w-5 flex-shrink-0 mt-0.5 ${
                      suggestion.priority === 'high'
                        ? 'text-red-600'
                        : suggestion.priority === 'medium'
                        ? 'text-yellow-600'
                        : 'text-blue-600'
                    }`} />
                    <div className="flex-1">
                      <p className="text-sm text-gray-700">{suggestion.message}</p>
                    </div>
                    <button className="text-sm font-medium text-blue-600 hover:text-blue-800">
                      {suggestion.type === 'load' ? 'View Load' : suggestion.type === 'route' ? 'View Route' : 'Schedule'}
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Active Shipments */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Active Shipments</h3>
                <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">View All</button>
              </div>
              <div className="divide-y divide-gray-200">
                {DEMO_SHIPMENTS.map((shipment) => (
                  <div key={shipment.id} className="px-6 py-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3">
                          <span className="text-sm font-medium text-gray-900">{shipment.id}</span>
                          <span className={`px-2 py-1 text-xs font-medium rounded-full text-white ${getStatusColor(shipment.status)}`}>
                            {getStatusText(shipment.status)}
                          </span>
                        </div>
                        <div className="mt-2 flex items-center text-sm text-gray-500 space-x-6">
                          <span className="flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {shipment.origin} → {shipment.destination}
                          </span>
                          <span className="flex items-center">
                            <Truck className="h-4 w-4 mr-1" />
                            {shipment.driver}
                          </span>
                          <span className="flex items-center">
                            <DollarSign className="h-4 w-4 mr-1" />
                            ${shipment.rate}
                          </span>
                          <span className="flex items-center">
                            <Navigation className="h-4 w-4 mr-1" />
                            {shipment.distance} miles
                          </span>
                        </div>
                      </div>
                      <div className="ml-4">
                        <div className="w-32">
                          <div className="flex justify-between text-xs text-gray-500 mb-1">
                            <span>Progress</span>
                            <span>{shipment.progress}%</span>
                          </div>
                          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-blue-600 rounded-full transition-all duration-500"
                              style={{ width: `${shipment.progress}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'shipments' && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">All Shipments</h3>
            </div>
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Shipper</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Route</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rate</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {DEMO_SHIPMENTS.map((shipment) => (
                  <tr key={shipment.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{shipment.id}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{shipment.shipper}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{shipment.origin} → {shipment.destination}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full text-white ${getStatusColor(shipment.status)}`}>
                        {getStatusText(shipment.status)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${shipment.rate}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-600 hover:text-blue-800 cursor-pointer">View Details</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'drivers' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {DEMO_DRIVERS.map((driver) => (
              <div key={driver.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center space-x-4">
                  <div className="h-12 w-12 bg-gray-200 rounded-full flex items-center justify-center">
                    <Users className="h-6 w-6 text-gray-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{driver.name}</h3>
                    <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full text-white ${getStatusColor(driver.status)}`}>
                      {getStatusText(driver.status)}
                    </span>
                  </div>
                </div>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center text-sm text-gray-500">
                    <Star className="h-4 w-4 mr-2 text-yellow-500" />
                    Rating: {driver.rating}/5.0
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Activity className="h-4 w-4 mr-2 text-blue-500" />
                    {driver.miles.toLocaleString()} miles driven
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <MapPin className="h-4 w-4 mr-2 text-green-500" />
                    {driver.location}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue Analytics</h3>
              <div className="h-64 flex items-end justify-around space-x-2">
                {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'].map((month, index) => (
                  <div key={month} className="flex flex-col items-center">
                    <div
                      className="w-16 bg-blue-600 rounded-t-lg transition-all duration-500 hover:bg-blue-700"
                      style={{ height: `${(index + 1) * 40 + 60}px` }}
                    />
                    <span className="mt-2 text-sm text-gray-500">{month}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Metrics</h3>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-500">On-Time Delivery</span>
                      <span className="font-medium text-gray-900">94%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 rounded-full" style={{ width: '94%' }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-500">Customer Satisfaction</span>
                      <span className="font-medium text-gray-900">4.8/5</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 rounded-full" style={{ width: '96%' }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-500">Fleet Utilization</span>
                      <span className="font-medium text-gray-900">87%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-purple-500 rounded-full" style={{ width: '87%' }} />
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Cost Breakdown</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-3 w-3 bg-blue-500 rounded-full mr-2" />
                      <span className="text-sm text-gray-600">Fuel</span>
                    </div>
                    <span className="text-sm font-medium text-gray-900">42%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-3 w-3 bg-green-500 rounded-full mr-2" />
                      <span className="text-sm text-gray-600">Driver Pay</span>
                    </div>
                    <span className="text-sm font-medium text-gray-900">35%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-3 w-3 bg-yellow-500 rounded-full mr-2" />
                      <span className="text-sm text-gray-600">Maintenance</span>
                    </div>
                    <span className="text-sm font-medium text-gray-900">12%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-3 w-3 bg-red-500 rounded-full mr-2" />
                      <span className="text-sm text-gray-600">Insurance</span>
                    </div>
                    <span className="text-sm font-medium text-gray-900">8%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-3 w-3 bg-gray-500 rounded-full mr-2" />
                      <span className="text-sm text-gray-600">Other</span>
                    </div>
                    <span className="text-sm font-medium text-gray-900">3%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* CTA Section */}
      <div className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Freight Operations?</h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Join thousands of carriers and drivers already using Infamous Freight to maximize profitability.
          </p>
          <div className="flex justify-center space-x-4">
            <a
              href="/signup"
              className="px-8 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors"
            >
              Start Free Trial
            </a>
            <a
              href="/contact"
              className="px-8 py-3 bg-transparent border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-gray-900 transition-colors"
            >
              Talk to Sales
            </a>
          </div>
          <p className="mt-4 text-sm text-gray-400">No credit card required. 14-day free trial.</p>
        </div>
      </div>
    </div>
  );
}
