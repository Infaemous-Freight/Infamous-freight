-- Infamous Freight Demo Data
-- This script creates sample data for the public demo environment

-- Insert demo users
INSERT INTO "User" (id, email, name, role, company, created_at, updated_at) VALUES
('demo-user-1', 'demo@infamousfreight.com', 'Demo Driver', 'DRIVER', 'Demo Trucking LLC', NOW(), NOW()),
('demo-user-2', 'fleet@infamousfreight.com', 'Fleet Manager', 'FLEET_MANAGER', 'Midwest Logistics Inc', NOW(), NOW()),
('demo-user-3', 'admin@infamousfreight.com', 'Admin User', 'ADMIN', 'Infamous Freight Demo', NOW(), NOW());

-- Insert demo drivers
INSERT INTO "Driver" (id, user_id, license_number, phone, status, current_location, rating, total_miles, created_at) VALUES
('driver-1', 'demo-user-1', 'CDL12345678', '+1-555-0101', 'AVAILABLE', 'Chicago, IL', 4.8, 150000, NOW()),
('driver-2', NULL, 'CDL87654321', '+1-555-0102', 'ON_DUTY', 'Dallas, TX', 4.9, 230000, NOW()),
('driver-3', NULL, 'CDL11223344', '+1-555-0103', 'OFF_DUTY', 'Atlanta, GA', 4.7, 89000, NOW());

-- Insert demo vehicles
INSERT INTO "Vehicle" (id, driver_id, vin, make, model, year, plate_number, status, mileage, last_maintenance, next_maintenance, created_at) VALUES
('vehicle-1', 'driver-1', '1HGBH41JXMN109186', 'Freightliner', 'Cascadia', 2022, 'IL-TRUCK1', 'ACTIVE', 150000, '2025-01-15', '2025-04-15', NOW()),
('vehicle-2', 'driver-2', '1HGBH41JXMN109187', 'Peterbilt', '579', 2023, 'TX-TRUCK2', 'ACTIVE', 89000, '2025-02-01', '2025-05-01', NOW()),
('vehicle-3', 'driver-3', '1HGBH41JXMN109188', 'Kenworth', 'T680', 2021, 'GA-TRUCK3', 'MAINTENANCE', 230000, '2025-01-20', '2025-02-20', NOW());

-- Insert demo shipments
INSERT INTO "Shipment" (id, shipper_name, shipper_address, consignee_name, consignee_address, pickup_date, delivery_date, status, weight, distance, rate, driver_id, vehicle_id, created_at) VALUES
('shipment-1', 'ABC Manufacturing', '123 Industrial Way, Chicago, IL 60601', 'XYZ Distribution', '456 Commerce St, Detroit, MI 48201', '2025-02-25 08:00:00', '2025-02-25 16:00:00', 'IN_TRANSIT', 45000, 283, 850.00, 'driver-1', 'vehicle-1', NOW()),
('shipment-2', 'Global Foods Inc', '789 Warehouse Blvd, Dallas, TX 75201', 'Fresh Market', '321 Grocery Lane, Houston, TX 77001', '2025-02-24 06:00:00', '2025-02-24 14:00:00', 'DELIVERED', 32000, 240, 620.00, 'driver-2', 'vehicle-2', NOW()),
('shipment-3', 'Steel Works Co', '555 Factory Rd, Pittsburgh, PA 15201', 'Construction Depot', '888 Building Ave, Cleveland, OH 44101', '2025-02-26 07:00:00', '2025-02-26 18:00:00', 'PENDING', 48000, 135, 450.00, NULL, NULL, NOW()),
('shipment-4', 'Electronics Plus', '999 Tech Park, San Jose, CA 95101', 'Retail Giant', '111 Storefront St, Los Angeles, CA 90001', '2025-02-23 09:00:00', '2025-02-25 15:00:00', 'DELIVERED', 12000, 382, 1200.00, 'driver-1', 'vehicle-1', NOW()),
('shipment-5', 'Farm Fresh', '222 Rural Route, Des Moines, IA 50301', 'City Market', '333 Urban Ave, Minneapolis, MN 55401', '2025-02-27 05:00:00', '2025-02-27 16:00:00', 'PENDING', 28000, 244, 580.00, NULL, NULL, NOW());

-- Insert demo invoices
INSERT INTO "Invoice" (id, shipment_id, amount, status, due_date, paid_date, created_at) VALUES
('invoice-1', 'shipment-2', 620.00, 'PAID', '2025-03-10', '2025-03-05', NOW()),
('invoice-2', 'shipment-4', 1200.00, 'PAID', '2025-03-12', '2025-03-08', NOW()),
('invoice-3', 'shipment-1', 850.00, 'PENDING', '2025-03-15', NULL, NOW()),
('invoice-4', 'shipment-3', 450.00, 'DRAFT', '2025-03-20', NULL, NOW());

-- Insert demo tracking events
INSERT INTO "TrackingEvent" (id, shipment_id, event_type, location, latitude, longitude, notes, created_at) VALUES
('event-1', 'shipment-1', 'PICKUP', 'Chicago, IL', 41.8781, -87.6298, 'Load picked up on time', NOW() - INTERVAL '6 hours'),
('event-2', 'shipment-1', 'IN_TRANSIT', 'Gary, IN', 41.5934, -87.3369, 'Passing through Indiana', NOW() - INTERVAL '4 hours'),
('event-3', 'shipment-1', 'IN_TRANSIT', 'Toledo, OH', 41.6528, -83.5379, 'Approaching Michigan border', NOW() - INTERVAL '2 hours'),
('event-4', 'shipment-2', 'PICKUP', 'Dallas, TX', 32.7767, -96.7970, 'Load secured', NOW() - INTERVAL '24 hours'),
('event-5', 'shipment-2', 'DELIVERED', 'Houston, TX', 29.7604, -95.3698, 'Delivery completed successfully', NOW() - INTERVAL '12 hours');

-- Insert demo AI events
INSERT INTO "AiEvent" (id, user_id, event_type, prompt, response, tokens_used, created_at) VALUES
('ai-1', 'demo-user-1', 'LOAD_RECOMMENDATION', 'Find me the best paying load from Chicago', '{"loads": [{"id": "shipment-3", "rate": 450, "distance": 135, "rpm": 3.33}]}', 150, NOW() - INTERVAL '2 hours'),
('ai-2', 'demo-user-2', 'ROUTE_OPTIMIZATION', 'Optimize route for 5 deliveries in Texas', '{"optimized_route": ["Dallas", "Houston", "Austin", "San Antonio"], "savings": 127}', 200, NOW() - INTERVAL '1 hour'),
('ai-3', 'demo-user-1', 'PROFITABILITY_ANALYSIS', 'What was my profit last week?', '{"total_revenue": 2050, "total_expenses": 890, "net_profit": 1160, "margin": 56.6}', 180, NOW());

-- Insert demo maintenance records
INSERT INTO "MaintenanceRecord" (id, vehicle_id, service_type, description, cost, service_date, next_service_date, status, created_at) VALUES
('maint-1', 'vehicle-1', 'OIL_CHANGE', 'Regular oil change and filter replacement', 125.00, '2025-01-15', '2025-04-15', 'COMPLETED', NOW()),
('maint-2', 'vehicle-2', 'TIRE_ROTATION', 'Tire rotation and alignment check', 85.00, '2025-02-01', '2025-05-01', 'COMPLETED', NOW()),
('maint-3', 'vehicle-3', 'BRAKE_REPLACEMENT', 'Brake pad and rotor replacement', 450.00, '2025-01-20', '2025-07-20', 'SCHEDULED', NOW());

-- Insert demo compliance records
INSERT INTO "ComplianceRecord" (id, driver_id, record_type, status, expiration_date, document_url, created_at) VALUES
('comp-1', 'driver-1', 'CDL', 'VALID', '2027-03-15', 'https://docs.infamousfreight.com/cdl/demo-1.pdf', NOW()),
('comp-2', 'driver-1', 'MEDICAL_CARD', 'VALID', '2026-08-20', 'https://docs.infamousfreight.com/medical/demo-1.pdf', NOW()),
('comp-3', 'driver-2', 'CDL', 'VALID', '2028-01-10', 'https://docs.infamousfreight.com/cdl/demo-2.pdf', NOW()),
('comp-4', 'driver-1', 'HAZMAT_ENDORSEMENT', 'VALID', '2027-03-15', 'https://docs.infamousfreight.com/hazmat/demo-1.pdf', NOW());

-- Insert demo HOS logs
INSERT INTO "HosLog" (id, driver_id, date, drive_hours, on_duty_hours, off_duty_hours, sleeper_berth_hours, status, created_at) VALUES
('hos-1', 'driver-1', '2025-02-24', 8.5, 11.0, 10.0, 2.5, 'COMPLIANT', NOW()),
('hos-2', 'driver-2', '2025-02-24', 7.0, 10.5, 11.5, 2.0, 'COMPLIANT', NOW()),
('hos-3', 'driver-1', '2025-02-23', 9.0, 12.0, 9.0, 3.0, 'COMPLIANT', NOW());

-- Create demo analytics summary view
CREATE OR REPLACE VIEW demo_dashboard_summary AS
SELECT
  (SELECT COUNT(*) FROM "Shipment" WHERE status IN ('IN_TRANSIT', 'PENDING')) as active_shipments,
  (SELECT COUNT(*) FROM "Shipment" WHERE status = 'DELIVERED' AND created_at > NOW() - INTERVAL '30 days') as deliveries_this_month,
  (SELECT COUNT(*) FROM "Driver" WHERE status = 'AVAILABLE') as available_drivers,
  (SELECT COUNT(*) FROM "Vehicle" WHERE status = 'ACTIVE') as active_vehicles,
  (SELECT SUM(rate) FROM "Shipment" WHERE status = 'DELIVERED' AND created_at > NOW() - INTERVAL '30 days') as revenue_this_month,
  (SELECT ROUND(AVG(rating), 2) FROM "Driver") as average_driver_rating,
  (SELECT SUM(distance) FROM "Shipment" WHERE status = 'DELIVERED') as total_miles_driven;

-- Grant access to demo users
-- Note: In production, use proper RBAC
