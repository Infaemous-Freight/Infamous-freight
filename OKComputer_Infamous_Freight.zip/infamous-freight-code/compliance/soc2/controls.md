# SOC 2 Type II Controls

## Overview

This document outlines the controls implemented by Infamous Freight to meet SOC 2 Type II requirements across the five Trust Service Criteria (TSC).

---

## 1. Security (Common Criteria)

### CC6.1 - Logical and Physical Access Controls

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| SEC-001 | User authentication required | JWT-based auth with 15min expiry | Auth middleware code |
| SEC-002 | MFA for admin access | Required for all admin accounts | IAM configuration |
| SEC-003 | Password complexity enforced | Min 12 chars, complexity rules | Registration validation |
| SEC-004 | Account lockout after failures | 5 failed attempts = 15min lockout | Rate limiter config |
| SEC-005 | Session timeout | 15min idle timeout | JWT configuration |

### CC6.2 - Prior to Access

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| SEC-006 | User access requests documented | Jira tickets for access requests | Jira project |
| SEC-007 | Access approval workflow | Manager + Security approval required | Approval process docs |
| SEC-008 | Background checks | Completed for all employees | HR records |
| SEC-009 | Access reviews quarterly | Automated quarterly reviews | Review logs |

### CC6.3 - Access Removal

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| SEC-010 | Immediate access termination | API key revocation within 1 hour | Termination checklist |
| SEC-011 | Offboarding checklist | 15-step offboarding process | HR procedures |

### CC7.1 - Security Operations

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| SEC-012 | Vulnerability scanning | Weekly Trivy scans | GitHub Actions |
| SEC-013 | Penetration testing | Annual third-party pentest | Pentest reports |
| SEC-014 | Bug bounty program | HackerOne integration | bug-bounty.md |
| SEC-015 | Security incident response | 24/7 on-call rotation | Incident response plan |
| SEC-016 | WAF protection | AWS WAF with custom rules | waf-rules.json |

### CC7.2 - System Monitoring

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| SEC-017 | Centralized logging | ELK stack for all logs | Kibana dashboards |
| SEC-018 | Log retention | 1 year retention policy | S3 lifecycle policy |
| SEC-019 | Audit logging | All data changes logged | Audit log table |
| SEC-020 | Real-time alerting | PagerDuty for critical alerts | Alert rules |

### CC8.1 - Change Management

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| SEC-021 | Code review required | PR approval required | GitHub branch protection |
| SEC-022 | Automated testing | CI/CD with test gates | GitHub Actions |
| SEC-023 | Change approval | CAB approval for production | Change log |
| SEC-024 | Rollback capability | One-command rollback | rollback.sh |

---

## 2. Availability

### A1.1 - Availability Commitments

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| AVA-001 | 99.99% uptime SLA | Multi-AZ deployment | SLA document |
| AVA-002 | Status page | status.infamousfreight.com | Status page |
| AVA-003 | Incident communication | < 15min incident notification | Incident response plan |

### A1.2 - System Availability

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| AVA-004 | Auto-scaling | HPA with CPU/memory metrics | hpa.yaml |
| AVA-005 | Load balancing | NGINX ingress controller | ingress.yaml |
| AVA-006 | Health checks | Liveness/readiness probes | deployment.yaml |
| AVA-007 | Circuit breakers | Implemented for external APIs | Code review |

### A1.3 - Recovery Point Objective

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| AVA-008 | Database backups | Hourly automated backups | RDS backup config |
| AVA-009 | Backup testing | Monthly restore tests | Test documentation |
| AVA-010 | RPO: 1 hour | Point-in-time recovery enabled | RDS configuration |

### A1.4 - Recovery Time Objective

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| AVA-011 | RTO: 4 hours | Documented recovery procedures | DR playbook |
| AVA-012 | Disaster recovery plan | Annual DR testing | DR test results |
| AVA-013 | Multi-region failover | Hot standby in secondary region | Architecture diagram |

---

## 3. Processing Integrity

### PI1.1 - Data Processing

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| INT-001 | Input validation | Zod schemas for all inputs | Validation code |
| INT-002 | Data type enforcement | TypeScript strict mode | tsconfig.json |
| INT-003 | Transaction integrity | ACID database transactions | Prisma transactions |
| INT-004 | Error handling | Centralized error handler | errorHandler.ts |

### PI1.2 - Processing Accuracy

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| INT-005 | Data reconciliation | Daily automated reconciliations | Reconciliation jobs |
| INT-006 | Rate calculation accuracy | Unit tests for all calculations | Test suite |
| INT-007 | Duplicate detection | Unique constraints + checks | Database schema |

### PI1.3 - Processing Completeness

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| INT-008 | Event sourcing | Kafka for all state changes | Kafka topics |
| INT-009 | Audit trail | Immutable audit log | audit_logs table |
| INT-010 | Batch processing monitoring | Dead letter queue monitoring | DLQ alerts |

---

## 4. Confidentiality

### C1.1 - Confidentiality Commitments

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| CON-001 | Data classification | Public, Internal, Confidential, Restricted | Data classification policy |
| CON-002 | Encryption in transit | TLS 1.3 for all connections | SSL Labs report |
| CON-003 | Encryption at rest | AES-256 for all storage | RDS/EBS encryption |
| CON-004 | Key management | AWS KMS with rotation | KMS configuration |

### C1.2 - Access to Confidential Information

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| CON-005 | Role-based access control | 5 role levels implemented | RBAC matrix |
| CON-006 | Principle of least privilege | Users have minimum required access | Access reviews |
| CON-007 | Data masking | PII masked in logs | Log configuration |

---

## 5. Privacy

### P1.1 - Privacy Notice

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| PRV-001 | Privacy policy published | infamousfreight.com/privacy | Privacy policy |
| PRV-002 | Cookie notice | Cookie consent banner | Website |
| PRV-003 | Data use transparency | Clear data use explanations | Privacy policy |

### P2.1 - Choice and Consent

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| PRV-004 | Opt-in for marketing | Explicit consent required | Registration flow |
| PRV-005 | Cookie preferences | Granular cookie controls | Cookie settings |
| PRV-006 | Data sharing opt-out | Users can opt out | Account settings |

### P3.1 - Collection

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| PRV-007 | Data minimization | Only collect necessary data | Data inventory |
| PRV-008 | Purpose limitation | Data used only for stated purpose | Privacy policy |

### P4.1 - Use, Retention, and Disposal

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| PRV-009 | Data retention policy | 7 years for financial data | Retention schedule |
| PRV-010 | Secure deletion | Cryptographic erasure | Deletion procedures |
| PRV-011 | Account deletion | Self-service account deletion | Account settings |

### P5.1 - Access

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| PRV-012 | Data access requests | 30-day response SLA | DSR procedure |
| PRV-013 | Data portability | Export data in standard format | Export feature |
| PRV-014 | Data correction | Self-service profile editing | Profile page |

### P6.1 - Disclosure to Third Parties

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| PRV-015 | Vendor agreements | DPA with all vendors | Vendor contracts |
| PRV-016 | Subprocessor list | Published on website | Subprocessor page |

### P7.1 - Quality

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| PRV-017 | Data accuracy | Users can update their data | Profile editing |
| PRV-018 | Data validation | Input validation on all fields | Validation code |

### P8.1 - Monitoring and Enforcement

| Control ID | Control Description | Implementation | Evidence |
|------------|---------------------|----------------|----------|
| PRV-019 | Privacy training | Annual privacy training | Training records |
| PRV-020 | Privacy impact assessments | PIA for new features | PIA documents |
| PRV-021 | DPO appointed | privacy@infamousfreight.com | Contact info |

---

## Control Testing Schedule

| Frequency | Controls | Responsible Party |
|-----------|----------|-------------------|
| Daily | Automated security scans | Security Team |
| Weekly | Vulnerability scans | Security Team |
| Monthly | Access reviews, backup tests | IT Operations |
| Quarterly | Control self-assessments | Compliance Team |
| Annually | Penetration test, DR test | Third-party + Internal |
| Continuous | Monitoring, alerting | Security Operations |

---

## Evidence Repository

All evidence is stored in:
- **GitHub**: Code, configurations, CI/CD pipelines
- **Google Drive**: Policies, procedures, training records
- **Vanta/Drata**: Automated evidence collection
- **AWS**: Infrastructure configurations, logs

---

## Audit Trail

| Date | Change | Author | Approved By |
|------|--------|--------|-------------|
| 2025-01-01 | Initial document | CISO | CEO |
