# Infamous Freight

AI-Native Freight Management Platform for Modern Fleets

[![Version](https://img.shields.io/badge/version-2.2.0-blue.svg)](https://github.com/infamousfreight/infamous-freight)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Node](https://img.shields.io/badge/node-%3E%3D20.0.0-brightgreen.svg)](https://nodejs.org)

## Overview

Infamous Freight is a comprehensive freight management platform built for modern trucking operations. It combines AI-powered load matching, real-time tracking, automated dispatch, and financial management in a single, intuitive interface.

## Features

- **AI-Powered Load Matching**: Intelligent recommendations to maximize truck utilization
- **Real-Time Tracking**: GPS-enabled shipment tracking with ETA predictions
- **Route Optimization**: AI-driven route planning to minimize costs
- **Driver Management**: HOS compliance, performance tracking, and scheduling
- **Fleet Management**: Vehicle tracking, maintenance scheduling, and utilization analytics
- **Financial Management**: Invoicing, payment tracking, and revenue analytics
- **WebSocket Real-Time Updates**: Live notifications and tracking updates
- **Webhook Integrations**: Connect with external systems and services

## Tech Stack

### Backend
- **Runtime**: Node.js 20+
- **Framework**: Express.js 5.2
- **Database**: PostgreSQL 16 with Prisma 7.3 ORM
- **Cache**: Redis 7
- **Authentication**: JWT with refresh tokens
- **Real-time**: WebSocket (ws)
- **AI Integration**: OpenAI GPT-4

### Frontend
- **Framework**: Next.js 16 (App Router)
- **UI Library**: Chakra UI 2.8
- **State Management**: Zustand
- **Data Fetching**: TanStack Query (React Query)
- **Forms**: React Hook Form with Zod validation
- **Charts**: Recharts

### Infrastructure
- **Containerization**: Docker & Docker Compose
- **Package Manager**: pnpm
- **Build Tool**: Turbo
- **Testing**: Jest + Supertest

## Quick Start

### Prerequisites

- Node.js 20+
- pnpm 8+
- Docker & Docker Compose (optional)

### Installation

1. Clone the repository:
```bash
git clone https://github.com/infamousfreight/infamous-freight.git
cd infamous-freight
```

2. Install dependencies:
```bash
pnpm install
```

3. Set up environment variables:
```bash
cp .env.example .env
# Edit .env with your configuration
```

4. Start the database:
```bash
docker-compose up -d postgres redis
```

5. Run database migrations:
```bash
pnpm db:migrate
```

6. Seed the database:
```bash
pnpm db:seed
```

7. Start the development servers:
```bash
pnpm dev
```

The application will be available at:
- Web: http://localhost:3000
- API: http://localhost:4000
- API Docs: http://localhost:4000/api/docs

### Docker Compose (Full Stack)

To run the entire stack with Docker Compose:

```bash
docker-compose up -d
```

This will start:
- PostgreSQL database
- Redis cache
- API server
- Web frontend
- MinIO (S3-compatible storage)
- Mailhog (email testing)

## Project Structure

```
infamous-freight/
├── apps/
│   ├── api/                 # Express.js API server
│   │   ├── src/
│   │   │   ├── routes/      # API route handlers
│   │   │   ├── middleware/  # Express middleware
│   │   │   ├── websocket/   # WebSocket handlers
│   │   │   └── utils/       # Utility functions
│   │   └── Dockerfile
│   └── web/                 # Next.js frontend
│       ├── src/
│       │   ├── app/         # Next.js app router
│       │   ├── components/  # React components
│       │   ├── store/       # Zustand stores
│       │   ├── lib/         # Utility functions
│       │   └── types/       # TypeScript types
│       └── Dockerfile
├── packages/
│   └── shared/              # Shared types and utilities
├── prisma/
│   ├── schema.prisma        # Database schema
│   └── seed.ts              # Database seed script
├── docker-compose.yml       # Docker Compose configuration
├── turbo.json               # Turbo configuration
└── package.json             # Root package.json
```

## Environment Variables

### Required

| Variable | Description | Default |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | - |
| `REDIS_URL` | Redis connection string | - |
| `JWT_SECRET` | Secret for JWT signing | - |

### Optional

| Variable | Description | Default |
|----------|-------------|---------|
| `NODE_ENV` | Environment mode | `development` |
| `API_PORT` | API server port | `4000` |
| `WEB_PORT` | Web server port | `3000` |
| `OPENAI_API_KEY` | OpenAI API key | - |
| `STRIPE_SECRET_KEY` | Stripe API key | - |

## API Documentation

The API is documented at `/api/docs` when running the server. Key endpoints:

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login
- `POST /api/auth/refresh` - Refresh access token
- `POST /api/auth/logout` - Logout

### Shipments
- `GET /api/shipments` - List shipments
- `POST /api/shipments` - Create shipment
- `GET /api/shipments/:id` - Get shipment details
- `PATCH /api/shipments/:id` - Update shipment
- `POST /api/shipments/:id/assign` - Assign driver/vehicle
- `POST /api/shipments/:id/status` - Update status

### Drivers
- `GET /api/drivers` - List drivers
- `POST /api/drivers` - Create driver
- `GET /api/drivers/:id` - Get driver details
- `GET /api/drivers/:id/hos` - Get HOS logs
- `GET /api/drivers/:id/performance` - Get performance metrics

### Vehicles
- `GET /api/vehicles` - List vehicles
- `POST /api/vehicles` - Create vehicle
- `GET /api/vehicles/:id` - Get vehicle details
- `GET /api/vehicles/:id/maintenance` - Get maintenance records

### Invoices
- `GET /api/invoices` - List invoices
- `POST /api/invoices` - Create invoice
- `POST /api/invoices/:id/send` - Send invoice
- `POST /api/invoices/:id/payments` - Record payment

### Tracking
- `GET /api/tracking/shipments/:id` - Get tracking history
- `GET /api/tracking/active` - Get active shipment locations
- `POST /api/tracking/checkin` - Manual check-in

### AI
- `POST /api/ai/load-recommendation` - Get load recommendations
- `POST /api/ai/route-optimization` - Optimize route
- `POST /api/ai/command` - Process natural language command

## Testing

### Run all tests
```bash
pnpm test
```

### Run tests with coverage
```bash
pnpm test:coverage
```

### Run tests for specific package
```bash
pnpm --filter @infamous-freight/api test
```

## Database

### Generate Prisma client
```bash
pnpm prisma:generate
```

### Run migrations
```bash
pnpm db:migrate
```

### Open Prisma Studio
```bash
pnpm prisma:studio
```

### Seed database
```bash
pnpm db:seed
```

## Deployment

### Production Build

1. Build all packages:
```bash
pnpm build
```

2. Start production servers:
```bash
pnpm start
```

### Docker Deployment

Build and push Docker images:
```bash
docker-compose -f docker-compose.prod.yml build
docker-compose -f docker-compose.prod.yml push
```

Deploy to production:
```bash
docker-compose -f docker-compose.prod.yml up -d
```

## Demo Credentials

- **Email**: admin@infamousfreight.com
- **Password**: demo123

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support, email support@infamousfreight.com or join our Slack channel.

## Roadmap

- [ ] Mobile app (React Native)
- [ ] ELD integrations
- [ ] Fuel card integration
- [ ] Document scanning with OCR
- [ ] Advanced analytics with ML
- [ ] Multi-language support
- [ ] White-label solution

---

Built with ❤️ by the Infamous Freight Team
