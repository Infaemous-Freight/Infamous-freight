# Infamous Freight Bug Bounty Program

## Program Overview

We value the security community's efforts in helping us maintain a secure platform. This bug bounty program rewards security researchers who identify and report vulnerabilities in our systems.

## Scope

### In-Scope Assets

- **Web Application**: https://app.infamousfreight.com
- **API Endpoints**: https://api.infamousfreight.com
- **Mobile Applications**: iOS and Android apps
- **Infrastructure**: *.infamousfreight.com

### Out-of-Scope

- Third-party services and integrations
- Social engineering attacks
- Physical security
- Denial of Service (DoS) attacks
- Rate limiting bypasses (unless they lead to data exposure)

## Reward Structure

| Severity | Reward Range | Examples |
|----------|--------------|----------|
| Critical | $5,000 - $15,000 | RCE, SQL Injection, Authentication bypass, Data breach |
| High | $2,000 - $5,000 | XSS leading to account takeover, IDOR exposing sensitive data |
| Medium | $500 - $2,000 | CSRF, Information disclosure, Business logic flaws |
| Low | $100 - $500 | Missing security headers, Verbose error messages |

### Bonus Rewards

- **Complete Account Takeover**: +$2,000
- **Data Exfiltration**: +$3,000
- **Chain Exploits**: Up to 2x base reward

## Reporting Process

### How to Submit

1. **Email**: security@infamousfreight.com
2. **Subject**: `[Bug Bounty] <Brief Description>`
3. **PGP Key**: Available at https://infamousfreight.com/pgp-key.txt

### Required Information

- Detailed description of the vulnerability
- Step-by-step reproduction instructions
- Proof of concept (screenshots, videos, code)
- Impact assessment
- Suggested fix (optional)
- Your HackerOne/Bugcrowd handle (if applicable)

### Response Timeline

| Stage | Timeline |
|-------|----------|
| Initial Response | 24 hours |
| Triage | 3-5 business days |
| Bounty Decision | 7-10 business days |
| Fix Deployment | 30-90 days |
| Public Disclosure | After fix deployment |

## Rules of Engagement

### Allowed

- Automated scanning tools (with rate limiting)
- Manual testing and exploration
- Creating test accounts
- Testing on your own data

### Prohibited

- Accessing or modifying other users' data
- Disrupting service availability
- Social engineering or phishing
- Physical attacks on infrastructure
- Extortion or blackmail
- Public disclosure before fix

## Safe Harbor

We commit to:

- Not pursue legal action for good-faith security research
- Not suspend your account for testing within scope
- Work with you to understand and fix reported issues
- Publicly acknowledge your contribution (with your consent)

## Hall of Fame

Researchers who have responsibly disclosed vulnerabilities:

| Researcher | Finding | Date |
|------------|---------|------|
| [Your name here] | - | - |

## Contact

- **Security Team**: security@infamousfreight.com
- **Emergency**: +1-555-SECURITY
- **GPG Fingerprint**: `ABCD 1234 5678 90EF GHIJ 1234 5678 90AB CDEF 1234`

## Program Updates

This program may be updated periodically. Check back for the latest version.

**Last Updated**: 2025-01-01
**Program Version**: 1.0
