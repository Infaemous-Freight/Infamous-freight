// Shared types and utilities for Infamous Freight

// Enums
export enum UserRole {
  ADMIN = 'ADMIN',
  MANAGER = 'MANAGER',
  DISPATCHER = 'DISPATCHER',
  DRIVER = 'DRIVER',
  ACCOUNTANT = 'ACCOUNTANT',
}

export enum UserStatus {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE',
  SUSPENDED = 'SUSPENDED',
}

export enum ShipmentStatus {
  PENDING = 'PENDING',
  DISPATCHED = 'DISPATCHED',
  AT_PICKUP = 'AT_PICKUP',
  PICKED_UP = 'PICKED_UP',
  IN_TRANSIT = 'IN_TRANSIT',
  AT_DROPOFF = 'AT_DROPOFF',
  DELIVERED = 'DELIVERED',
  CANCELLED = 'CANCELLED',
}

export enum DriverStatus {
  AVAILABLE = 'AVAILABLE',
  ON_DUTY = 'ON_DUTY',
  OFF_DUTY = 'OFF_DUTY',
  IN_TRANSIT = 'IN_TRANSIT',
  SLEEPER_BERTH = 'SLEEPER_BERTH',
}

export enum VehicleStatus {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE',
  MAINTENANCE = 'MAINTENANCE',
  RETIRED = 'RETIRED',
}

export enum VehicleType {
  TRACTOR = 'TRACTOR',
  STRAIGHT_TRUCK = 'STRAIGHT_TRUCK',
  VAN = 'VAN',
  REEFER = 'REEFER',
  FLATBED = 'FLATBED',
  TANKER = 'TANKER',
  CAR_HAULER = 'CAR_HAULER',
  OTHER = 'OTHER',
}

export enum InvoiceStatus {
  DRAFT = 'DRAFT',
  SENT = 'SENT',
  PARTIAL = 'PARTIAL',
  PAID = 'PAID',
  OVERDUE = 'OVERDUE',
  CANCELLED = 'CANCELLED',
}

export enum PaymentMethod {
  CASH = 'CASH',
  CHECK = 'CHECK',
  ACH = 'ACH',
  CREDIT_CARD = 'CREDIT_CARD',
  DEBIT_CARD = 'DEBIT_CARD',
  WIRE = 'WIRE',
  FACTORING = 'FACTORING',
}

export enum WebhookEvent {
  SHIPMENT_CREATED = 'SHIPMENT_CREATED',
  SHIPMENT_UPDATED = 'SHIPMENT_UPDATED',
  SHIPMENT_DELIVERED = 'SHIPMENT_DELIVERED',
  DRIVER_CREATED = 'DRIVER_CREATED',
  DRIVER_UPDATED = 'DRIVER_UPDATED',
  VEHICLE_CREATED = 'VEHICLE_CREATED',
  VEHICLE_UPDATED = 'VEHICLE_UPDATED',
  INVOICE_CREATED = 'INVOICE_CREATED',
  INVOICE_PAID = 'INVOICE_PAID',
  TRACKING_UPDATE = 'TRACKING_UPDATE',
}

// Interfaces
export interface Organization {
  id: string;
  name: string;
  email: string;
  phone?: string;
  address?: string;
  city?: string;
  state?: string;
  zip?: string;
  country: string;
  timezone: string;
  currency: string;
  status: 'ACTIVE' | 'INACTIVE' | 'SUSPENDED';
  plan: 'FREE' | 'STARTER' | 'PROFESSIONAL' | 'ENTERPRISE';
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  status: UserStatus;
  phone?: string;
  emailVerified: boolean;
  lastLoginAt?: Date;
  organizationId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Driver {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  cdlNumber: string;
  cdlState: string;
  cdlExpiration: Date;
  cdlClass?: string;
  medicalExpiration?: Date;
  status: DriverStatus;
  hireDate?: Date;
  terminationDate?: Date;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  address?: string;
  city?: string;
  state?: string;
  zip?: string;
  dateOfBirth?: Date;
  notes?: string;
  userId?: string;
  organizationId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Vehicle {
  id: string;
  unitNumber: string;
  type: VehicleType;
  make: string;
  model: string;
  year: number;
  vin: string;
  licensePlate: string;
  licensePlateState: string;
  status: VehicleStatus;
  gvw?: number;
  fuelType?: string;
  color?: string;
  currentMileage?: number;
  registrationExpiration?: Date;
  insuranceExpiration?: Date;
  iftaStatus: boolean;
  eldDeviceId?: string;
  gpsDeviceId?: string;
  notes?: string;
  organizationId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Shipment {
  id: string;
  referenceNumber: string;
  customerName: string;
  customerEmail?: string;
  customerPhone?: string;
  customerAddress?: string;
  customerCity?: string;
  customerState?: string;
  customerZip?: string;
  status: ShipmentStatus;
  equipmentType: string;
  weight?: number;
  length?: number;
  width?: number;
  height?: number;
  commodity?: string;
  hazmat: boolean;
  hazmatClass?: string;
  temperature?: number;
  rate?: number;
  rateType: 'PER_MILE' | 'FLAT' | 'PER_HOUR' | 'TON';
  distance?: number;
  totalMiles?: number;
  estimatedFuelCost?: number;
  actualFuelCost?: number;
  origin: string;
  originAddress?: string;
  originCity: string;
  originState: string;
  originZip?: string;
  originLatitude?: number;
  originLongitude?: number;
  destination: string;
  destinationAddress?: string;
  destinationCity: string;
  destinationState: string;
  destinationZip?: string;
  destinationLatitude?: number;
  destinationLongitude?: number;
  scheduledPickupDate?: Date;
  scheduledDeliveryDate?: Date;
  actualPickupDate?: Date;
  actualDeliveryDate?: Date;
  driverId?: string;
  vehicleId?: string;
  organizationId: string;
  currentLatitude?: number;
  currentLongitude?: number;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Stop {
  id: string;
  shipmentId: string;
  sequence: number;
  type: 'PICKUP' | 'DROPOFF' | 'WAYPOINT';
  name?: string;
  address?: string;
  city: string;
  state: string;
  zip?: string;
  latitude: number;
  longitude: number;
  scheduledArrival?: Date;
  scheduledDeparture?: Date;
  actualArrival?: Date;
  actualDeparture?: Date;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  shipmentId: string;
  organizationId: string;
  invoiceDate: Date;
  dueDate: Date;
  status: InvoiceStatus;
  lineItems: any[];
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  totalAmount: number;
  amountPaid: number;
  balanceDue: number;
  notes?: string;
  terms?: string;
  sentAt?: Date;
  paidAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

// Utility functions
export function generateReferenceNumber(prefix: string = 'SHP'): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 5).toUpperCase();
  return `${prefix}-${timestamp}-${random}`;
}

export function generateInvoiceNumber(count: number): string {
  const prefix = 'INV';
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const sequence = (count + 1).toString().padStart(4, '0');
  return `${prefix}-${date}-${sequence}`;
}

export function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 3959; // Earth's radius in miles
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
      Math.cos(toRadians(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRadians(degrees: number): number {
  return degrees * (Math.PI / 180);
}

export function formatCurrency(amount: number, currency: string = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
  }).format(amount);
}

export function formatDate(date: Date | string, format: string = 'yyyy-MM-dd'): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toISOString().split('T')[0];
}

export function isValidEmail(email: string): boolean {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

export function isValidPhone(phone: string): boolean {
  const cleaned = phone.replace(/\D/g, '');
  return cleaned.length === 10;
}

export function truncate(str: string, length: number): string {
  if (str.length <= length) return str;
  return str.slice(0, length) + '...';
}

// Constants
export const US_STATES = [
  { code: 'AL', name: 'Alabama' },
  { code: 'AK', name: 'Alaska' },
  { code: 'AZ', name: 'Arizona' },
  { code: 'AR', name: 'Arkansas' },
  { code: 'CA', name: 'California' },
  { code: 'CO', name: 'Colorado' },
  { code: 'CT', name: 'Connecticut' },
  { code: 'DE', name: 'Delaware' },
  { code: 'FL', name: 'Florida' },
  { code: 'GA', name: 'Georgia' },
  { code: 'HI', name: 'Hawaii' },
  { code: 'ID', name: 'Idaho' },
  { code: 'IL', name: 'Illinois' },
  { code: 'IN', name: 'Indiana' },
  { code: 'IA', name: 'Iowa' },
  { code: 'KS', name: 'Kansas' },
  { code: 'KY', name: 'Kentucky' },
  { code: 'LA', name: 'Louisiana' },
  { code: 'ME', name: 'Maine' },
  { code: 'MD', name: 'Maryland' },
  { code: 'MA', name: 'Massachusetts' },
  { code: 'MI', name: 'Michigan' },
  { code: 'MN', name: 'Minnesota' },
  { code: 'MS', name: 'Mississippi' },
  { code: 'MO', name: 'Missouri' },
  { code: 'MT', name: 'Montana' },
  { code: 'NE', name: 'Nebraska' },
  { code: 'NV', name: 'Nevada' },
  { code: 'NH', name: 'New Hampshire' },
  { code: 'NJ', name: 'New Jersey' },
  { code: 'NM', name: 'New Mexico' },
  { code: 'NY', name: 'New York' },
  { code: 'NC', name: 'North Carolina' },
  { code: 'ND', name: 'North Dakota' },
  { code: 'OH', name: 'Ohio' },
  { code: 'OK', name: 'Oklahoma' },
  { code: 'OR', name: 'Oregon' },
  { code: 'PA', name: 'Pennsylvania' },
  { code: 'RI', name: 'Rhode Island' },
  { code: 'SC', name: 'South Carolina' },
  { code: 'SD', name: 'South Dakota' },
  { code: 'TN', name: 'Tennessee' },
  { code: 'TX', name: 'Texas' },
  { code: 'UT', name: 'Utah' },
  { code: 'VT', name: 'Vermont' },
  { code: 'VA', name: 'Virginia' },
  { code: 'WA', name: 'Washington' },
  { code: 'WV', name: 'West Virginia' },
  { code: 'WI', name: 'Wisconsin' },
  { code: 'WY', name: 'Wyoming' },
];

export const EQUIPMENT_TYPES = [
  'Dry Van',
  'Reefer',
  'Flatbed',
  'Step Deck',
  'Lowboy',
  'Tanker',
  'Box Truck',
  'Power Only',
  'Hotshot',
  'Auto Carrier',
  'Conestoga',
  'RGN',
  'Other',
];
