#!/bin/bash

# Infamous Freight Development Setup Script
# Usage: ./scripts/setup.sh

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Infamous Freight Development Setup${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check prerequisites
echo -e "${YELLOW}Checking prerequisites...${NC}"

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}Error: Node.js is not installed${NC}"
    echo "Please install Node.js 20+ from https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
    echo -e "${RED}Error: Node.js 20+ is required (found $(node --version))${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Node.js $(node --version)${NC}"

# Check pnpm
if ! command -v pnpm &> /dev/null; then
    echo -e "${YELLOW}Installing pnpm...${NC}"
    npm install -g pnpm@9.15.0
fi

echo -e "${GREEN}✓ pnpm $(pnpm --version)${NC}"

# Check Docker
if ! command -v docker &> /dev/null; then
    echo -e "${YELLOW}Warning: Docker is not installed (optional for local development)${NC}"
else
    echo -e "${GREEN}✓ Docker $(docker --version)${NC}"
fi

# Check Docker Compose
if ! command -v docker-compose &> /dev/null; then
    echo -e "${YELLOW}Warning: Docker Compose is not installed (optional)${NC}"
else
    echo -e "${GREEN}✓ Docker Compose $(docker-compose --version)${NC}"
fi

echo ""
echo -e "${YELLOW}Installing dependencies...${NC}"
pnpm install

echo ""
echo -e "${YELLOW}Setting up environment files...${NC}"

# Create .env files if they don't exist
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo -e "${GREEN}✓ Created .env (please update with your values)${NC}"
fi

if [ ! -f ".env.local" ]; then
    cp .env.example .env.local
    echo -e "${GREEN}✓ Created .env.local${NC}"
fi

echo ""
echo -e "${YELLOW}Generating Prisma client...${NC}"
pnpm prisma generate

echo ""
echo -e "${YELLOW}Setting up database...${NC}"

# Ask if user wants to start Docker services
read -p "Start Docker services (PostgreSQL, Redis)? (Y/n) " -n 1 -r
echo

if [[ $REPLY =~ ^[Yy]$ ]] || [[ -z $REPLY ]]; then
    echo -e "${BLUE}Starting Docker services...${NC}"
    docker-compose up -d postgres redis
    
    # Wait for services to be ready
    echo -e "${YELLOW}Waiting for services to be ready...${NC}"
    sleep 5
    
    # Run migrations
    echo -e "${YELLOW}Running database migrations...${NC}"
    pnpm prisma migrate dev
    
    # Seed database
    read -p "Seed database with demo data? (Y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]] || [[ -z $REPLY ]]; then
        echo -e "${YELLOW}Seeding database...${NC}"
        pnpm prisma db seed
    fi
else
    echo -e "${YELLOW}Skipping Docker setup. You'll need to configure your own database.${NC}"
fi

echo ""
echo -e "${YELLOW}Building packages...${NC}"
pnpm build:shared

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  Setup Complete!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${BLUE}Next steps:${NC}"
echo ""
echo "1. Update your .env file with your configuration:"
echo "   - Database connection"
echo "   - JWT secrets"
echo "   - API keys (OpenAI, Stripe, etc.)"
echo ""
echo "2. Start the development servers:"
echo "   pnpm dev"
echo ""
echo "3. Or start services individually:"
echo "   pnpm dev:api    # API server only"
echo "   pnpm dev:web    # Web app only"
echo ""
echo "4. Access the application:"
echo "   - Web: http://localhost:3000"
echo "   - API: http://localhost:4000"
echo "   - API Docs: http://localhost:4000/api/docs"
echo ""
echo "5. Demo credentials:"
echo "   Email: admin@infamousfreight.com"
echo "   Password: demo123"
echo ""
echo -e "${BLUE}Happy coding! 🚀${NC}"
