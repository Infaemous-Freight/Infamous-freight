#!/bin/bash

# Infamous Freight Deployment Script
# Usage: ./deploy.sh [environment] [version]
# Example: ./deploy.sh production v2.2.0

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
ENVIRONMENT=${1:-staging}
VERSION=${2:-latest}
PROJECT_NAME="infamous-freight"

# Validate environment
if [[ ! "$ENVIRONMENT" =~ ^(staging|production)$ ]]; then
    echo -e "${RED}Error: Environment must be 'staging' or 'production'${NC}"
    exit 1
fi

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Infamous Freight Deployment${NC}"
echo -e "${BLUE}  Environment: $ENVIRONMENT${NC}"
echo -e "${BLUE}  Version: $VERSION${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Pre-deployment checks
echo -e "${YELLOW}Running pre-deployment checks...${NC}"

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo -e "${RED}Error: Must run from project root directory${NC}"
    exit 1
fi

# Check if required tools are installed
command -v pnpm >/dev/null 2>&1 || { echo -e "${RED}Error: pnpm is required${NC}"; exit 1; }
command -v docker >/dev/null 2>&1 || { echo -e "${RED}Error: docker is required${NC}"; exit 1; }

# Load environment variables
if [ -f ".env.$ENVIRONMENT" ]; then
    echo -e "${GREEN}Loading environment variables from .env.$ENVIRONMENT${NC}"
    export $(cat .env.$ENVIRONMENT | grep -v '^#' | xargs)
else
    echo -e "${YELLOW}Warning: .env.$ENVIRONMENT not found, using existing environment${NC}"
fi

# Run tests
echo ""
echo -e "${YELLOW}Running tests...${NC}"
pnpm test

if [ $? -ne 0 ]; then
    echo -e "${RED}Tests failed! Aborting deployment.${NC}"
    exit 1
fi

echo -e "${GREEN}All tests passed!${NC}"

# Build applications
echo ""
echo -e "${YELLOW}Building applications...${NC}"
pnpm build

if [ $? -ne 0 ]; then
    echo -e "${RED}Build failed! Aborting deployment.${NC}"
    exit 1
fi

echo -e "${GREEN}Build successful!${NC}"

# Database migrations
echo ""
echo -e "${YELLOW}Running database migrations...${NC}"
pnpm prisma migrate deploy

if [ $? -ne 0 ]; then
    echo -e "${RED}Database migration failed!${NC}"
    read -p "Continue with deployment? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Deploy based on environment
echo ""
echo -e "${YELLOW}Deploying to $ENVIRONMENT...${NC}"

if [ "$ENVIRONMENT" == "staging" ]; then
    # Deploy to staging
    echo -e "${BLUE}Deploying API to Fly.io (Staging)...${NC}"
    flyctl deploy --config fly.staging.toml --remote-only
    
    echo -e "${BLUE}Deploying Web to Vercel (Staging)...${NC}"
    vercel --target=preview
    
elif [ "$ENVIRONMENT" == "production" ]; then
    # Production deployment with confirmation
    echo -e "${RED}WARNING: You are about to deploy to PRODUCTION!${NC}"
    read -p "Are you sure? Type 'deploy' to confirm: " confirm
    
    if [ "$confirm" != "deploy" ]; then
        echo -e "${YELLOW}Deployment cancelled.${NC}"
        exit 0
    fi
    
    # Create git tag
    if [ "$VERSION" != "latest" ]; then
        echo -e "${BLUE}Creating git tag $VERSION...${NC}"
        git tag -a "$VERSION" -m "Release $VERSION"
        git push origin "$VERSION"
    fi
    
    # Deploy API
    echo -e "${BLUE}Deploying API to Fly.io (Production)...${NC}"
    flyctl deploy --config fly.toml --remote-only
    
    # Deploy Web
    echo -e "${BLUE}Deploying Web to Vercel (Production)...${NC}"
    vercel --prod
    
    # Create Sentry release
    echo -e "${BLUE}Creating Sentry release...${NC}"
    if command -v sentry-cli &> /dev/null; then
        sentry-cli releases new "$VERSION"
        sentry-cli releases set-commits "$VERSION" --auto
        sentry-cli releases finalize "$VERSION"
    fi
fi

# Health check
echo ""
echo -e "${YELLOW}Running health checks...${NC}"

if [ "$ENVIRONMENT" == "staging" ]; then
    HEALTH_URL="https://api-staging.infamousfreight.com/api/health"
else
    HEALTH_URL="https://api.infamousfreight.com/api/health"
fi

# Wait for deployment to be ready
sleep 10

# Check health endpoint
for i in {1..5}; do
    response=$(curl -s -o /dev/null -w "%{http_code}" "$HEALTH_URL" || echo "000")
    if [ "$response" == "200" ]; then
        echo -e "${GREEN}Health check passed!${NC}"
        break
    else
        echo -e "${YELLOW}Health check attempt $i failed (status: $response), retrying...${NC}"
        sleep 5
    fi
done

if [ "$response" != "200" ]; then
    echo -e "${RED}Health check failed after 5 attempts!${NC}"
    echo -e "${RED}Consider rolling back!${NC}"
    exit 1
fi

# Post-deployment verification
echo ""
echo -e "${YELLOW}Running post-deployment verification...${NC}"

# Run smoke tests
if [ -f "scripts/smoke-tests.sh" ]; then
    ./scripts/smoke-tests.sh "$ENVIRONMENT"
fi

# Clear CDN cache if applicable
if [ "$ENVIRONMENT" == "production" ]; then
    echo -e "${BLUE}Clearing CDN cache...${NC}"
    # Add CDN cache invalidation here
fi

# Notify team
echo ""
echo -e "${BLUE}Sending deployment notification...${NC}"

# Slack notification (if webhook configured)
if [ -n "$SLACK_WEBHOOK_URL" ]; then
    curl -X POST -H 'Content-type: application/json' \
        --data "{\"text\":\"✅ Deployment successful: $PROJECT_NAME $VERSION to $ENVIRONMENT\"}" \
        "$SLACK_WEBHOOK_URL" || true
fi

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  Deployment Complete!${NC}"
echo -e "${GREEN}  Environment: $ENVIRONMENT${NC}"
echo -e "${GREEN}  Version: $VERSION${NC}"
echo -e "${GREEN}========================================${NC}"

# Print useful links
echo ""
echo -e "${BLUE}Useful Links:${NC}"
if [ "$ENVIRONMENT" == "staging" ]; then
    echo "  - App: https://staging.infamousfreight.com"
    echo "  - API: https://api-staging.infamousfreight.com"
    echo "  - Logs: https://fly.io/apps/infamous-freight-staging"
else
    echo "  - App: https://infamousfreight.com"
    echo "  - API: https://api.infamousfreight.com"
    echo "  - Logs: https://fly.io/apps/infamous-freight"
    echo "  - Sentry: https://sentry.io/organizations/infamous-freight"
    echo "  - Analytics: https://analytics.infamousfreight.com"
fi

exit 0
