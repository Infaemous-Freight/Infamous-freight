#!/bin/bash

# Infamous Freight Rollback Script
# Usage: ./rollback.sh [environment] [version]

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

ENVIRONMENT=${1:-staging}
VERSION=${2:-}

echo -e "${RED}========================================${NC}"
echo -e "${RED}  EMERGENCY ROLLBACK${NC}"
echo -e "${RED}  Environment: $ENVIRONMENT${NC}"
echo -e "${RED}========================================${NC}"
echo ""

# Confirm rollback
read -p "Are you sure you want to rollback? Type 'rollback' to confirm: " confirm

if [ "$confirm" != "rollback" ]; then
    echo -e "${YELLOW}Rollback cancelled.${NC}"
    exit 0
fi

if [ "$ENVIRONMENT" == "staging" ]; then
    echo -e "${YELLOW}Rolling back staging...${NC}"
    flyctl deploy --config fly.staging.toml --image infamous-freight-staging:previous
    vercel --target=preview --rollback
    
elif [ "$ENVIRONMENT" == "production" ]; then
    echo -e "${RED}Rolling back production...${NC}"
    
    if [ -n "$VERSION" ]; then
        # Rollback to specific version
        echo -e "${BLUE}Rolling back to version $VERSION...${NC}"
        git checkout "$VERSION"
        flyctl deploy --config fly.toml --remote-only
        vercel --prod
    else
        # Rollback to previous deployment
        echo -e "${BLUE}Rolling back to previous deployment...${NC}"
        flyctl deploy --config fly.toml --image infamous-freight:previous
        vercel --prod --rollback
    fi
fi

# Verify rollback
echo ""
echo -e "${YELLOW}Verifying rollback...${NC}"
sleep 10

if [ "$ENVIRONMENT" == "staging" ]; then
    HEALTH_URL="https://api-staging.infamousfreight.com/api/health"
else
    HEALTH_URL="https://api.infamousfreight.com/api/health"
fi

response=$(curl -s -o /dev/null -w "%{http_code}" "$HEALTH_URL" || echo "000")

if [ "$response" == "200" ]; then
    echo -e "${GREEN}Rollback verified successfully!${NC}"
else
    echo -e "${RED}Rollback verification failed! Manual intervention required.${NC}"
    exit 1
fi

# Notify team
echo ""
echo -e "${BLUE}Sending rollback notification...${NC}"

if [ -n "$SLACK_WEBHOOK_URL" ]; then
    curl -X POST -H 'Content-type: application/json' \
        --data "{\"text\":\"🚨 ROLLBACK EXECUTED: Infamous Freight $ENVIRONMENT rolled back to $VERSION\"}" \
        "$SLACK_WEBHOOK_URL" || true
fi

echo ""
echo -e "${GREEN}Rollback complete!${NC}"
