import { PrismaClient, Plan, UserRole, DriverStatus, VehicleStatus, ShipmentStatus } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seed...');

  // Create demo organization
  const org = await prisma.organization.create({
    data: {
      name: 'Demo Trucking LLC',
      slug: 'demo-trucking',
      plan: Plan.PRO,
    },
  });

  console.log(`✅ Created organization: ${org.name}`);

  // Create demo users
  const hashedPassword = await bcrypt.hash('demo123', 10);

  const adminUser = await prisma.user.create({
    data: {
      email: 'admin@infamousfreight.com',
      password: hashedPassword,
      name: 'Admin User',
      role: UserRole.ADMIN,
      organizationId: org.id,
      referralCode: 'IFFADMIN001',
    },
  });

  const driverUser = await prisma.user.create({
    data: {
      email: 'driver@infamousfreight.com',
      password: hashedPassword,
      name: 'Demo Driver',
      role: UserRole.DRIVER,
      organizationId: org.id,
      referralCode: 'IFFDRIVER001',
    },
  });

  console.log(`✅ Created users: ${adminUser.email}, ${driverUser.email}`);

  // Create driver profile
  const driver = await prisma.driver.create({
    data: {
      userId: driverUser.id,
      licenseNumber: 'CDL12345678',
      phone: '+1-555-0101',
      status: DriverStatus.AVAILABLE,
      currentLocation: 'Chicago, IL',
      currentLatitude: 41.8781,
      currentLongitude: -87.6298,
      rating: 4.8,
      totalMiles: 150000,
      organizationId: org.id,
    },
  });

  console.log(`✅ Created driver: ${driver.licenseNumber}`);

  // Create vehicles
  const vehicle1 = await prisma.vehicle.create({
    data: {
      vin: '1HGBH41JXMN109186',
      make: 'Freightliner',
      model: 'Cascadia',
      year: 2022,
      plateNumber: 'IL-TRUCK1',
      status: VehicleStatus.ACTIVE,
      mileage: 150000,
      driverId: driver.id,
      organizationId: org.id,
    },
  });

  const vehicle2 = await prisma.vehicle.create({
    data: {
      vin: '1HGBH41JXMN109187',
      make: 'Peterbilt',
      model: '579',
      year: 2023,
      plateNumber: 'TX-TRUCK2',
      status: VehicleStatus.ACTIVE,
      mileage: 89000,
      organizationId: org.id,
    },
  });

  console.log(`✅ Created vehicles: ${vehicle1.plateNumber}, ${vehicle2.plateNumber}`);

  // Create shipments
  const shipment1 = await prisma.shipment.create({
    data: {
      bolNumber: 'BOL-2025-001',
      shipperName: 'ABC Manufacturing',
      shipperAddress: '123 Industrial Way',
      shipperCity: 'Chicago',
      shipperState: 'IL',
      shipperZip: '60601',
      consigneeName: 'XYZ Distribution',
      consigneeAddress: '456 Commerce St',
      consigneeCity: 'Detroit',
      consigneeState: 'MI',
      consigneeZip: '48201',
      pickupLatitude: 41.8781,
      pickupLongitude: -87.6298,
      deliveryLatitude: 42.3314,
      deliveryLongitude: -83.0458,
      pickupDate: new Date('2025-03-01T08:00:00Z'),
      deliveryDate: new Date('2025-03-01T16:00:00Z'),
      status: ShipmentStatus.IN_TRANSIT,
      weight: 45000,
      distance: 283,
      rate: 850.00,
      driverId: driver.id,
      vehicleId: vehicle1.id,
      organizationId: org.id,
    },
  });

  const shipment2 = await prisma.shipment.create({
    data: {
      bolNumber: 'BOL-2025-002',
      shipperName: 'Global Foods Inc',
      shipperAddress: '789 Warehouse Blvd',
      shipperCity: 'Dallas',
      shipperState: 'TX',
      shipperZip: '75201',
      consigneeName: 'Fresh Market',
      consigneeAddress: '321 Grocery Lane',
      consigneeCity: 'Houston',
      consigneeState: 'TX',
      consigneeZip: '77001',
      pickupLatitude: 32.7767,
      pickupLongitude: -96.7970,
      deliveryLatitude: 29.7604,
      deliveryLongitude: -95.3698,
      pickupDate: new Date('2025-02-28T06:00:00Z'),
      deliveryDate: new Date('2025-02-28T14:00:00Z'),
      status: ShipmentStatus.DELIVERED,
      weight: 32000,
      distance: 240,
      rate: 620.00,
      organizationId: org.id,
    },
  });

  const shipment3 = await prisma.shipment.create({
    data: {
      bolNumber: 'BOL-2025-003',
      shipperName: 'Steel Works Co',
      shipperAddress: '555 Factory Rd',
      shipperCity: 'Pittsburgh',
      shipperState: 'PA',
      shipperZip: '15201',
      consigneeName: 'Construction Depot',
      consigneeAddress: '888 Building Ave',
      consigneeCity: 'Cleveland',
      consigneeState: 'OH',
      consigneeZip: '44101',
      pickupLatitude: 40.4406,
      pickupLongitude: -79.9959,
      deliveryLatitude: 41.4993,
      deliveryLongitude: -81.6944,
      pickupDate: new Date('2025-03-02T07:00:00Z'),
      deliveryDate: new Date('2025-03-02T18:00:00Z'),
      status: ShipmentStatus.PENDING,
      weight: 48000,
      distance: 135,
      rate: 450.00,
      organizationId: org.id,
    },
  });

  console.log(`✅ Created shipments: ${shipment1.bolNumber}, ${shipment2.bolNumber}, ${shipment3.bolNumber}`);

  // Create tracking events
  await prisma.trackingEvent.createMany({
    data: [
      {
        shipmentId: shipment1.id,
        eventType: 'PICKUP',
        location: 'Chicago, IL',
        latitude: 41.8781,
        longitude: -87.6298,
        notes: 'Load picked up on time',
      },
      {
        shipmentId: shipment1.id,
        eventType: 'IN_TRANSIT',
        location: 'Gary, IN',
        latitude: 41.5934,
        longitude: -87.3369,
        notes: 'Passing through Indiana',
      },
      {
        shipmentId: shipment2.id,
        eventType: 'PICKUP',
        location: 'Dallas, TX',
        latitude: 32.7767,
        longitude: -96.7970,
        notes: 'Load secured',
      },
      {
        shipmentId: shipment2.id,
        eventType: 'DELIVERED',
        location: 'Houston, TX',
        latitude: 29.7604,
        longitude: -95.3698,
        notes: 'Delivery completed successfully',
      },
    ],
  });

  console.log('✅ Created tracking events');

  // Create invoices
  await prisma.invoice.create({
    data: {
      invoiceNumber: 'INV-2025-001',
      amount: 620.00,
      totalAmount: 620.00,
      status: 'PAID',
      dueDate: new Date('2025-03-15'),
      paidDate: new Date('2025-03-10'),
      shipmentId: shipment2.id,
      organizationId: org.id,
    },
  });

  console.log('✅ Created invoice');

  console.log('\n🎉 Database seed completed successfully!');
  console.log('\nDemo credentials:');
  console.log('  Admin: admin@infamousfreight.com / demo123');
  console.log('  Driver: driver@infamousfreight.com / demo123');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
