import React, { useEffect, useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { Provider as PaperProvider } from 'react-native-paper';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import * as Notifications from 'expo-notifications';
import * as Location from 'expo-location';

import { RootNavigator } from './src/navigation/RootNavigator';
import { theme } from './src/theme';
import { useAuthStore } from './src/store/auth';
import { initBackgroundLocation } from './src/services/location';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,
      retry: 2,
    },
  },
});

export default function App() {
  const [isReady, setIsReady] = useState(false);
  const initializeAuth = useAuthStore((state) => state.initialize);

  useEffect(() => {
    async function prepare() {
      try {
        // Initialize auth
        await initializeAuth();

        // Request permissions
        const { status: notificationStatus } = await Notifications.requestPermissionsAsync();
        const { status: locationStatus } = await Location.requestForegroundPermissionsAsync();
        const { status: backgroundLocationStatus } = await Location.requestBackgroundPermissionsAsync();

        // Initialize background location tracking
        if (locationStatus === 'granted' && backgroundLocationStatus === 'granted') {
          await initBackgroundLocation();
        }

        // Setup notification listeners
        const notificationListener = Notifications.addNotificationReceivedListener(
          (notification) => {
            console.log('Notification received:', notification);
          }
        );

        const responseListener = Notifications.addNotificationResponseReceivedListener(
          (response) => {
            console.log('Notification response:', response);
          }
        );

        return () => {
          Notifications.removeNotificationSubscription(notificationListener);
          Notifications.removeNotificationSubscription(responseListener);
        };
      } catch (e) {
        console.warn(e);
      } finally {
        setIsReady(true);
      }
    }

    prepare();
  }, []);

  if (!isReady) {
    return null;
  }

  return (
    <SafeAreaProvider>
      <QueryClientProvider client={queryClient}>
        <PaperProvider theme={theme}>
          <NavigationContainer>
            <RootNavigator />
            <StatusBar style="auto" />
          </NavigationContainer>
        </PaperProvider>
      </QueryClientProvider>
    </SafeAreaProvider>
  );
}
