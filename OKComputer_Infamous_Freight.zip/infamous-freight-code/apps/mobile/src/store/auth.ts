import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';

import { graphqlClient, LOGIN_MUTATION } from '../api/graphql';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  organization: {
    id: string;
    name: string;
  };
}

interface AuthState {
  user: User | null;
  accessToken: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isInitializing: boolean;

  // Actions
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshAccessToken: () => Promise<void>;
  initialize: () => Promise<void>;
  setUser: (user: User) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      accessToken: null,
      refreshToken: null,
      isAuthenticated: false,
      isLoading: false,
      isInitializing: true,

      initialize: async () => {
        try {
          const refreshToken = await SecureStore.getItemAsync('refreshToken');
          if (refreshToken) {
            // Try to refresh the token
            await get().refreshAccessToken();
          }
        } catch (error) {
          console.error('Auth initialization failed:', error);
        } finally {
          set({ isInitializing: false });
        }
      },

      login: async (email: string, password: string) => {
        set({ isLoading: true });
        try {
          const result = await graphqlClient
            .mutation(LOGIN_MUTATION, { email, password })
            .toPromise();

          if (result.error) {
            throw new Error(result.error.message);
          }

          const { user, accessToken, refreshToken } = result.data!.login;

          // Store tokens securely
          await SecureStore.setItemAsync('accessToken', accessToken);
          await SecureStore.setItemAsync('refreshToken', refreshToken);

          set({
            user,
            accessToken,
            refreshToken,
            isAuthenticated: true,
            isLoading: false,
          });
        } catch (error) {
          set({ isLoading: false });
          throw error;
        }
      },

      logout: async () => {
        try {
          // Call logout mutation
          await graphqlClient.mutation(
            `
            mutation Logout {
              logout
            }
          `,
            {}
          ).toPromise();
        } catch (error) {
          console.error('Logout error:', error);
        } finally {
          // Clear stored tokens
          await SecureStore.deleteItemAsync('accessToken');
          await SecureStore.deleteItemAsync('refreshToken');

          set({
            user: null,
            accessToken: null,
            refreshToken: null,
            isAuthenticated: false,
          });
        }
      },

      refreshAccessToken: async () => {
        const { refreshToken } = get();
        if (!refreshToken) {
          throw new Error('No refresh token available');
        }

        try {
          const result = await graphqlClient
            .mutation(
              `
              mutation RefreshToken {
                refreshToken {
                  user {
                    id
                    email
                    firstName
                    lastName
                    role
                    organization {
                      id
                      name
                    }
                  }
                  accessToken
                  refreshToken
                }
              }
            `,
              {}
            )
            .toPromise();

          if (result.error) {
            throw new Error(result.error.message);
          }

          const { user, accessToken, refreshToken: newRefreshToken } =
            result.data!.refreshToken;

          await SecureStore.setItemAsync('accessToken', accessToken);
          await SecureStore.setItemAsync('refreshToken', newRefreshToken);

          set({
            user,
            accessToken,
            refreshToken: newRefreshToken,
            isAuthenticated: true,
          });
        } catch (error) {
          // Refresh failed, logout user
          await get().logout();
          throw error;
        }
      },

      setUser: (user: User) => {
        set({ user });
      },
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
);
