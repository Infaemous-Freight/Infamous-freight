import { createClient } from 'urql';
import { cacheExchange, fetchExchange } from '@urql/core';
import * as SecureStore from 'expo-secure-store';

const API_URL = process.env.EXPO_PUBLIC_API_URL || 'https://api.infamousfreight.com/graphql';

// Custom fetch that adds auth header
const customFetch = async (input: RequestInfo | URL, init?: RequestInit) => {
  const token = await SecureStore.getItemAsync('accessToken');

  const modifiedInit: RequestInit = {
    ...init,
    headers: {
      ...init?.headers,
      ...(token && { Authorization: `Bearer ${token}` }),
    },
  };

  return fetch(input, modifiedInit);
};

export const graphqlClient = createClient({
  url: API_URL,
  exchanges: [cacheExchange, fetchExchange],
  fetch: customFetch as any,
});

// GraphQL Queries
export const DASHBOARD_QUERY = `
  query Dashboard {
    dashboardStats {
      activeShipments
      availableDrivers
      activeVehicles
      pendingInvoices
      todayDeliveries
      revenueToday
      revenueThisMonth
      revenueGrowth
      onTimeDeliveryRate
      averageTransitTime
      costPerMile
      revenuePerMile
      driverUtilization
      fuelEfficiency
    }
    me {
      id
      email
      firstName
      lastName
      fullName
      role
      notificationCount
    }
  }
`;

export const SHIPMENTS_QUERY = `
  query Shipments($status: ShipmentStatus, $limit: Int, $offset: Int) {
    shipments(status: $status, limit: $limit, offset: $offset) {
      id
      referenceNumber
      customerName
      status
      originCity
      originState
      destinationCity
      destinationState
      scheduledPickupDate
      scheduledDeliveryDate
      actualPickupDate
      actualDeliveryDate
      rate
      distance
      driver {
        id
        fullName
      }
      vehicle {
        id
        unitNumber
      }
      currentLocation {
        latitude
        longitude
      }
      eta {
        estimatedArrival
        confidence
        remainingDistance
        remainingDuration
      }
    }
    shipmentCount(status: $status)
  }
`;

export const SHIPMENT_DETAIL_QUERY = `
  query Shipment($id: ID!) {
    shipment(id: $id) {
      id
      referenceNumber
      customerName
      customerEmail
      customerPhone
      status
      equipmentType
      weight
      commodity
      hazmat
      rate
      rateType
      distance
      totalMiles
      origin
      originAddress
      originCity
      originState
      originZip
      destination
      destinationAddress
      destinationCity
      destinationState
      destinationZip
      scheduledPickupDate
      scheduledDeliveryDate
      actualPickupDate
      actualDeliveryDate
      notes
      driver {
        id
        fullName
        phone
      }
      vehicle {
        id
        unitNumber
        make
        model
        licensePlate
      }
      stops {
        id
        sequence
        type
        name
        address
        city
        state
        scheduledArrival
        actualArrival
      }
      trackingEvents(limit: 20) {
        id
        latitude
        longitude
        speed
        heading
        locationName
        recordedAt
      }
      currentLocation {
        latitude
        longitude
        timestamp
      }
      eta {
        estimatedArrival
        confidence
        remainingDistance
        remainingDuration
        factors
      }
      documents {
        id
        type
        name
        url
      }
    }
  }
`;

export const HOS_LOGS_QUERY = `
  query HosLogs($driverId: ID!) {
    driver(id: $driverId) {
      id
      hosSummary {
        dailyDrivingHours
        dailyDutyHours
        weeklyHours
        remainingDrivingHours
        remainingDutyHours
        lastRestBreak
        violations {
          type
          description
          severity
          timestamp
        }
      }
      hosLogs(limit: 7, orderBy: { date: desc }) {
        id
        date
        dutyStatus
        hours
        startTime
        endTime
        location
        remarks
      }
    }
  }
`;

export const NOTIFICATIONS_QUERY = `
  query Notifications($unreadOnly: Boolean) {
    notifications(unreadOnly: $unreadOnly) {
      id
      type
      title
      message
      read
      entityType
      entityId
      createdAt
    }
    notificationCount
  }
`;

// GraphQL Mutations
export const LOGIN_MUTATION = `
  mutation Login($email: String!, $password: String!) {
    login(email: $email, password: $password) {
      user {
        id
        email
        firstName
        lastName
        role
        organization {
          id
          name
        }
      }
      accessToken
      refreshToken
    }
  }
`;

export const UPDATE_SHIPMENT_STATUS_MUTATION = `
  mutation UpdateShipmentStatus($id: ID!, $status: ShipmentStatus!, $notes: String) {
    updateShipmentStatus(id: $id, status: $status, notes: $notes) {
      id
      status
      actualPickupDate
      actualDeliveryDate
    }
  }
`;

export const ADD_TRACKING_EVENT_MUTATION = `
  mutation AddTrackingEvent($shipmentId: ID!, $input: TrackingEventInput!) {
    addTrackingEvent(shipmentId: $shipmentId, input: $input) {
      id
      latitude
      longitude
      recordedAt
    }
  }
`;

export const LOG_HOS_MUTATION = `
  mutation LogHos($driverId: ID!, $input: HosLogInput!) {
    logHos(driverId: $driverId, input: $input) {
      id
      date
      dutyStatus
      hours
      startTime
      endTime
    }
  }
`;

export const MARK_NOTIFICATION_READ_MUTATION = `
  mutation MarkNotificationRead($id: ID!) {
    markNotificationRead(id: $id) {
      id
      read
    }
  }
`;

// GraphQL Subscriptions
export const SHIPMENT_UPDATED_SUBSCRIPTION = `
  subscription ShipmentUpdated {
    shipmentUpdated {
      id
      status
      currentLocation {
        latitude
        longitude
      }
    }
  }
`;

export const TRACKING_UPDATE_SUBSCRIPTION = `
  subscription TrackingUpdate($shipmentId: ID!) {
    trackingUpdate(shipmentId: $shipmentId) {
      id
      latitude
      longitude
      speed
      heading
      recordedAt
    }
  }
`;

export const NOTIFICATION_RECEIVED_SUBSCRIPTION = `
  subscription NotificationReceived {
    notificationReceived {
      id
      type
      title
      message
      createdAt
    }
  }
`;
