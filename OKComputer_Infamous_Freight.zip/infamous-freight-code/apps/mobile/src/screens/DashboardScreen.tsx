import React from 'react';
import { View, StyleSheet, ScrollView, RefreshControl } from 'react-native';
import { Text, Card, Button, Avatar, Badge, Divider } from 'react-native-paper';
import { useQuery } from '@tanstack/react-query';
import { useNavigation } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import { useAuthStore } from '../store/auth';
import { graphqlClient, DASHBOARD_QUERY } from '../api/graphql';

export function DashboardScreen() {
  const navigation = useNavigation();
  const user = useAuthStore((state) => state.user);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['dashboard'],
    queryFn: async () => {
      const result = await graphqlClient.query(DASHBOARD_QUERY, {}).toPromise();
      return result.data;
    },
  });

  const stats = data?.dashboardStats;

  const StatCard = ({
    title,
    value,
    icon,
    color,
  }: {
    title: string;
    value: string | number;
    icon: string;
    color: string;
  }) => (
    <Card style={[styles.statCard, { borderLeftColor: color, borderLeftWidth: 4 }]}>
      <Card.Content style={styles.statContent}>
        <MaterialCommunityIcons name={icon as any} size={32} color={color} />
        <View style={styles.statText}>
          <Text variant="titleLarge" style={styles.statValue}>
            {value}
          </Text>
          <Text variant="bodySmall" style={styles.statTitle}>
            {title}
          </Text>
        </View>
      </Card.Content>
    </Card>
  );

  return (
    <ScrollView
      style={styles.container}
      refreshControl={<RefreshControl refreshing={isLoading} onRefresh={refetch} />}
    >
      {/* Welcome Header */}
      <View style={styles.header}>
        <View>
          <Text variant="headlineSmall">Welcome back,</Text>
          <Text variant="titleLarge" style={styles.name}>
            {user?.firstName} {user?.lastName}
          </Text>
        </View>
        <Avatar.Text
          size={50}
          label={`${user?.firstName?.[0]}${user?.lastName?.[0]}`}
          style={styles.avatar}
        />
      </View>

      {/* HOS Status Card */}
      <Card style={styles.hosCard}>
        <Card.Content>
          <View style={styles.hosHeader}>
            <Text variant="titleMedium">Hours of Service</Text>
            <Badge style={styles.hosBadge}>ON DUTY</Badge>
          </View>
          <Divider style={styles.divider} />
          <View style={styles.hosStats}>
            <View style={styles.hosStat}>
              <Text variant="headlineSmall" style={styles.hosValue}>
                6.5
              </Text>
              <Text variant="bodySmall">Hrs Remaining (Drive)</Text>
            </View>
            <View style={styles.hosStat}>
              <Text variant="headlineSmall" style={styles.hosValue}>
                8.0
              </Text>
              <Text variant="bodySmall">Hrs Remaining (Duty)</Text>
            </View>
            <View style={styles.hosStat}>
              <Text variant="headlineSmall" style={styles.hosValue}>
                34
              </Text>
              <Text variant="bodySmall">Hrs This Week</Text>
            </View>
          </View>
          <Button
            mode="outlined"
            onPress={() => navigation.navigate('HosLog' as never)}
            style={styles.hosButton}
          >
            Log HOS
          </Button>
        </Card.Content>
      </Card>

      {/* Quick Stats */}
      <Text variant="titleMedium" style={styles.sectionTitle}>
        Today's Activity
      </Text>
      <View style={styles.statsGrid}>
        <StatCard
          title="Active Shipments"
          value={stats?.activeShipments || 0}
          icon="truck-delivery"
          color="#0ea5e9"
        />
        <StatCard
          title="Deliveries"
          value={stats?.todayDeliveries || 0}
          icon="check-circle"
          color="#22c55e"
        />
        <StatCard
          title="Miles Today"
          value={stats?.averageTransitTime || 0}
          icon="map-marker-distance"
          color="#f59e0b"
        />
        <StatCard
          title="Earnings"
          value={`$${stats?.revenueToday || 0}`}
          icon="cash"
          color="#10b981"
        />
      </View>

      {/* Current Shipment */}
      <Text variant="titleMedium" style={styles.sectionTitle}>
        Current Shipment
      </Text>
      <Card style={styles.shipmentCard}>
        <Card.Content>
          <View style={styles.shipmentHeader}>
            <Text variant="titleMedium">SHP-123456</Text>
            <Badge style={styles.inTransitBadge}>IN TRANSIT</Badge>
          </View>
          <Divider style={styles.divider} />
          <View style={styles.routeInfo}>
            <View style={styles.location}>
              <MaterialCommunityIcons name="map-marker" size={24} color="#22c55e" />
              <View>
                <Text variant="bodyLarge">Austin, TX</Text>
                <Text variant="bodySmall" style={styles.timeText}>
                  Picked up 2 hrs ago
                </Text>
              </View>
            </View>
            <MaterialCommunityIcons name="arrow-down" size={24} color="#666" />
            <View style={styles.location}>
              <MaterialCommunityIcons name="map-marker" size={24} color="#ef4444" />
              <View>
                <Text variant="bodyLarge">Dallas, TX</Text>
                <Text variant="bodySmall" style={styles.timeText}>
                  ETA: 1:30 PM (45 min)
                </Text>
              </View>
            </View>
          </View>
          <Button
            mode="contained"
            onPress={() =>
              navigation.navigate('ShipmentDetail' as never, { shipmentId: '123' } as never)
            }
            style={styles.viewButton}
          >
            View Details
          </Button>
        </Card.Content>
      </Card>

      {/* Quick Actions */}
      <Text variant="titleMedium" style={styles.sectionTitle}>
        Quick Actions
      </Text>
      <View style={styles.actionsRow}>
        <Button
          mode="outlined"
          icon="camera"
          onPress={() =>
            navigation.navigate('DocumentScan' as never, {
              shipmentId: '123',
              documentType: 'BOL',
            } as never)
          }
          style={styles.actionButton}
        >
          Scan BOL
        </Button>
        <Button
          mode="outlined"
          icon="message"
          onPress={() => navigation.navigate('Messages' as never)}
          style={styles.actionButton}
        >
          Message
        </Button>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
  },
  name: {
    fontWeight: 'bold',
  },
  avatar: {
    backgroundColor: '#0ea5e9',
  },
  hosCard: {
    margin: 16,
    marginTop: 0,
  },
  hosHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  hosBadge: {
    backgroundColor: '#22c55e',
  },
  divider: {
    marginVertical: 12,
  },
  hosStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
  },
  hosStat: {
    alignItems: 'center',
  },
  hosValue: {
    fontWeight: 'bold',
    color: '#0ea5e9',
  },
  hosButton: {
    marginTop: 8,
  },
  sectionTitle: {
    marginHorizontal: 16,
    marginTop: 16,
    marginBottom: 8,
    fontWeight: 'bold',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 12,
  },
  statCard: {
    width: '50%',
    padding: 4,
    backgroundColor: '#fff',
  },
  statContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    marginLeft: 12,
  },
  statValue: {
    fontWeight: 'bold',
  },
  statTitle: {
    color: '#666',
  },
  shipmentCard: {
    margin: 16,
    marginTop: 0,
  },
  shipmentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  inTransitBadge: {
    backgroundColor: '#0ea5e9',
  },
  routeInfo: {
    marginVertical: 12,
  },
  location: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 4,
  },
  timeText: {
    color: '#666',
  },
  viewButton: {
    marginTop: 8,
  },
  actionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: 16,
    paddingBottom: 24,
  },
  actionButton: {
    flex: 1,
    marginHorizontal: 8,
  },
});
