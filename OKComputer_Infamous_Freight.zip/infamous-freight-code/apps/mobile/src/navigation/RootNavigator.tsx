import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { useAuthStore } from '../store/auth';

import { LoginScreen } from '../screens/LoginScreen';
import { MainTabNavigator } from './MainTabNavigator';
import { ShipmentDetailScreen } from '../screens/ShipmentDetailScreen';
import { HosLogScreen } from '../screens/HosLogScreen';
import { DocumentScanScreen } from '../screens/DocumentScanScreen';
import { ProfileScreen } from '../screens/ProfileScreen';

export type RootStackParamList = {
  Login: undefined;
  Main: undefined;
  ShipmentDetail: { shipmentId: string };
  HosLog: undefined;
  DocumentScan: { shipmentId: string; documentType: string };
  Profile: undefined;
};

const Stack = createStackNavigator<RootStackParamList>();

export function RootNavigator() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {!isAuthenticated ? (
        <Stack.Screen name="Login" component={LoginScreen} />
      ) : (
        <>
          <Stack.Screen name="Main" component={MainTabNavigator} />
          <Stack.Screen
            name="ShipmentDetail"
            component={ShipmentDetailScreen}
            options={{ headerShown: true, title: 'Shipment Details' }}
          />
          <Stack.Screen
            name="HosLog"
            component={HosLogScreen}
            options={{ headerShown: true, title: 'HOS Log' }}
          />
          <Stack.Screen
            name="DocumentScan"
            component={DocumentScanScreen}
            options={{ headerShown: true, title: 'Scan Document' }}
          />
          <Stack.Screen
            name="Profile"
            component={ProfileScreen}
            options={{ headerShown: true, title: 'Profile' }}
          />
        </>
      )}
    </Stack.Navigator>
  );
}
