import axios from 'axios';
import { useAuthStore } from '@/store/auth';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

export const api = axios.create({
  baseURL: `${API_URL}/api`,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = useAuthStore.getState().accessToken;
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle token refresh
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    // If error is 401 and we haven't tried to refresh token yet
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        await useAuthStore.getState().refreshAccessToken();
        const newToken = useAuthStore.getState().accessToken;
        originalRequest.headers.Authorization = `Bearer ${newToken}`;
        return api(originalRequest);
      } catch (refreshError) {
        // Refresh failed, logout user
        useAuthStore.getState().logout();
        window.location.href = '/login';
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

// API helper functions
export const shipmentsApi = {
  getAll: (params?: any) => api.get('/shipments', { params }),
  getById: (id: string) => api.get(`/shipments/${id}`),
  create: (data: any) => api.post('/shipments', data),
  update: (id: string, data: any) => api.patch(`/shipments/${id}`, data),
  delete: (id: string) => api.delete(`/shipments/${id}`),
  assign: (id: string, data: any) => api.post(`/shipments/${id}/assign`, data),
  updateStatus: (id: string, data: any) => api.post(`/shipments/${id}/status`, data),
};

export const driversApi = {
  getAll: (params?: any) => api.get('/drivers', { params }),
  getById: (id: string) => api.get(`/drivers/${id}`),
  create: (data: any) => api.post('/drivers', data),
  update: (id: string, data: any) => api.patch(`/drivers/${id}`, data),
  delete: (id: string) => api.delete(`/drivers/${id}`),
  getHos: (id: string, params?: any) => api.get(`/drivers/${id}/hos`, { params }),
  getPerformance: (id: string) => api.get(`/drivers/${id}/performance`),
};

export const vehiclesApi = {
  getAll: (params?: any) => api.get('/vehicles', { params }),
  getById: (id: string) => api.get(`/vehicles/${id}`),
  create: (data: any) => api.post('/vehicles', data),
  update: (id: string, data: any) => api.patch(`/vehicles/${id}`, data),
  delete: (id: string) => api.delete(`/vehicles/${id}`),
  assignDriver: (id: string, data: any) => api.post(`/vehicles/${id}/drivers`, data),
  removeDriver: (id: string, driverId: string) => api.delete(`/vehicles/${id}/drivers/${driverId}`),
  getMaintenance: (id: string, params?: any) => api.get(`/vehicles/${id}/maintenance`, { params }),
  addMaintenance: (id: string, data: any) => api.post(`/vehicles/${id}/maintenance`, data),
  getUtilization: (id: string) => api.get(`/vehicles/${id}/utilization`),
};

export const invoicesApi = {
  getAll: (params?: any) => api.get('/invoices', { params }),
  getById: (id: string) => api.get(`/invoices/${id}`),
  create: (data: any) => api.post('/invoices', data),
  update: (id: string, data: any) => api.patch(`/invoices/${id}`, data),
  delete: (id: string) => api.delete(`/invoices/${id}`),
  send: (id: string) => api.post(`/invoices/${id}/send`),
  recordPayment: (id: string, data: any) => api.post(`/invoices/${id}/payments`, data),
  getAging: () => api.get('/invoices/reports/aging'),
  getRevenue: (params?: any) => api.get('/invoices/reports/revenue', { params }),
};

export const trackingApi = {
  getShipmentTracking: (id: string, params?: any) => api.get(`/tracking/shipments/${id}`, { params }),
  getActiveLocations: () => api.get('/tracking/active'),
  getEta: (id: string) => api.get(`/tracking/shipments/${id}/eta`),
  checkIn: (data: any) => api.post('/tracking/checkin', data),
};

export const analyticsApi = {
  getDashboard: () => api.get('/analytics/dashboard'),
  getPerformance: (params?: any) => api.get('/analytics/performance', { params }),
  getFinancials: (params?: any) => api.get('/analytics/financials', { params }),
  getOperations: (params?: any) => api.get('/analytics/operations', { params }),
  getKpis: () => api.get('/analytics/kpis'),
  getForecast: () => api.get('/analytics/forecast'),
};

export const aiApi = {
  getLoadRecommendations: (data: any) => api.post('/ai/load-recommendation', data),
  optimizeRoute: (data: any) => api.post('/ai/route-optimization', data),
  processCommand: (data: any) => api.post('/ai/command', data),
  extractDocument: (data: any) => api.post('/ai/document-extract', data),
};

export default api;
