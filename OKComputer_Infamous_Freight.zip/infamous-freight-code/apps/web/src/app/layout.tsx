import type { Metadata } from 'next';
import { Providers } from './providers';

export const metadata: Metadata = {
  title: 'Infamous Freight - AI-Native Freight Management',
  description: 'Modern freight management platform with AI-powered load matching, route optimization, and real-time tracking.',
  keywords: 'freight, trucking, logistics, TMS, fleet management, route optimization',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
