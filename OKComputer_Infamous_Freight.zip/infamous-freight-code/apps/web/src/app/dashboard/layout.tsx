'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  Box,
  Flex,
  useColorModeValue,
} from '@chakra-ui/react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { useAuthStore } from '@/store/auth';

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const { isAuthenticated, isLoading } = useAuthStore();
  const bgColor = useColorModeValue('gray.50', 'gray.900');

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login');
    }
  }, [isAuthenticated, isLoading, router]);

  if (isLoading) {
    return null; // Or a loading spinner
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <Flex h="100vh" bg={bgColor}>
      <Sidebar />
      <Flex flex={1} flexDirection="column" overflow="hidden">
        <Header />
        <Box
          flex={1}
          overflow="auto"
          p={6}
        >
          {children}
        </Box>
      </Flex>
    </Flex>
  );
}
