'use client';

import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Heading,
  Flex,
  Card,
  CardBody,
  Text,
  Badge,
  Select,
  HStack,
  VStack,
  useColorModeValue,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Divider,
} from '@chakra-ui/react';
import { FaTruck, FaClock, FaMapMarkerAlt } from 'react-icons/fa';
import { shipmentsApi, trackingApi } from '@/lib/api';
import { useTracking } from '@/hooks/useTracking';
import { formatDateTime, formatDistanceToNow } from '@/lib/utils';

const statusColors: Record<string, string> = {
  PENDING: 'yellow',
  ASSIGNED: 'blue',
  PICKED_UP: 'purple',
  IN_TRANSIT: 'brand',
  OUT_FOR_DELIVERY: 'orange',
  DELIVERED: 'green',
  CANCELLED: 'red',
};

function TrackingMap({ shipmentId }: { shipmentId: string }) {
  const { currentLocation, locations, eta, isConnected } = useTracking({
    shipmentId,
    enableWebSocket: true,
  });

  return (
    <Card bg={useColorModeValue('white', 'gray.800')} shadow="md" h="400px">
      <CardBody>
        <Flex direction="column" h="full">
          <Flex justify="space-between" align="center" mb={4}>
            <HStack>
              <Box
                w={3}
                h={3}
                borderRadius="full"
                bg={isConnected ? 'green.500' : 'red.500'}
              />
              <Text fontSize="sm">
                {isConnected ? 'Live Tracking' : 'Disconnected'}
              </Text>
            </HStack>
            {eta && (
              <HStack>
                <FaClock />
                <Text fontSize="sm">ETA: {eta}</Text>
              </HStack>
            )}
          </Flex>

          <Box flex={1} bg="gray.100" borderRadius="md" position="relative">
            {/* Map placeholder - integrate with Google Maps or Mapbox */}
            <Flex
              direction="column"
              align="center"
              justify="center"
              h="full"
              color="gray.500"
            >
              <FaMapMarkerAlt size={48} />
              <Text mt={2}>Map Integration</Text>
              <Text fontSize="sm">
                {currentLocation
                  ? `Lat: ${currentLocation.latitude.toFixed(4)}, Lng: ${currentLocation.longitude.toFixed(4)}`
                  : 'No location data'}
              </Text>
            </Flex>
          </Box>

          {currentLocation && (
            <HStack mt={4} spacing={6}>
              <Box>
                <Text fontSize="xs" color="gray.500">
                  Speed
                </Text>
                <Text fontWeight="bold">
                  {currentLocation.speed?.toFixed(0) || 0} mph
                </Text>
              </Box>
              <Box>
                <Text fontSize="xs" color="gray.500">
                  Heading
                </Text>
                <Text fontWeight="bold">
                  {currentLocation.heading?.toFixed(0) || 0}°
                </Text>
              </Box>
              <Box>
                <Text fontSize="xs" color="gray.500">
                  Last Update
                </Text>
                <Text fontWeight="bold">
                  {formatDistanceToNow(currentLocation.timestamp)}
                </Text>
              </Box>
            </HStack>
          )}
        </Flex>
      </CardBody>
    </Card>
  );
}

function TrackingHistory({ shipmentId }: { shipmentId: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ['tracking-history', shipmentId],
    queryFn: () => trackingApi.getShipmentTracking(shipmentId).then((res) => res.data),
    enabled: !!shipmentId,
  });

  const events = data?.events || [];

  return (
    <Card bg={useColorModeValue('white', 'gray.800')} shadow="md">
      <CardBody>
        <Heading size="md" mb={4}>
          Tracking History
        </Heading>
        {isLoading ? (
          <Text>Loading...</Text>
        ) : (
          <Table variant="simple" size="sm">
            <Thead>
              <Tr>
                <Th>Time</Th>
                <Th>Event</Th>
                <Th>Location</Th>
                <Th>Notes</Th>
              </Tr>
            </Thead>
            <Tbody>
              {events.map((event: any) => (
                <Tr key={event.id}>
                  <Td>{formatDateTime(event.recordedAt)}</Td>
                  <Td>
                    <Badge colorScheme={statusColors[event.type] || 'gray'}>
                      {event.type}
                    </Badge>
                  </Td>
                  <Td>
                    {event.latitude.toFixed(4)}, {event.longitude.toFixed(4)}
                  </Td>
                  <Td>{event.notes || '-'}</Td>
                </Tr>
              ))}
            </Tbody>
          </Table>
        )}
      </CardBody>
    </Card>
  );
}

export default function TrackingPage() {
  const [selectedShipmentId, setSelectedShipmentId] = useState<string>('');
  const cardBg = useColorModeValue('white', 'gray.800');

  const { data: activeShipments, isLoading } = useQuery({
    queryKey: ['active-shipments'],
    queryFn: () =>
      shipmentsApi
        .getAll({
          status: 'IN_TRANSIT',
          limit: 100,
        })
        .then((res) => res.data.shipments),
  });

  useEffect(() => {
    if (activeShipments?.length > 0 && !selectedShipmentId) {
      setSelectedShipmentId(activeShipments[0].id);
    }
  }, [activeShipments, selectedShipmentId]);

  return (
    <Box>
      <Heading mb={6}>Live Tracking</Heading>

      {/* Shipment Selector */}
      <Card bg={cardBg} shadow="md" mb={6}>
        <CardBody>
          <Flex align="center" gap={4}>
            <Text fontWeight="medium">Select Shipment:</Text>
            <Select
              maxW="400px"
              value={selectedShipmentId}
              onChange={(e) => setSelectedShipmentId(e.target.value)}
              isDisabled={isLoading}
            >
              <option value="">Select a shipment</option>
              {activeShipments?.map((shipment: any) => (
                <option key={shipment.id} value={shipment.id}>
                  {shipment.referenceNumber} - {shipment.originCity} to{' '}
                  {shipment.destinationCity}
                </option>
              ))}
            </Select>
            <Badge colorScheme="green">
              {activeShipments?.length || 0} Active
            </Badge>
          </Flex>
        </CardBody>
      </Card>

      {/* Tracking Content */}
      {selectedShipmentId ? (
        <VStack spacing={6} align="stretch">
          <TrackingMap shipmentId={selectedShipmentId} />
          <TrackingHistory shipmentId={selectedShipmentId} />
        </VStack>
      ) : (
        <Card bg={cardBg} shadow="md">
          <CardBody>
            <Flex
              direction="column"
              align="center"
              justify="center"
              py={12}
              color="gray.500"
            >
              <FaTruck size={48} />
              <Text mt={4} fontSize="lg">
                Select a shipment to view live tracking
              </Text>
            </Flex>
          </CardBody>
        </Card>
      )}
    </Box>
  );
}
