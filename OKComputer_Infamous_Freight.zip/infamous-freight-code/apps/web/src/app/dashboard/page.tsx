'use client';

import { useQuery } from '@tanstack/react-query';
import {
  Box,
  SimpleGrid,
  Heading,
  Text,
  Card,
  CardBody,
  CardHeader,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  Icon,
  Flex,
  Badge,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Button,
  HStack,
  useColorModeValue,
} from '@chakra-ui/react';
import {
  FaTruck,
  FaUsers,
  FaBox,
  FaDollarSign,
  FaClock,
  FaCheckCircle,
  FaExclamationTriangle,
} from 'react-icons/fa';
import Link from 'next/link';
import { analyticsApi, shipmentsApi } from '@/lib/api';
import { formatDistanceToNow, formatCurrency } from '@/lib/utils';

const stats = [
  { label: 'Active Shipments', icon: FaBox, color: 'brand', api: 'activeShipments' },
  { label: 'Available Drivers', icon: FaUsers, color: 'success', api: 'availableDrivers' },
  { label: 'Active Vehicles', icon: FaTruck, color: 'warning', api: 'activeVehicles' },
  { label: 'Revenue Today', icon: FaDollarSign, color: 'brand', api: 'revenueToday', format: 'currency' },
];

export default function DashboardPage() {
  const cardBg = useColorModeValue('white', 'gray.800');

  const { data: dashboardData, isLoading: dashboardLoading } = useQuery({
    queryKey: ['dashboard'],
    queryFn: () => analyticsApi.getDashboard().then((res) => res.data),
  });

  const { data: recentShipments, isLoading: shipmentsLoading } = useQuery({
    queryKey: ['recentShipments'],
    queryFn: () =>
      shipmentsApi
        .getAll({ limit: 5, sort: 'createdAt', order: 'desc' })
        .then((res) => res.data.shipments),
  });

  const { data: kpis, isLoading: kpisLoading } = useQuery({
    queryKey: ['kpis'],
    queryFn: () => analyticsApi.getKpis().then((res) => res.data),
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'DELIVERED':
        return 'success';
      case 'IN_TRANSIT':
        return 'brand';
      case 'PENDING':
        return 'warning';
      case 'CANCELLED':
        return 'danger';
      default:
        return 'gray';
    }
  };

  return (
    <Box>
      <Heading mb={6}>Dashboard</Heading>

      {/* Stats Grid */}
      <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6} mb={8}>
        {stats.map((stat) => (
          <Card key={stat.label} bg={cardBg} shadow="md">
            <CardBody>
              <Flex align="center" justify="space-between">
                <Stat>
                  <StatLabel color="gray.500">{stat.label}</StatLabel>
                  <StatNumber fontSize="2xl">
                    {dashboardLoading
                      ? '-'
                      : stat.format === 'currency'
                      ? formatCurrency(dashboardData?.[stat.api] || 0)
                      : dashboardData?.[stat.api] || 0}
                  </StatNumber>
                </Stat>
                <Box
                  p={3}
                  bg={`${stat.color}.100`}
                  borderRadius="lg"
                >
                  <Icon
                    as={stat.icon}
                    boxSize={6}
                    color={`${stat.color}.500`}
                  />
                </Box>
              </Flex>
            </CardBody>
          </Card>
        ))}
      </SimpleGrid>

      {/* KPIs */}
      <Card bg={cardBg} shadow="md" mb={8}>
        <CardHeader>
          <Heading size="md">Key Performance Indicators</Heading>
        </CardHeader>
        <CardBody>
          <SimpleGrid columns={{ base: 1, md: 3, lg: 6 }} spacing={6}>
            {kpisLoading ? (
              <Text>Loading...</Text>
            ) : (
              <>
                <Box textAlign="center">
                  <Text fontSize="sm" color="gray.500">On-Time Delivery</Text>
                  <Text fontSize="2xl" fontWeight="bold" color="success.500">
                    {kpis?.onTimeDelivery?.toFixed(1)}%
                  </Text>
                </Box>
                <Box textAlign="center">
                  <Text fontSize="sm" color="gray.500">Avg Transit Time</Text>
                  <Text fontSize="2xl" fontWeight="bold">
                    {kpis?.averageTransitTime?.toFixed(1)}h
                  </Text>
                </Box>
                <Box textAlign="center">
                  <Text fontSize="sm" color="gray.500">Cost/Mile</Text>
                  <Text fontSize="2xl" fontWeight="bold">
                    ${kpis?.costPerMile?.toFixed(2)}
                  </Text>
                </Box>
                <Box textAlign="center">
                  <Text fontSize="sm" color="gray.500">Revenue/Mile</Text>
                  <Text fontSize="2xl" fontWeight="bold" color="success.500">
                    ${kpis?.revenuePerMile?.toFixed(2)}
                  </Text>
                </Box>
                <Box textAlign="center">
                  <Text fontSize="sm" color="gray.500">Driver Utilization</Text>
                  <Text fontSize="2xl" fontWeight="bold">
                    {kpis?.driverUtilization?.toFixed(1)}%
                  </Text>
                </Box>
                <Box textAlign="center">
                  <Text fontSize="sm" color="gray.500">Fuel Efficiency</Text>
                  <Text fontSize="2xl" fontWeight="bold">
                    {kpis?.fuelEfficiency?.toFixed(1)} MPG
                  </Text>
                </Box>
              </>
            )}
          </SimpleGrid>
        </CardBody>
      </Card>

      {/* Recent Shipments */}
      <Card bg={cardBg} shadow="md">
        <CardHeader>
          <Flex justify="space-between" align="center">
            <Heading size="md">Recent Shipments</Heading>
            <Button
              as={Link}
              href="/dashboard/shipments"
              size="sm"
              colorScheme="brand"
              variant="outline"
            >
              View All
            </Button>
          </Flex>
        </CardHeader>
        <CardBody>
          {shipmentsLoading ? (
            <Text>Loading...</Text>
          ) : (
            <Table variant="simple">
              <Thead>
                <Tr>
                  <Th>Reference</Th>
                  <Th>Customer</Th>
                  <Th>Route</Th>
                  <Th>Status</Th>
                  <Th>Created</Th>
                  <Th>Actions</Th>
                </Tr>
              </Thead>
              <Tbody>
                {recentShipments?.map((shipment: any) => (
                  <Tr key={shipment.id}>
                    <Td fontWeight="medium">{shipment.referenceNumber}</Td>
                    <Td>{shipment.customerName}</Td>
                    <Td>
                      <Text fontSize="sm">
                        {shipment.originCity}, {shipment.originState} →{' '}
                        {shipment.destinationCity}, {shipment.destinationState}
                      </Text>
                    </Td>
                    <Td>
                      <Badge colorScheme={getStatusColor(shipment.status)}>
                        {shipment.status}
                      </Badge>
                    </Td>
                    <Td>{formatDistanceToNow(shipment.createdAt)}</Td>
                    <Td>
                      <HStack spacing={2}>
                        <Button
                          as={Link}
                          href={`/dashboard/shipments/${shipment.id}`}
                          size="sm"
                          variant="ghost"
                        >
                          View
                        </Button>
                      </HStack>
                    </Td>
                  </Tr>
                ))}
              </Tbody>
            </Table>
          )}
        </CardBody>
      </Card>
    </Box>
  );
}
