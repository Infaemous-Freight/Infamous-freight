'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Heading,
  Button,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Badge,
  HStack,
  Input,
  InputGroup,
  InputLeftElement,
  Flex,
  Text,
  IconButton,
  useColorModeValue,
  Card,
  CardBody,
  Progress,
} from '@chakra-ui/react';
import { FaSearch, FaPlus, FaEye, FaEdit, FaWrench } from 'react-icons/fa';
import Link from 'next/link';
import { vehiclesApi } from '@/lib/api';

const statusColors: Record<string, string> = {
  ACTIVE: 'green',
  INACTIVE: 'gray',
  MAINTENANCE: 'yellow',
  RETIRED: 'red',
};

const typeLabels: Record<string, string> = {
  TRACTOR: 'Tractor',
  STRAIGHT_TRUCK: 'Straight Truck',
  VAN: 'Van',
  REEFER: 'Reefer',
  FLATBED: 'Flatbed',
  TANKER: 'Tanker',
  CAR_CARRIER: 'Car Carrier',
  DUMP_TRUCK: 'Dump Truck',
  OTHER: 'Other',
};

export default function VehiclesPage() {
  const [page, setPage] = useState(1);
  const [limit] = useState(10);
  const [search, setSearch] = useState('');
  const cardBg = useColorModeValue('white', 'gray.800');

  const { data, isLoading } = useQuery({
    queryKey: ['vehicles', page, limit, search],
    queryFn: () =>
      vehiclesApi
        .getAll({
          page,
          limit,
          search: search || undefined,
        })
        .then((res) => res.data),
  });

  const vehicles = data?.vehicles || [];
  const totalPages = data?.pagination?.totalPages || 1;

  return (
    <Box>
      <Flex justify="space-between" align="center" mb={6}>
        <Heading>Vehicles</Heading>
        <Button
          as={Link}
          href="/dashboard/vehicles/new"
          leftIcon={<FaPlus />}
          colorScheme="brand"
        >
          Add Vehicle
        </Button>
      </Flex>

      {/* Filters */}
      <Card bg={cardBg} shadow="md" mb={6}>
        <CardBody>
          <InputGroup maxW="400px">
            <InputLeftElement pointerEvents="none">
              <FaSearch color="gray.300" />
            </InputLeftElement>
            <Input
              placeholder="Search by VIN, plate, or unit number..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </InputGroup>
        </CardBody>
      </Card>

      {/* Vehicles Table */}
      <Card bg={cardBg} shadow="md">
        <CardBody>
          {isLoading ? (
            <Text>Loading vehicles...</Text>
          ) : (
            <>
              <Table variant="simple">
                <Thead>
                  <Tr>
                    <Th>Unit #</Th>
                    <Th>Type</Th>
                    <Th>Make/Model</Th>
                    <Th>Year</Th>
                    <Th>Status</Th>
                    <Th>Mileage</Th>
                    <Th>Utilization</Th>
                    <Th>Actions</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {vehicles.map((vehicle: any) => (
                    <Tr key={vehicle.id}>
                      <Td fontWeight="medium">{vehicle.unitNumber}</Td>
                      <Td>{typeLabels[vehicle.type] || vehicle.type}</Td>
                      <Td>
                        {vehicle.make} {vehicle.model}
                      </Td>
                      <Td>{vehicle.year}</Td>
                      <Td>
                        <Badge colorScheme={statusColors[vehicle.status] || 'gray'}>
                          {vehicle.status}
                        </Badge>
                      </Td>
                      <Td>{vehicle.currentMileage?.toLocaleString()} mi</Td>
                      <Td>
                        <Box w="100px">
                          <Progress
                            value={vehicle.utilization || 0}
                            size="sm"
                            colorScheme={
                              (vehicle.utilization || 0) > 80
                                ? 'green'
                                : (vehicle.utilization || 0) > 50
                                ? 'yellow'
                                : 'red'
                            }
                            borderRadius="full"
                          />
                          <Text fontSize="xs" textAlign="center" mt={1}>
                            {vehicle.utilization?.toFixed(0)}%
                          </Text>
                        </Box>
                      </Td>
                      <Td>
                        <HStack spacing={2}>
                          <IconButton
                            as={Link}
                            href={`/dashboard/vehicles/${vehicle.id}`}
                            aria-label="View"
                            icon={<FaEye />}
                            size="sm"
                            variant="ghost"
                          />
                          <IconButton
                            as={Link}
                            href={`/dashboard/vehicles/${vehicle.id}/edit`}
                            aria-label="Edit"
                            icon={<FaEdit />}
                            size="sm"
                            variant="ghost"
                          />
                          <IconButton
                            as={Link}
                            href={`/dashboard/vehicles/${vehicle.id}/maintenance`}
                            aria-label="Maintenance"
                            icon={<FaWrench />}
                            size="sm"
                            variant="ghost"
                          />
                        </HStack>
                      </Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>

              {/* Pagination */}
              <Flex justify="center" mt={4}>
                <HStack>
                  <Button
                    size="sm"
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    isDisabled={page === 1}
                  >
                    Previous
                  </Button>
                  <Text>
                    Page {page} of {totalPages}
                  </Text>
                  <Button
                    size="sm"
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                    isDisabled={page === totalPages}
                  >
                    Next
                  </Button>
                </HStack>
              </Flex>
            </>
          )}
        </CardBody>
      </Card>
    </Box>
  );
}
