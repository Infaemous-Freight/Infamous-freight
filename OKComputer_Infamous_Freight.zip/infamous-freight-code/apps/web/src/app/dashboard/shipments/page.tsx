'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Heading,
  Button,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Badge,
  HStack,
  Input,
  InputGroup,
  InputLeftElement,
  Select,
  Flex,
  Text,
  IconButton,
  useColorModeValue,
  Card,
  CardBody,
  Pagination,
} from '@chakra-ui/react';
import { FaSearch, FaPlus, FaEye, FaEdit, FaTrash } from 'react-icons/fa';
import Link from 'next/link';
import { shipmentsApi } from '@/lib/api';
import { formatDistanceToNow, formatCurrency, formatDate } from '@/lib/utils';

const statusColors: Record<string, string> = {
  PENDING: 'yellow',
  ASSIGNED: 'blue',
  PICKED_UP: 'purple',
  IN_TRANSIT: 'brand',
  OUT_FOR_DELIVERY: 'orange',
  DELIVERED: 'green',
  CANCELLED: 'red',
};

export default function ShipmentsPage() {
  const [page, setPage] = useState(1);
  const [limit] = useState(10);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const cardBg = useColorModeValue('white', 'gray.800');

  const { data, isLoading } = useQuery({
    queryKey: ['shipments', page, limit, search, statusFilter],
    queryFn: () =>
      shipmentsApi
        .getAll({
          page,
          limit,
          search: search || undefined,
          status: statusFilter || undefined,
        })
        .then((res) => res.data),
  });

  const shipments = data?.shipments || [];
  const totalPages = data?.pagination?.totalPages || 1;

  return (
    <Box>
      <Flex justify="space-between" align="center" mb={6}>
        <Heading>Shipments</Heading>
        <Button
          as={Link}
          href="/dashboard/shipments/new"
          leftIcon={<FaPlus />}
          colorScheme="brand"
        >
          New Shipment
        </Button>
      </Flex>

      {/* Filters */}
      <Card bg={cardBg} shadow="md" mb={6}>
        <CardBody>
          <Flex gap={4} wrap="wrap">
            <InputGroup maxW="300px">
              <InputLeftElement pointerEvents="none">
                <FaSearch color="gray.300" />
              </InputLeftElement>
              <Input
                placeholder="Search shipments..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </InputGroup>

            <Select
              maxW="200px"
              placeholder="Filter by status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="PENDING">Pending</option>
              <option value="ASSIGNED">Assigned</option>
              <option value="PICKED_UP">Picked Up</option>
              <option value="IN_TRANSIT">In Transit</option>
              <option value="OUT_FOR_DELIVERY">Out for Delivery</option>
              <option value="DELIVERED">Delivered</option>
              <option value="CANCELLED">Cancelled</option>
            </Select>
          </Flex>
        </CardBody>
      </Card>

      {/* Shipments Table */}
      <Card bg={cardBg} shadow="md">
        <CardBody>
          {isLoading ? (
            <Text>Loading shipments...</Text>
          ) : (
            <>
              <Table variant="simple">
                <Thead>
                  <Tr>
                    <Th>Reference</Th>
                    <Th>Customer</Th>
                    <Th>Route</Th>
                    <Th>Status</Th>
                    <Th>Rate</Th>
                    <Th>Created</Th>
                    <Th>Actions</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {shipments.map((shipment: any) => (
                    <Tr key={shipment.id}>
                      <Td fontWeight="medium">{shipment.referenceNumber}</Td>
                      <Td>{shipment.customerName}</Td>
                      <Td>
                        <Text fontSize="sm">
                          {shipment.originCity}, {shipment.originState}
                          <br />
                          ↓
                          <br />
                          {shipment.destinationCity}, {shipment.destinationState}
                        </Text>
                      </Td>
                      <Td>
                        <Badge colorScheme={statusColors[shipment.status] || 'gray'}>
                          {shipment.status}
                        </Badge>
                      </Td>
                      <Td>{formatCurrency(shipment.rate)}</Td>
                      <Td>{formatDistanceToNow(shipment.createdAt)}</Td>
                      <Td>
                        <HStack spacing={2}>
                          <IconButton
                            as={Link}
                            href={`/dashboard/shipments/${shipment.id}`}
                            aria-label="View"
                            icon={<FaEye />}
                            size="sm"
                            variant="ghost"
                          />
                          <IconButton
                            as={Link}
                            href={`/dashboard/shipments/${shipment.id}/edit`}
                            aria-label="Edit"
                            icon={<FaEdit />}
                            size="sm"
                            variant="ghost"
                          />
                        </HStack>
                      </Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>

              {/* Pagination */}
              <Flex justify="center" mt={4}>
                <HStack>
                  <Button
                    size="sm"
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    isDisabled={page === 1}
                  >
                    Previous
                  </Button>
                  <Text>
                    Page {page} of {totalPages}
                  </Text>
                  <Button
                    size="sm"
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                    isDisabled={page === totalPages}
                  >
                    Next
                  </Button>
                </HStack>
              </Flex>
            </>
          )}
        </CardBody>
      </Card>
    </Box>
  );
}
