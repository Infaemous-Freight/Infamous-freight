'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Heading,
  Button,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Badge,
  HStack,
  Input,
  InputGroup,
  InputLeftElement,
  Select,
  Flex,
  Text,
  IconButton,
  useColorModeValue,
  Card,
  CardBody,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
} from '@chakra-ui/react';
import { FaSearch, FaPlus, FaEye, FaEdit, FaPaperPlane, FaDollarSign } from 'react-icons/fa';
import Link from 'next/link';
import { invoicesApi } from '@/lib/api';
import { formatCurrency, formatDate } from '@/lib/utils';

const statusColors: Record<string, string> = {
  DRAFT: 'gray',
  SENT: 'blue',
  VIEWED: 'purple',
  PARTIAL: 'orange',
  PAID: 'green',
  OVERDUE: 'red',
  CANCELLED: 'gray',
};

export default function InvoicesPage() {
  const [page, setPage] = useState(1);
  const [limit] = useState(10);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const cardBg = useColorModeValue('white', 'gray.800');

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['invoices', page, limit, search, statusFilter],
    queryFn: () =>
      invoicesApi
        .getAll({
          page,
          limit,
          search: search || undefined,
          status: statusFilter || undefined,
        })
        .then((res) => res.data),
  });

  const invoices = data?.invoices || [];
  const totalPages = data?.pagination?.totalPages || 1;

  const handleSendInvoice = async (id: string) => {
    try {
      await invoicesApi.send(id);
      refetch();
    } catch (error) {
      console.error('Failed to send invoice:', error);
    }
  };

  const agingData = data?.aging || {};

  return (
    <Box>
      <Flex justify="space-between" align="center" mb={6}>
        <Heading>Invoices</Heading>
        <Button
          as={Link}
          href="/dashboard/invoices/new"
          leftIcon={<FaPlus />}
          colorScheme="brand"
        >
          Create Invoice
        </Button>
      </Flex>

      {/* Aging Summary */}
      <Card bg={cardBg} shadow="md" mb={6}>
        <CardBody>
          <Heading size="sm" mb={4}>
            Accounts Receivable Aging
          </Heading>
          <Flex gap={8} wrap="wrap">
            <Box>
              <Text fontSize="sm" color="gray.500">
                Current
              </Text>
              <Text fontSize="xl" fontWeight="bold" color="green.500">
                {formatCurrency(agingData.current || 0)}
              </Text>
            </Box>
            <Box>
              <Text fontSize="sm" color="gray.500">
                1-30 Days
              </Text>
              <Text fontSize="xl" fontWeight="bold">
                {formatCurrency(agingData.days1to30 || 0)}
              </Text>
            </Box>
            <Box>
              <Text fontSize="sm" color="gray.500">
                31-60 Days
              </Text>
              <Text fontSize="xl" fontWeight="bold" color="orange.500">
                {formatCurrency(agingData.days31to60 || 0)}
              </Text>
            </Box>
            <Box>
              <Text fontSize="sm" color="gray.500">
                61-90 Days
              </Text>
              <Text fontSize="xl" fontWeight="bold" color="red.500">
                {formatCurrency(agingData.days61to90 || 0)}
              </Text>
            </Box>
            <Box>
              <Text fontSize="sm" color="gray.500">
                90+ Days
              </Text>
              <Text fontSize="xl" fontWeight="bold" color="red.600">
                {formatCurrency(agingData.days90Plus || 0)}
              </Text>
            </Box>
          </Flex>
        </CardBody>
      </Card>

      {/* Filters */}
      <Card bg={cardBg} shadow="md" mb={6}>
        <CardBody>
          <Flex gap={4} wrap="wrap">
            <InputGroup maxW="300px">
              <InputLeftElement pointerEvents="none">
                <FaSearch color="gray.300" />
              </InputLeftElement>
              <Input
                placeholder="Search invoices..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </InputGroup>

            <Select
              maxW="200px"
              placeholder="Filter by status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="DRAFT">Draft</option>
              <option value="SENT">Sent</option>
              <option value="VIEWED">Viewed</option>
              <option value="PARTIAL">Partial</option>
              <option value="PAID">Paid</option>
              <option value="OVERDUE">Overdue</option>
            </Select>
          </Flex>
        </CardBody>
      </Card>

      {/* Invoices Table */}
      <Card bg={cardBg} shadow="md">
        <CardBody>
          {isLoading ? (
            <Text>Loading invoices...</Text>
          ) : (
            <>
              <Table variant="simple">
                <Thead>
                  <Tr>
                    <Th>Invoice #</Th>
                    <Th>Customer</Th>
                    <Th>Shipment</Th>
                    <Th>Amount</Th>
                    <Th>Status</Th>
                    <Th>Due Date</Th>
                    <Th>Actions</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {invoices.map((invoice: any) => (
                    <Tr key={invoice.id}>
                      <Td fontWeight="medium">{invoice.invoiceNumber}</Td>
                      <Td>{invoice.customerName}</Td>
                      <Td>{invoice.shipment?.referenceNumber || 'N/A'}</Td>
                      <Td>{formatCurrency(invoice.totalAmount)}</Td>
                      <Td>
                        <Badge colorScheme={statusColors[invoice.status] || 'gray'}>
                          {invoice.status}
                        </Badge>
                      </Td>
                      <Td>{formatDate(invoice.dueDate)}</Td>
                      <Td>
                        <HStack spacing={2}>
                          <IconButton
                            as={Link}
                            href={`/dashboard/invoices/${invoice.id}`}
                            aria-label="View"
                            icon={<FaEye />}
                            size="sm"
                            variant="ghost"
                          />
                          <IconButton
                            as={Link}
                            href={`/dashboard/invoices/${invoice.id}/edit`}
                            aria-label="Edit"
                            icon={<FaEdit />}
                            size="sm"
                            variant="ghost"
                          />
                          {invoice.status === 'DRAFT' && (
                            <IconButton
                              aria-label="Send"
                              icon={<FaPaperPlane />}
                              size="sm"
                              variant="ghost"
                              onClick={() => handleSendInvoice(invoice.id)}
                            />
                          )}
                          {(invoice.status === 'SENT' || invoice.status === 'VIEWED' || invoice.status === 'PARTIAL') && (
                            <IconButton
                              as={Link}
                              href={`/dashboard/invoices/${invoice.id}/payment`}
                              aria-label="Record Payment"
                              icon={<FaDollarSign />}
                              size="sm"
                              variant="ghost"
                              colorScheme="green"
                            />
                          )}
                        </HStack>
                      </Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>

              {/* Pagination */}
              <Flex justify="center" mt={4}>
                <HStack>
                  <Button
                    size="sm"
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    isDisabled={page === 1}
                  >
                    Previous
                  </Button>
                  <Text>
                    Page {page} of {totalPages}
                  </Text>
                  <Button
                    size="sm"
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                    isDisabled={page === totalPages}
                  >
                    Next
                  </Button>
                </HStack>
              </Flex>
            </>
          )}
        </CardBody>
      </Card>
    </Box>
  );
}
