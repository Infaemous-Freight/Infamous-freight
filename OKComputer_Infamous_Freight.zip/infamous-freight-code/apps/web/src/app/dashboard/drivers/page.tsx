'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Heading,
  Button,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Badge,
  HStack,
  Input,
  InputGroup,
  InputLeftElement,
  Flex,
  Text,
  IconButton,
  useColorModeValue,
  Card,
  CardBody,
  Avatar,
} from '@chakra-ui/react';
import { FaSearch, FaPlus, FaEye, FaEdit, FaPhone, FaEnvelope } from 'react-icons/fa';
import Link from 'next/link';
import { driversApi } from '@/lib/api';

const statusColors: Record<string, string> = {
  ACTIVE: 'green',
  INACTIVE: 'gray',
  ON_DUTY: 'blue',
  OFF_DUTY: 'yellow',
  SUSPENDED: 'red',
};

export default function DriversPage() {
  const [page, setPage] = useState(1);
  const [limit] = useState(10);
  const [search, setSearch] = useState('');
  const cardBg = useColorModeValue('white', 'gray.800');

  const { data, isLoading } = useQuery({
    queryKey: ['drivers', page, limit, search],
    queryFn: () =>
      driversApi
        .getAll({
          page,
          limit,
          search: search || undefined,
        })
        .then((res) => res.data),
  });

  const drivers = data?.drivers || [];
  const totalPages = data?.pagination?.totalPages || 1;

  return (
    <Box>
      <Flex justify="space-between" align="center" mb={6}>
        <Heading>Drivers</Heading>
        <Button
          as={Link}
          href="/dashboard/drivers/new"
          leftIcon={<FaPlus />}
          colorScheme="brand"
        >
          Add Driver
        </Button>
      </Flex>

      {/* Filters */}
      <Card bg={cardBg} shadow="md" mb={6}>
        <CardBody>
          <InputGroup maxW="400px">
            <InputLeftElement pointerEvents="none">
              <FaSearch color="gray.300" />
            </InputLeftElement>
            <Input
              placeholder="Search drivers by name, license, or phone..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </InputGroup>
        </CardBody>
      </Card>

      {/* Drivers Table */}
      <Card bg={cardBg} shadow="md">
        <CardBody>
          {isLoading ? (
            <Text>Loading drivers...</Text>
          ) : (
            <>
              <Table variant="simple">
                <Thead>
                  <Tr>
                    <Th>Driver</Th>
                    <Th>License</Th>
                    <Th>Phone</Th>
                    <Th>Status</Th>
                    <Th>HOS Status</Th>
                    <Th>Rating</Th>
                    <Th>Actions</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {drivers.map((driver: any) => (
                    <Tr key={driver.id}>
                      <Td>
                        <HStack>
                          <Avatar
                            size="sm"
                            name={driver.user?.name || driver.licenseNumber}
                          />
                          <Box>
                            <Text fontWeight="medium">{driver.user?.name || 'N/A'}</Text>
                            <Text fontSize="sm" color="gray.500">
                              {driver.user?.email}
                            </Text>
                          </Box>
                        </HStack>
                      </Td>
                      <Td>{driver.licenseNumber}</Td>
                      <Td>{driver.user?.phone || 'N/A'}</Td>
                      <Td>
                        <Badge colorScheme={statusColors[driver.status] || 'gray'}>
                          {driver.status}
                        </Badge>
                      </Td>
                      <Td>
                        <Badge
                          colorScheme={
                            driver.currentHosStatus === 'DRIVING'
                              ? 'green'
                              : driver.currentHosStatus === 'ON_DUTY'
                              ? 'blue'
                              : 'gray'
                          }
                        >
                          {driver.currentHosStatus || 'OFF_DUTY'}
                        </Badge>
                      </Td>
                      <Td>
                        <Text fontWeight="bold">
                          {driver.rating?.toFixed(1) || 'N/A'}
                        </Text>
                      </Td>
                      <Td>
                        <HStack spacing={2}>
                          <IconButton
                            as={Link}
                            href={`/dashboard/drivers/${driver.id}`}
                            aria-label="View"
                            icon={<FaEye />}
                            size="sm"
                            variant="ghost"
                          />
                          <IconButton
                            as={Link}
                            href={`/dashboard/drivers/${driver.id}/edit`}
                            aria-label="Edit"
                            icon={<FaEdit />}
                            size="sm"
                            variant="ghost"
                          />
                        </HStack>
                      </Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>

              {/* Pagination */}
              <Flex justify="center" mt={4}>
                <HStack>
                  <Button
                    size="sm"
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    isDisabled={page === 1}
                  >
                    Previous
                  </Button>
                  <Text>
                    Page {page} of {totalPages}
                  </Text>
                  <Button
                    size="sm"
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                    isDisabled={page === totalPages}
                  >
                    Next
                  </Button>
                </HStack>
              </Flex>
            </>
          )}
        </CardBody>
      </Card>
    </Box>
  );
}
