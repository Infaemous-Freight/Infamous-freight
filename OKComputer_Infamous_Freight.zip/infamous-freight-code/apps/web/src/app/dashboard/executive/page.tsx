'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Heading,
  SimpleGrid,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  Card,
  CardBody,
  CardHeader,
  Text,
  Flex,
  Badge,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Progress,
  useColorModeValue,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
  Select,
  HStack,
  VStack,
  Divider,
} from '@chakra-ui/react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from 'recharts';
import { FaChartLine, FaUsers, FaTruck, FaMoneyBillWave, FaExclamationTriangle } from 'react-icons/fa';

// Mock data - in production would come from API
const revenueData = [
  { month: 'Jan', revenue: 45000, target: 50000 },
  { month: 'Feb', revenue: 52000, target: 55000 },
  { month: 'Mar', revenue: 48000, target: 55000 },
  { month: 'Apr', revenue: 61000, target: 60000 },
  { month: 'May', revenue: 68000, target: 65000 },
  { month: 'Jun', revenue: 75000, target: 70000 },
];

const shipmentData = [
  { day: 'Mon', completed: 45, pending: 12 },
  { day: 'Tue', completed: 52, pending: 8 },
  { day: 'Wed', completed: 48, pending: 15 },
  { day: 'Thu', completed: 61, pending: 10 },
  { day: 'Fri', completed: 58, pending: 14 },
  { day: 'Sat', completed: 35, pending: 5 },
  { day: 'Sun', completed: 28, pending: 3 },
];

const customerData = [
  { name: 'Enterprise', value: 45, color: '#0ea5e9' },
  { name: 'Mid-Market', value: 30, color: '#22c55e' },
  { name: 'SMB', value: 25, color: '#f59e0b' },
];

const churnRiskData = [
  { customer: 'Acme Logistics', risk: 85, mrr: 2500, reason: 'Declining usage' },
  { customer: 'Fast Freight Inc', risk: 72, mrr: 4200, reason: 'Payment issues' },
  { customer: 'RoadRunner Transport', risk: 68, mrr: 1800, reason: 'Support tickets' },
  { customer: 'Swift Carriers', risk: 45, mrr: 5600, reason: 'Low engagement' },
  { customer: 'Diamond Express', risk: 32, mrr: 3200, reason: 'Competitor mention' },
];

const COLORS = ['#0ea5e9', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6'];

function StatCard({
  title,
  value,
  change,
  changeType,
  icon: Icon,
  color,
}: {
  title: string;
  value: string;
  change: string;
  changeType: 'increase' | 'decrease';
  icon: any;
  color: string;
}) {
  const bg = useColorModeValue('white', 'gray.800');

  return (
    <Card bg={bg} shadow="md" borderLeft="4px" borderLeftColor={color}>
      <CardBody>
        <Flex justify="space-between" align="start">
          <Box>
            <Stat>
              <StatLabel color="gray.500">{title}</StatLabel>
              <StatNumber fontSize="2xl">{value}</StatNumber>
              <StatHelpText>
                <StatArrow type={changeType} />
                {change} from last month
              </StatHelpText>
            </Stat>
          </Box>
          <Box p={2} bg={`${color}20`} borderRadius="lg">
            <Icon size={24} color={color} />
          </Box>
        </Flex>
      </CardBody>
    </Card>
  );
}

export default function ExecutiveDashboard() {
  const [timeRange, setTimeRange] = useState('30d');
  const cardBg = useColorModeValue('white', 'gray.800');

  const { data: executiveData, isLoading } = useQuery({
    queryKey: ['executive-summary', timeRange],
    queryFn: async () => {
      // In production, this would call the GraphQL API
      return {
        totalCustomers: 156,
        totalShipments: 12450,
        totalRevenue: 384500,
        activeUsers: 892,
        mrr: 45200,
        arr: 542400,
        growthRate: 42,
        churnRate: 3.2,
        nps: 72,
        cac: 1200,
        ltv: 18000,
      };
    },
  });

  return (
    <Box>
      <Flex justify="space-between" align="center" mb={6}>
        <Heading>Executive Dashboard</Heading>
        <Select
          value={timeRange}
          onChange={(e) => setTimeRange(e.target.value)}
          w="150px"
        >
          <option value="7d">Last 7 days</option>
          <option value="30d">Last 30 days</option>
          <option value="90d">Last 90 days</option>
          <option value="1y">Last year</option>
        </Select>
      </Flex>

      {/* Key Metrics */}
      <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6} mb={8}>
        <StatCard
          title="Monthly Recurring Revenue"
          value={`$${(executiveData?.mrr || 0).toLocaleString()}`}
          change="12.5%"
          changeType="increase"
          icon={FaMoneyBillWave}
          color="#0ea5e9"
        />
        <StatCard
          title="Active Customers"
          value={(executiveData?.totalCustomers || 0).toString()}
          change="8.3%"
          changeType="increase"
          icon={FaUsers}
          color="#22c55e"
        />
        <StatCard
          title="Total Shipments"
          value={(executiveData?.totalShipments || 0).toLocaleString()}
          change="15.2%"
          changeType="increase"
          icon={FaTruck}
          color="#f59e0b"
        />
        <StatCard
          title="Net Revenue Retention"
          value="118%"
          change="5.1%"
          changeType="increase"
          icon={FaChartLine}
          color="#8b5cf6"
        />
      </SimpleGrid>

      {/* Charts */}
      <Tabs variant="enclosed" mb={8}>
        <TabList>
          <Tab>Revenue</Tab>
          <Tab>Shipments</Tab>
          <Tab>Customers</Tab>
          <Tab>Unit Economics</Tab>
        </TabList>

        <TabPanels>
          <TabPanel>
            <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6}>
              <Card bg={cardBg} shadow="md">
                <CardHeader>
                  <Heading size="md">Revenue Trend</Heading>
                </CardHeader>
                <CardBody>
                  <Box h="300px">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={revenueData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                        <Area
                          type="monotone"
                          dataKey="revenue"
                          stroke="#0ea5e9"
                          fill="#0ea5e9"
                          fillOpacity={0.3}
                        />
                        <Area
                          type="monotone"
                          dataKey="target"
                          stroke="#22c55e"
                          fill="#22c55e"
                          fillOpacity={0.1}
                          strokeDasharray="5 5"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </Box>
                </CardBody>
              </Card>

              <Card bg={cardBg} shadow="md">
                <CardHeader>
                  <Heading size="md">Revenue by Segment</Heading>
                </CardHeader>
                <CardBody>
                  <Box h="300px">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={customerData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {customerData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </Box>
                  <Flex justify="center" gap={4} mt={4}>
                    {customerData.map((item) => (
                      <HStack key={item.name}>
                        <Box w={3} h={3} bg={item.color} borderRadius="full" />
                        <Text fontSize="sm">{item.name} ({item.value}%)</Text>
                      </HStack>
                    ))}
                  </Flex>
                </CardBody>
              </Card>
            </SimpleGrid>
          </TabPanel>

          <TabPanel>
            <Card bg={cardBg} shadow="md">
              <CardHeader>
                <Heading size="md">Shipment Volume</Heading>
              </CardHeader>
              <CardBody>
                <Box h="400px">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={shipmentData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="completed" fill="#22c55e" name="Completed" />
                      <Bar dataKey="pending" fill="#f59e0b" name="Pending" />
                    </BarChart>
                  </ResponsiveContainer>
                </Box>
              </CardBody>
            </Card>
          </TabPanel>

          <TabPanel>
            <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6}>
              <Card bg={cardBg} shadow="md">
                <CardHeader>
                  <Heading size="md">Customer Growth</Heading>
                </CardHeader>
                <CardBody>
                  <VStack align="stretch" spacing={4}>
                    <Flex justify="space-between">
                      <Text>New Customers (MTD)</Text>
                      <Badge colorScheme="green">+24</Badge>
                    </Flex>
                    <Progress value={75} colorScheme="green" />
                    <Flex justify="space-between">
                      <Text>Churned Customers</Text>
                      <Badge colorScheme="red">-3</Badge>
                    </Flex>
                    <Progress value={5} colorScheme="red" />
                    <Flex justify="space-between">
                      <Text>Net Growth</Text>
                      <Badge colorScheme="blue">+21</Badge>
                    </Flex>
                    <Divider />
                    <Flex justify="space-between">
                      <Text fontWeight="bold">Net Revenue Retention</Text>
                      <Text fontWeight="bold" color="green.500">118%</Text>
                    </Flex>
                  </VStack>
                </CardBody>
              </Card>

              <Card bg={cardBg} shadow="md">
                <CardHeader>
                  <Heading size="md">Customer Health</Heading>
                </CardHeader>
                <CardBody>
                  <VStack align="stretch" spacing={4}>
                    <Flex justify="space-between" align="center">
                      <Text>Healthy</Text>
                      <HStack>
                        <Text fontWeight="bold">142</Text>
                        <Badge colorScheme="green">91%</Badge>
                      </HStack>
                    </Flex>
                    <Progress value={91} colorScheme="green" />
                    <Flex justify="space-between" align="center">
                      <Text>At Risk</Text>
                      <HStack>
                        <Text fontWeight="bold">11</Text>
                        <Badge colorScheme="yellow">7%</Badge>
                      </HStack>
                    </Flex>
                    <Progress value={7} colorScheme="yellow" />
                    <Flex justify="space-between" align="center">
                      <Text>Critical</Text>
                      <HStack>
                        <Text fontWeight="bold">3</Text>
                        <Badge colorScheme="red">2%</Badge>
                      </HStack>
                    </Flex>
                    <Progress value={2} colorScheme="red" />
                  </VStack>
                </CardBody>
              </Card>
            </SimpleGrid>
          </TabPanel>

          <TabPanel>
            <SimpleGrid columns={{ base: 1, lg: 3 }} spacing={6}>
              <Card bg={cardBg} shadow="md">
                <CardBody>
                  <VStack spacing={2}>
                    <Text color="gray.500">Customer Acquisition Cost</Text>
                    <Text fontSize="4xl" fontWeight="bold">
                      ${(executiveData?.cac || 1200).toLocaleString()}
                    </Text>
                    <Badge colorScheme="green">↓ 8% vs last quarter</Badge>
                  </VStack>
                </CardBody>
              </Card>

              <Card bg={cardBg} shadow="md">
                <CardBody>
                  <VStack spacing={2}>
                    <Text color="gray.500">Lifetime Value</Text>
                    <Text fontSize="4xl" fontWeight="bold">
                      ${(executiveData?.ltv || 18000).toLocaleString()}
                    </Text>
                    <Badge colorScheme="green">↑ 12% vs last quarter</Badge>
                  </VStack>
                </CardBody>
              </Card>

              <Card bg={cardBg} shadow="md">
                <CardBody>
                  <VStack spacing={2}>
                    <Text color="gray.500">LTV:CAC Ratio</Text>
                    <Text fontSize="4xl" fontWeight="bold">
                      {((executiveData?.ltv || 18000) / (executiveData?.cac || 1200)).toFixed(1)}x
                    </Text>
                    <Badge colorScheme="green">Excellent</Badge>
                  </VStack>
                </CardBody>
              </Card>
            </SimpleGrid>
          </TabPanel>
        </TabPanels>
      </Tabs>

      {/* Churn Risk Alert */}
      <Card bg={cardBg} shadow="md" mb={8}>
        <CardHeader>
          <Flex align="center" gap={2}>
            <FaExclamationTriangle color="#ef4444" />
            <Heading size="md">Churn Risk Alerts</Heading>
          </Flex>
        </CardHeader>
        <CardBody>
          <Table variant="simple">
            <Thead>
              <Tr>
                <Th>Customer</Th>
                <Th>Risk Score</Th>
                <Th>MRR</Th>
                <Th>Risk Factors</Th>
                <Th>Action</Th>
              </Tr>
            </Thead>
            <Tbody>
              {churnRiskData.map((customer) => (
                <Tr key={customer.customer}>
                  <Td fontWeight="medium">{customer.customer}</Td>
                  <Td>
                    <Badge
                      colorScheme={
                        customer.risk > 80 ? 'red' : customer.risk > 60 ? 'orange' : 'yellow'
                      }
                    >
                      {customer.risk}%
                    </Badge>
                  </Td>
                  <Td>${customer.mrr.toLocaleString()}</Td>
                  <Td>{customer.reason}</Td>
                  <Td>
                    <Badge colorScheme="blue" cursor="pointer">
                      View Details
                    </Badge>
                  </Td>
                </Tr>
              ))}
            </Tbody>
          </Table>
        </CardBody>
      </Card>

      {/* Efficiency Metrics */}
      <SimpleGrid columns={{ base: 1, lg: 3 }} spacing={6}>
        <Card bg={cardBg} shadow="md">
          <CardHeader>
            <Heading size="md">On-Time Delivery Rate</Heading>
          </CardHeader>
          <CardBody>
            <VStack spacing={4}>
              <Text fontSize="5xl" fontWeight="bold" color="green.500">
                94.2%
              </Text>
              <Progress value={94.2} colorScheme="green" size="lg" />
              <Text color="gray.500">Target: 95%</Text>
            </VStack>
          </CardBody>
        </Card>

        <Card bg={cardBg} shadow="md">
          <CardHeader>
            <Heading size="md">Driver Utilization</Heading>
          </CardHeader>
          <CardBody>
            <VStack spacing={4}>
              <Text fontSize="5xl" fontWeight="bold" color="blue.500">
                78.5%
              </Text>
              <Progress value={78.5} colorScheme="blue" size="lg" />
              <Text color="gray.500">Target: 80%</Text>
            </VStack>
          </CardBody>
        </Card>

        <Card bg={cardBg} shadow="md">
          <CardHeader>
            <Heading size="md">Fuel Efficiency</Heading>
          </CardHeader>
          <CardBody>
            <VStack spacing={4}>
              <Text fontSize="5xl" fontWeight="bold" color="purple.500">
                7.2 MPG
              </Text>
              <Progress value={72} colorScheme="purple" size="lg" />
              <Text color="gray.500">Industry avg: 6.5 MPG</Text>
            </VStack>
          </CardBody>
        </Card>
      </SimpleGrid>
    </Box>
  );
}
