'use client';

import {
  Box,
  Container,
  Heading,
  Text,
  Button,
  VStack,
  HStack,
  SimpleGrid,
  Card,
  CardBody,
  CardHeader,
  Icon,
  useColorModeValue,
  Flex,
  Badge,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
} from '@chakra-ui/react';
import {
  FaTruck,
  FaRoute,
  FaChartLine,
  FaUsers,
  FaBox,
  FaMapMarkedAlt,
  FaClock,
  FaDollarSign,
} from 'react-icons/fa';
import Link from 'next/link';

const features = [
  {
    icon: FaTruck,
    title: 'Fleet Management',
    description: 'Track and manage your entire fleet in real-time with GPS integration.',
  },
  {
    icon: FaRoute,
    title: 'Route Optimization',
    description: 'AI-powered route planning to minimize fuel costs and delivery times.',
  },
  {
    icon: FaChartLine,
    title: 'Analytics Dashboard',
    description: 'Comprehensive insights into your operations and performance metrics.',
  },
  {
    icon: FaUsers,
    title: 'Driver Management',
    description: 'Manage drivers, HOS compliance, and performance tracking.',
  },
  {
    icon: FaBox,
    title: 'Load Matching',
    description: 'AI-driven load recommendations to maximize truck utilization.',
  },
  {
    icon: FaMapMarkedAlt,
    title: 'Real-time Tracking',
    description: 'Live shipment tracking with ETA predictions and geofencing alerts.',
  },
];

const stats = [
  { label: 'Active Shipments', value: '1,234', change: '+12%', icon: FaBox },
  { label: 'On-Time Delivery', value: '98.5%', change: '+2.3%', icon: FaClock },
  { label: 'Fleet Utilization', value: '87%', change: '+5%', icon: FaTruck },
  { label: 'Revenue Growth', value: '$2.4M', change: '+18%', icon: FaDollarSign },
];

export default function HomePage() {
  const bgGradient = useColorModeValue(
    'linear(to-br, brand.50, white)',
    'linear(to-br, gray.900, gray.800)'
  );
  const cardBg = useColorModeValue('white', 'gray.800');

  return (
    <Box minH="100vh">
      {/* Hero Section */}
      <Box bgGradient={bgGradient} py={20}>
        <Container maxW="7xl">
          <VStack spacing={8} textAlign="center">
            <Badge colorScheme="brand" fontSize="sm" px={3} py={1} borderRadius="full">
              v2.2 Now Available
            </Badge>
            <Heading
              as="h1"
              size="2xl"
              fontWeight="bold"
              lineHeight="shorter"
            >
              AI-Native Freight Management
              <br />
              <Text as="span" color="brand.500">
                for Modern Fleets
              </Text>
            </Heading>
            <Text fontSize="xl" color="gray.600" maxW="2xl">
              Streamline your trucking operations with intelligent load matching,
              real-time tracking, and automated dispatch. Built for carriers who
              demand more.
            </Text>
            <HStack spacing={4} pt={4}>
              <Button
                as={Link}
                href="/login"
                size="lg"
                colorScheme="brand"
                px={8}
              >
                Get Started
              </Button>
              <Button
                as={Link}
                href="/demo"
                size="lg"
                variant="outline"
                px={8}
              >
                View Demo
              </Button>
            </HStack>
          </VStack>
        </Container>
      </Box>

      {/* Stats Section */}
      <Box py={16} bg={useColorModeValue('gray.50', 'gray.900')}>
        <Container maxW="7xl">
          <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
            {stats.map((stat) => (
              <Card key={stat.label} bg={cardBg} shadow="md">
                <CardBody>
                  <Flex align="center" justify="space-between">
                    <Stat>
                      <StatLabel color="gray.500">{stat.label}</StatLabel>
                      <StatNumber fontSize="3xl">{stat.value}</StatNumber>
                      <StatHelpText color="success.500">{stat.change}</StatHelpText>
                    </Stat>
                    <Icon as={stat.icon} boxSize={10} color="brand.500" />
                  </Flex>
                </CardBody>
              </Card>
            ))}
          </SimpleGrid>
        </Container>
      </Box>

      {/* Features Section */}
      <Box py={20}>
        <Container maxW="7xl">
          <VStack spacing={12}>
            <VStack spacing={4} textAlign="center">
              <Heading size="xl">Everything You Need to Run Your Fleet</Heading>
              <Text fontSize="lg" color="gray.600" maxW="2xl">
                From dispatch to delivery, our platform provides all the tools you
                need to manage your trucking operations efficiently.
              </Text>
            </VStack>

            <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={8} w="full">
              {features.map((feature) => (
                <Card key={feature.title} bg={cardBg} shadow="md" h="full">
                  <CardHeader>
                    <Icon
                      as={feature.icon}
                      boxSize={12}
                      color="brand.500"
                      mb={4}
                    />
                    <Heading size="md">{feature.title}</Heading>
                  </CardHeader>
                  <CardBody pt={0}>
                    <Text color="gray.600">{feature.description}</Text>
                  </CardBody>
                </Card>
              ))}
            </SimpleGrid>
          </VStack>
        </Container>
      </Box>

      {/* CTA Section */}
      <Box py={20} bg="brand.500">
        <Container maxW="7xl">
          <VStack spacing={6} textAlign="center" color="white">
            <Heading size="xl">Ready to Transform Your Fleet?</Heading>
            <Text fontSize="lg" maxW="2xl" opacity={0.9}>
              Join thousands of carriers who have streamlined their operations
              with Infamous Freight.
            </Text>
            <Button
              as={Link}
              href="/signup"
              size="lg"
              bg="white"
              color="brand.500"
              _hover={{ bg: 'gray.100' }}
              px={8}
            >
              Start Free Trial
            </Button>
          </VStack>
        </Container>
      </Box>

      {/* Footer */}
      <Box py={8} borderTop="1px" borderColor={useColorModeValue('gray.200', 'gray.700')}>
        <Container maxW="7xl">
          <Flex
            direction={{ base: 'column', md: 'row' }}
            justify="space-between"
            align="center"
            gap={4}
          >
            <Text color="gray.500">
              © 2025 Infamous Freight. All rights reserved.
            </Text>
            <HStack spacing={6}>
              <Link href="/privacy">Privacy</Link>
              <Link href="/terms">Terms</Link>
              <Link href="/support">Support</Link>
            </HStack>
          </Flex>
        </Container>
      </Box>
    </Box>
  );
}
