'use client';

import {
  Box,
  VStack,
  Link,
  Text,
  Icon,
  useColorModeValue,
  Flex,
  Divider,
  BoxProps,
} from '@chakra-ui/react';
import {
  FaHome,
  FaTruck,
  FaUsers,
  FaBox,
  FaFileInvoice,
  FaMapMarkedAlt,
  FaChartBar,
  FaCog,
  FaSignOutAlt,
} from 'react-icons/fa';
import NextLink from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuthStore } from '@/store/auth';

interface NavItem {
  label: string;
  href: string;
  icon: any;
}

const navItems: NavItem[] = [
  { label: 'Dashboard', href: '/dashboard', icon: FaHome },
  { label: 'Shipments', href: '/dashboard/shipments', icon: FaBox },
  { label: 'Drivers', href: '/dashboard/drivers', icon: FaUsers },
  { label: 'Vehicles', href: '/dashboard/vehicles', icon: FaTruck },
  { label: 'Tracking', href: '/dashboard/tracking', icon: FaMapMarkedAlt },
  { label: 'Invoices', href: '/dashboard/invoices', icon: FaFileInvoice },
  { label: 'Analytics', href: '/dashboard/analytics', icon: FaChartBar },
  { label: 'Settings', href: '/dashboard/settings', icon: FaCog },
];

export function Sidebar(props: BoxProps) {
  const pathname = usePathname();
  const logout = useAuthStore((state) => state.logout);
  const user = useAuthStore((state) => state.user);

  const bgColor = useColorModeValue('white', 'gray.800');
  const borderColor = useColorModeValue('gray.200', 'gray.700');
  const activeBg = useColorModeValue('brand.50', 'brand.900');
  const activeColor = useColorModeValue('brand.600', 'brand.200');

  return (
    <Box
      as="nav"
      pos="fixed"
      top="0"
      left="0"
      zIndex="sticky"
      h="full"
      pb="10"
      overflowX="hidden"
      overflowY="auto"
      bg={bgColor}
      borderRight="1px"
      borderColor={borderColor}
      w="60"
      {...props}
    >
      <Flex h="20" alignItems="center" mx="8" justifyContent="space-between">
        <Text fontSize="2xl" fontWeight="bold" color="brand.500">
          Infamous
        </Text>
      </Flex>

      <Divider borderColor={borderColor} />

      <VStack spacing={1} align="stretch" px={4} py={4}>
        {navItems.map((item) => {
          const isActive = pathname === item.href || pathname?.startsWith(`${item.href}/`);
          return (
            <Link
              key={item.href}
              as={NextLink}
              href={item.href}
              display="flex"
              alignItems="center"
              px={4}
              py={3}
              borderRadius="lg"
              role="group"
              cursor="pointer"
              bg={isActive ? activeBg : 'transparent'}
              color={isActive ? activeColor : useColorModeValue('gray.600', 'gray.400')}
              fontWeight={isActive ? 'semibold' : 'normal'}
              _hover={{
                bg: activeBg,
                color: activeColor,
              }}
              transition="all 0.2s"
            >
              <Icon
                mr={4}
                fontSize="16"
                as={item.icon}
              />
              {item.label}
            </Link>
          );
        })}
      </VStack>

      <Divider borderColor={borderColor} mt="auto" />

      <Box px={4} py={4}>
        <Link
          display="flex"
          alignItems="center"
          px={4}
          py={3}
          borderRadius="lg"
          cursor="pointer"
          color={useColorModeValue('gray.600', 'gray.400')}
          _hover={{
            bg: useColorModeValue('red.50', 'red.900'),
            color: useColorModeValue('red.600', 'red.200'),
          }}
          onClick={logout}
          transition="all 0.2s"
        >
          <Icon mr={4} fontSize="16" as={FaSignOutAlt} />
          Sign Out
        </Link>
      </Box>

      <Box px={6} py={4}>
        <Text fontSize="xs" color="gray.500">
          Logged in as
        </Text>
        <Text fontSize="sm" fontWeight="medium" noOfLines={1}>
          {user?.firstName} {user?.lastName}
        </Text>
        <Text fontSize="xs" color="gray.500" textTransform="capitalize">
          {user?.role?.toLowerCase()}
        </Text>
      </Box>
    </Box>
  );
}
