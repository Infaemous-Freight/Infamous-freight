'use client';

import {
  Box,
  Flex,
  IconButton,
  useColorModeValue,
  Text,
  HStack,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Avatar,
  Badge,
  Popover,
  PopoverTrigger,
  PopoverContent,
  PopoverBody,
  VStack,
  Divider,
  Button,
} from '@chakra-ui/react';
import { BellIcon } from '@chakra-ui/icons';
import { FaUser, FaCog, FaSignOutAlt } from 'react-icons/fa';
import Link from 'next/link';
import { useAuthStore } from '@/store/auth';

const notifications = [
  {
    id: '1',
    title: 'Shipment Delivered',
    message: 'Shipment SHP-001234 has been delivered successfully.',
    time: '5 minutes ago',
    read: false,
    type: 'success',
  },
  {
    id: '2',
    title: 'Driver HOS Alert',
    message: 'Driver John Smith is approaching daily driving limit.',
    time: '1 hour ago',
    read: false,
    type: 'warning',
  },
  {
    id: '3',
    title: 'New Invoice Paid',
    message: 'Invoice INV-5678 has been paid in full.',
    time: '2 hours ago',
    read: true,
    type: 'info',
  },
];

export function Header() {
  const user = useAuthStore((state) => state.user);
  const logout = useAuthStore((state) => state.logout);
  const bgColor = useColorModeValue('white', 'gray.800');
  const borderColor = useColorModeValue('gray.200', 'gray.700');

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <Flex
      h={16}
      alignItems="center"
      justifyContent="space-between"
      bg={bgColor}
      borderBottom="1px"
      borderColor={borderColor}
      px={6}
    >
      <Text fontSize="lg" fontWeight="semibold" color="gray.600">
        {new Date().toLocaleDateString('en-US', {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric',
        })}
      </Text>

      <HStack spacing={4}>
        {/* Notifications */}
        <Popover placement="bottom-end">
          <PopoverTrigger>
            <Box position="relative">
              <IconButton
                aria-label="Notifications"
                icon={<BellIcon />}
                variant="ghost"
                size="md"
              />
              {unreadCount > 0 && (
                <Badge
                  position="absolute"
                  top="0"
                  right="0"
                  colorScheme="danger"
                  borderRadius="full"
                  fontSize="xs"
                  minW="18px"
                  textAlign="center"
                >
                  {unreadCount}
                </Badge>
              )}
            </Box>
          </PopoverTrigger>
          <PopoverContent w="360px">
            <PopoverBody p={0}>
              <Box p={4} borderBottom="1px" borderColor={borderColor}>
                <Flex justify="space-between" align="center">
                  <Text fontWeight="semibold">Notifications</Text>
                  <Button size="xs" variant="ghost" colorScheme="brand">
                    Mark all read
                  </Button>
                </Flex>
              </Box>
              <VStack spacing={0} align="stretch" maxH="400px" overflowY="auto">
                {notifications.map((notification) => (
                  <Box
                    key={notification.id}
                    p={4}
                    borderBottom="1px"
                    borderColor={borderColor}
                    bg={notification.read ? 'transparent' : 'brand.50'}
                    cursor="pointer"
                    _hover={{ bg: 'gray.50' }}
                  >
                    <Flex justify="space-between" align="start" mb={1}>
                      <Text fontWeight="semibold" fontSize="sm">
                        {notification.title}
                      </Text>
                      <Text fontSize="xs" color="gray.500">
                        {notification.time}
                      </Text>
                    </Flex>
                    <Text fontSize="sm" color="gray.600" noOfLines={2}>
                      {notification.message}
                    </Text>
                  </Box>
                ))}
              </VStack>
              <Box p={3} borderTop="1px" borderColor={borderColor} textAlign="center">
                <Link href="/dashboard/notifications">
                  <Text fontSize="sm" color="brand.500" fontWeight="medium">
                    View all notifications
                  </Text>
                </Link>
              </Box>
            </PopoverBody>
          </PopoverContent>
        </Popover>

        <Divider orientation="vertical" h={6} />

        {/* User Menu */}
        <Menu>
          <MenuButton>
            <HStack spacing={3}>
              <VStack spacing={0} align="end" display={{ base: 'none', md: 'flex' }}>
                <Text fontSize="sm" fontWeight="medium">
                  {user?.firstName} {user?.lastName}
                </Text>
                <Text fontSize="xs" color="gray.500" textTransform="capitalize">
                  {user?.role?.toLowerCase()}
                </Text>
              </VStack>
              <Avatar
                size="sm"
                name={`${user?.firstName} ${user?.lastName}`}
                bg="brand.500"
              />
            </HStack>
          </MenuButton>
          <MenuList>
            <MenuItem as={Link} href="/dashboard/profile" icon={<FaUser />}>
              Profile
            </MenuItem>
            <MenuItem as={Link} href="/dashboard/settings" icon={<FaCog />}>
              Settings
            </MenuItem>
            <Divider />
            <MenuItem icon={<FaSignOutAlt />} onClick={logout}>
              Sign Out
            </MenuItem>
          </MenuList>
        </Menu>
      </HStack>
    </Flex>
  );
}
