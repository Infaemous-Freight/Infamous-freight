export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: 'ADMIN' | 'MANAGER' | 'DISPATCHER' | 'DRIVER' | 'ACCOUNTANT';
  status: 'ACTIVE' | 'INACTIVE' | 'SUSPENDED';
  phone?: string;
  lastLoginAt?: string;
  createdAt: string;
  organization: {
    id: string;
    name: string;
  };
}

export interface Driver {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  cdlNumber: string;
  cdlState: string;
  cdlExpiration: string;
  cdlClass?: string;
  medicalExpiration?: string;
  status: 'AVAILABLE' | 'ON_DUTY' | 'OFF_DUTY' | 'IN_TRANSIT' | 'SLEEPER_BERTH';
  hireDate?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  address?: string;
  dateOfBirth?: string;
  user?: {
    id: string;
    email: string;
    status: string;
    lastLoginAt?: string;
  };
  _count?: {
    shipments: number;
    hosLogs: number;
  };
}

export interface Vehicle {
  id: string;
  unitNumber: string;
  type: 'TRACTOR' | 'STRAIGHT_TRUCK' | 'VAN' | 'REEFER' | 'FLATBED' | 'TANKER' | 'CAR_HAULER' | 'OTHER';
  make: string;
  model: string;
  year: number;
  vin: string;
  licensePlate: string;
  licensePlateState: string;
  status: 'ACTIVE' | 'INACTIVE' | 'MAINTENANCE' | 'RETIRED';
  gvw?: number;
  fuelType?: string;
  color?: string;
  currentMileage?: number;
  registrationExpiration?: string;
  insuranceExpiration?: string;
  iftaStatus: boolean;
  eldDeviceId?: string;
  gpsDeviceId?: string;
  drivers?: Array<{
    driver: Driver;
    isPrimary: boolean;
    assignedAt: string;
  }>;
  _count?: {
    shipments: number;
    maintenanceRecords: number;
  };
}

export interface Shipment {
  id: string;
  referenceNumber: string;
  customerName: string;
  customerEmail?: string;
  customerPhone?: string;
  status: 'PENDING' | 'DISPATCHED' | 'AT_PICKUP' | 'PICKED_UP' | 'IN_TRANSIT' | 'AT_DROPOFF' | 'DELIVERED' | 'CANCELLED';
  equipmentType: string;
  weight?: number;
  dimensions?: {
    length?: number;
    width?: number;
    height?: number;
  };
  commodity?: string;
  rate?: number;
  rateType: 'PER_MILE' | 'FLAT' | 'PER_HOUR' | 'TON';
  distance?: number;
  totalMiles?: number;
  estimatedFuelCost?: number;
  origin: string;
  originAddress?: string;
  originCity: string;
  originState: string;
  originZip?: string;
  originLatitude?: number;
  originLongitude?: number;
  destination: string;
  destinationAddress?: string;
  destinationCity: string;
  destinationState: string;
  destinationZip?: string;
  destinationLatitude?: number;
  destinationLongitude?: number;
  scheduledPickupDate?: string;
  scheduledDeliveryDate?: string;
  actualPickupDate?: string;
  actualDeliveryDate?: string;
  driverId?: string;
  vehicleId?: string;
  driver?: Driver;
  vehicle?: Vehicle;
  stops: Stop[];
  createdAt: string;
  updatedAt: string;
}

export interface Stop {
  id: string;
  sequence: number;
  type: 'PICKUP' | 'DROPOFF' | 'WAYPOINT';
  name?: string;
  address?: string;
  city: string;
  state: string;
  zip?: string;
  latitude: number;
  longitude: number;
  scheduledArrival?: string;
  scheduledDeparture?: string;
  actualArrival?: string;
  actualDeparture?: string;
  notes?: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  shipmentId: string;
  shipment?: Shipment;
  invoiceDate: string;
  dueDate: string;
  status: 'DRAFT' | 'SENT' | 'PARTIAL' | 'PAID' | 'OVERDUE' | 'CANCELLED';
  lineItems: any[];
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  totalAmount: number;
  amountPaid: number;
  balanceDue: number;
  notes?: string;
  terms?: string;
  sentAt?: string;
  paidAt?: string;
  payments?: Payment[];
}

export interface Payment {
  id: string;
  invoiceId: string;
  amount: number;
  method: 'CASH' | 'CHECK' | 'ACH' | 'CREDIT_CARD' | 'DEBIT_CARD' | 'WIRE' | 'FACTORING';
  date: string;
  reference?: string;
  notes?: string;
  createdAt: string;
}

export interface TrackingEvent {
  id: string;
  shipmentId: string;
  latitude: number;
  longitude: number;
  speed?: number;
  heading?: number;
  odometer?: number;
  ignitionStatus?: boolean;
  engineHours?: number;
  batteryVoltage?: number;
  locationName?: string;
  notes?: string;
  source?: string;
  recordedAt: string;
}

export interface HosLog {
  id: string;
  driverId: string;
  date: string;
  dutyStatus: 'OFF_DUTY' | 'SB' | 'D' | 'ON_DUTY';
  hours: number;
  startTime?: string;
  endTime?: string;
  location?: string;
  remarks?: string;
}

export interface MaintenanceRecord {
  id: string;
  vehicleId: string;
  date: string;
  type: string;
  description: string;
  cost?: number;
  mileage?: number;
  vendor?: string;
  invoiceNumber?: string;
  notes?: string;
}

export interface DashboardStats {
  activeShipments: number;
  availableDrivers: number;
  activeVehicles: number;
  pendingInvoices: number;
  todayDeliveries: number;
  revenueToday: number;
}

export interface KpiData {
  onTimeDelivery: number;
  averageTransitTime: number;
  costPerMile: number;
  revenuePerMile: number;
  driverUtilization: number;
  fuelEfficiency: number;
}

export interface Notification {
  id: string;
  type: 'INFO' | 'WARNING' | 'ERROR' | 'SUCCESS';
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}
