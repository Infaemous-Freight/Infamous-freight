'use client';

import { useState, useEffect, useCallback } from 'react';
import { trackingApi } from '@/lib/api';
import { useWebSocket } from './useWebSocket';

interface TrackingLocation {
  latitude: number;
  longitude: number;
  speed?: number;
  heading?: number;
  timestamp: string;
}

interface TrackingEvent {
  id: string;
  type: string;
  latitude: number;
  longitude: number;
  notes?: string;
  recordedAt: string;
}

interface UseTrackingOptions {
  shipmentId?: string;
  enableWebSocket?: boolean;
}

export function useTracking(options: UseTrackingOptions = {}) {
  const { shipmentId, enableWebSocket = true } = options;
  const [locations, setLocations] = useState<TrackingLocation[]>([]);
  const [events, setEvents] = useState<TrackingEvent[]>([]);
  const [currentLocation, setCurrentLocation] = useState<TrackingLocation | null>(null);
  const [eta, setEta] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const fetchTrackingData = useCallback(async () => {
    if (!shipmentId) return;

    setIsLoading(true);
    setError(null);

    try {
      const [trackingRes, etaRes] = await Promise.all([
        trackingApi.getShipmentTracking(shipmentId),
        trackingApi.getEta(shipmentId),
      ]);

      const trackingData = trackingRes.data;
      setEvents(trackingData.events || []);
      setLocations(trackingData.locations || []);
      
      if (trackingData.locations?.length > 0) {
        setCurrentLocation(trackingData.locations[trackingData.locations.length - 1]);
      }

      setEta(etaRes.data.eta);
    } catch (err) {
      setError(err as Error);
    } finally {
      setIsLoading(false);
    }
  }, [shipmentId]);

  const { subscribe, unsubscribe, isConnected } = useWebSocket({
    onMessage: (message) => {
      if (message.type === 'location_update' && message.shipmentId === shipmentId) {
        const newLocation = message.data;
        setCurrentLocation(newLocation);
        setLocations((prev) => [...prev, newLocation]);
      } else if (message.type === 'status_update' && message.shipmentId === shipmentId) {
        // Refresh tracking data on status update
        fetchTrackingData();
      }
    },
  });

  useEffect(() => {
    fetchTrackingData();
  }, [fetchTrackingData]);

  useEffect(() => {
    if (enableWebSocket && shipmentId && isConnected) {
      subscribe('tracking', shipmentId);
      return () => {
        unsubscribe('tracking', shipmentId);
      };
    }
  }, [enableWebSocket, shipmentId, isConnected, subscribe, unsubscribe]);

  return {
    locations,
    events,
    currentLocation,
    eta,
    isLoading,
    error,
    isConnected,
    refetch: fetchTrackingData,
  };
}
