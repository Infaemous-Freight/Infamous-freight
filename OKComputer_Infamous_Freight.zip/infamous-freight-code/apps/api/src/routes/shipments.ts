import { Router } from 'express';
import { PrismaClient, ShipmentStatus } from '@prisma/client';
import { body, param, query, validationResult } from 'express-validator';
import { authenticate, AuthRequest, requireOrganization } from '../middleware/auth';

const router = Router();
const prisma = new PrismaClient();

// Apply authentication to all routes
router.use(authenticate);

// Get all shipments
router.get(
  '/',
  [
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 100 }),
    query('status').optional().isIn(Object.values(ShipmentStatus)),
  ],
  async (req: AuthRequest, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        details: errors.array(),
      });
    }

    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const status = req.query.status as ShipmentStatus | undefined;

    try {
      const where: any = {
        organizationId: req.user!.organizationId,
      };

      if (status) {
        where.status = status;
      }

      const [shipments, total] = await Promise.all([
        prisma.shipment.findMany({
          where,
          skip: (page - 1) * limit,
          take: limit,
          orderBy: { createdAt: 'desc' },
          include: {
            driver: {
              select: {
                id: true,
                user: {
                  select: {
                    name: true,
                  },
                },
              },
            },
            vehicle: {
              select: {
                id: true,
                make: true,
                model: true,
                plateNumber: true,
              },
            },
            trackingEvents: {
              orderBy: { createdAt: 'desc' },
              take: 5,
            },
          },
        }),
        prisma.shipment.count({ where }),
      ]);

      res.json({
        data: shipments,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      });
    } catch (error) {
      console.error('Get shipments error:', error);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: 'Failed to fetch shipments',
      });
    }
  }
);

// Get shipment by ID
router.get(
  '/:id',
  [param('id').isUUID()],
  async (req: AuthRequest, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        details: errors.array(),
      });
    }

    const { id } = req.params;

    try {
      const shipment = await prisma.shipment.findFirst({
        where: {
          id,
          organizationId: req.user!.organizationId,
        },
        include: {
          driver: {
            include: {
              user: {
                select: {
                  name: true,
                  email: true,
                  phone: true,
                },
              },
            },
          },
          vehicle: true,
          trackingEvents: {
            orderBy: { createdAt: 'desc' },
          },
          invoice: true,
        },
      });

      if (!shipment) {
        return res.status(404).json({
          error: 'NOT_FOUND',
          message: 'Shipment not found',
        });
      }

      res.json(shipment);
    } catch (error) {
      console.error('Get shipment error:', error);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: 'Failed to fetch shipment',
      });
    }
  }
);

// Create shipment
router.post(
  '/',
  requireOrganization,
  [
    body('bolNumber').notEmpty().trim(),
    body('shipperName').notEmpty().trim(),
    body('shipperAddress').notEmpty().trim(),
    body('shipperCity').notEmpty().trim(),
    body('shipperState').notEmpty().trim(),
    body('shipperZip').notEmpty().trim(),
    body('consigneeName').notEmpty().trim(),
    body('consigneeAddress').notEmpty().trim(),
    body('consigneeCity').notEmpty().trim(),
    body('consigneeState').notEmpty().trim(),
    body('consigneeZip').notEmpty().trim(),
    body('pickupLatitude').isFloat(),
    body('pickupLongitude').isFloat(),
    body('deliveryLatitude').isFloat(),
    body('deliveryLongitude').isFloat(),
    body('pickupDate').isISO8601(),
    body('deliveryDate').isISO8601(),
    body('weight').isFloat({ min: 0 }),
    body('rate').isFloat({ min: 0 }),
  ],
  async (req: AuthRequest, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        details: errors.array(),
      });
    }

    try {
      // Calculate distance if not provided
      let distance = req.body.distance;
      if (!distance) {
        distance = calculateDistance(
          req.body.pickupLatitude,
          req.body.pickupLongitude,
          req.body.deliveryLatitude,
          req.body.deliveryLongitude
        );
      }

      const shipment = await prisma.shipment.create({
        data: {
          ...req.body,
          distance,
          organizationId: req.user!.organizationId,
        },
        include: {
          driver: true,
          vehicle: true,
        },
      });

      // Create initial tracking event
      await prisma.trackingEvent.create({
        data: {
          shipmentId: shipment.id,
          eventType: 'CREATED',
          notes: 'Shipment created',
        },
      });

      res.status(201).json(shipment);
    } catch (error) {
      console.error('Create shipment error:', error);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: 'Failed to create shipment',
      });
    }
  }
);

// Update shipment
router.put(
  '/:id',
  [param('id').isUUID()],
  async (req: AuthRequest, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        details: errors.array(),
      });
    }

    const { id } = req.params;

    try {
      // Verify shipment belongs to user's organization
      const existingShipment = await prisma.shipment.findFirst({
        where: {
          id,
          organizationId: req.user!.organizationId,
        },
      });

      if (!existingShipment) {
        return res.status(404).json({
          error: 'NOT_FOUND',
          message: 'Shipment not found',
        });
      }

      const shipment = await prisma.shipment.update({
        where: { id },
        data: req.body,
        include: {
          driver: true,
          vehicle: true,
        },
      });

      res.json(shipment);
    } catch (error) {
      console.error('Update shipment error:', error);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: 'Failed to update shipment',
      });
    }
  }
);

// Assign driver to shipment
router.post(
  '/:id/assign',
  [
    param('id').isUUID(),
    body('driverId').isUUID(),
    body('vehicleId').optional().isUUID(),
  ],
  async (req: AuthRequest, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        details: errors.array(),
      });
    }

    const { id } = req.params;
    const { driverId, vehicleId } = req.body;

    try {
      // Verify shipment belongs to user's organization
      const shipment = await prisma.shipment.findFirst({
        where: {
          id,
          organizationId: req.user!.organizationId,
        },
      });

      if (!shipment) {
        return res.status(404).json({
          error: 'NOT_FOUND',
          message: 'Shipment not found',
        });
      }

      // Verify driver belongs to organization
      const driver = await prisma.driver.findFirst({
        where: {
          id: driverId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!driver) {
        return res.status(404).json({
          error: 'NOT_FOUND',
          message: 'Driver not found',
        });
      }

      // Update shipment
      const updatedShipment = await prisma.shipment.update({
        where: { id },
        data: {
          driverId,
          vehicleId,
          status: 'ASSIGNED',
        },
        include: {
          driver: true,
          vehicle: true,
        },
      });

      // Create tracking event
      await prisma.trackingEvent.create({
        data: {
          shipmentId: id,
          eventType: 'ASSIGNED',
          notes: `Assigned to driver: ${driver.userId}`,
        },
      });

      res.json(updatedShipment);
    } catch (error) {
      console.error('Assign shipment error:', error);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: 'Failed to assign shipment',
      });
    }
  }
);

// Update shipment status
router.post(
  '/:id/status',
  [
    param('id').isUUID(),
    body('status').isIn(Object.values(ShipmentStatus)),
    body('location').optional().trim(),
    body('notes').optional().trim(),
  ],
  async (req: AuthRequest, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        details: errors.array(),
      });
    }

    const { id } = req.params;
    const { status, location, notes } = req.body;

    try {
      // Verify shipment belongs to user's organization
      const shipment = await prisma.shipment.findFirst({
        where: {
          id,
          organizationId: req.user!.organizationId,
        },
      });

      if (!shipment) {
        return res.status(404).json({
          error: 'NOT_FOUND',
          message: 'Shipment not found',
        });
      }

      // Update shipment status
      const updatedShipment = await prisma.shipment.update({
        where: { id },
        data: { status },
      });

      // Create tracking event
      await prisma.trackingEvent.create({
        data: {
          shipmentId: id,
          eventType: status as any,
          location,
          notes,
        },
      });

      // If delivered, create invoice
      if (status === 'DELIVERED') {
        await prisma.invoice.create({
          data: {
            invoiceNumber: `INV-${Date.now()}`,
            amount: shipment.rate,
            totalAmount: shipment.rate,
            status: 'DRAFT',
            dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
            shipmentId: id,
            organizationId: req.user!.organizationId,
          },
        });
      }

      res.json(updatedShipment);
    } catch (error) {
      console.error('Update status error:', error);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: 'Failed to update shipment status',
      });
    }
  }
);

// Delete shipment
router.delete(
  '/:id',
  [param('id').isUUID()],
  async (req: AuthRequest, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        details: errors.array(),
      });
    }

    const { id } = req.params;

    try {
      // Verify shipment belongs to user's organization
      const shipment = await prisma.shipment.findFirst({
        where: {
          id,
          organizationId: req.user!.organizationId,
        },
      });

      if (!shipment) {
        return res.status(404).json({
          error: 'NOT_FOUND',
          message: 'Shipment not found',
        });
      }

      // Only allow deletion of pending shipments
      if (shipment.status !== 'PENDING') {
        return res.status(400).json({
          error: 'BAD_REQUEST',
          message: 'Cannot delete shipment that has been assigned or is in transit',
        });
      }

      await prisma.shipment.delete({
        where: { id },
      });

      res.json({ message: 'Shipment deleted successfully' });
    } catch (error) {
      console.error('Delete shipment error:', error);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: 'Failed to delete shipment',
      });
    }
  }
);

// Helper function to calculate distance between two points
function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 3959; // Earth's radius in miles
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
      Math.cos(toRadians(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

function toRadians(degrees: number): number {
  return degrees * (Math.PI / 180);
}

export default router;
