import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { body, validationResult } from 'express-validator';
import OpenAI from 'openai';
import { authenticate, AuthRequest } from '../middleware/auth';
import { aiRateLimiter } from '../middleware/rateLimiter';

const router = Router();
const prisma = new PrismaClient();

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Apply authentication and rate limiting
router.use(authenticate);
router.use(aiRateLimiter);

// AI Load Recommendation
router.post(
  '/load-recommendation',
  [
    body('currentLocation').notEmpty().trim(),
    body('currentLatitude').isFloat(),
    body('currentLongitude').isFloat(),
    body('maxDistance').optional().isInt({ min: 1 }),
    body('minRate').optional().isFloat({ min: 0 }),
  ],
  async (req: AuthRequest, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        details: errors.array(),
      });
    }

    const { currentLocation, currentLatitude, currentLongitude, maxDistance = 100, minRate = 0 } = req.body;

    try {
      // Get available shipments near driver
      const nearbyShipments = await prisma.shipment.findMany({
        where: {
          organizationId: req.user!.organizationId,
          status: 'PENDING',
          rate: { gte: minRate },
        },
        include: {
          trackingEvents: {
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
        },
      });

      // Calculate distance and score for each shipment
      const scoredShipments = nearbyShipments.map((shipment) => {
        const distanceToPickup = calculateDistance(
          currentLatitude,
          currentLongitude,
          shipment.pickupLatitude,
          shipment.pickupLongitude
        );

        const ratePerMile = shipment.rate / (shipment.distance || 1);
        const score = calculateLoadScore(shipment.rate, shipment.distance || 1, distanceToPickup);

        return {
          ...shipment,
          distanceToPickup,
          ratePerMile: Math.round(ratePerMile * 100) / 100,
          score,
        };
      });

      // Filter by max distance and sort by score
      const recommendations = scoredShipments
        .filter((s) => s.distanceToPickup <= maxDistance)
        .sort((a, b) => b.score - a.score)
        .slice(0, 5);

      // Log AI event
      await prisma.aiEvent.create({
        data: {
          eventType: 'LOAD_RECOMMENDATION',
          prompt: JSON.stringify({ currentLocation, maxDistance, minRate }),
          response: JSON.stringify(recommendations),
          organizationId: req.user!.organizationId!,
          userId: req.user!.id,
        },
      });

      res.json({
        recommendations,
        location: currentLocation,
        totalAvailable: nearbyShipments.length,
      });
    } catch (error) {
      console.error('AI recommendation error:', error);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: 'Failed to generate load recommendations',
      });
    }
  }
);

// AI Route Optimization
router.post(
  '/route-optimization',
  [
    body('stops').isArray({ min: 2 }),
    body('stops.*.latitude').isFloat(),
    body('stops.*.longitude').isFloat(),
    body('stops.*.address').notEmpty(),
  ],
  async (req: AuthRequest, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        details: errors.array(),
      });
    }

    const { stops } = req.body;

    try {
      // Use OpenAI to optimize route
      const prompt = `Optimize the delivery route for the following stops. Return the optimal order as a JSON array of indices.

Stops:
${stops.map((stop: any, i: number) => `${i}: ${stop.address}`).join('\n')}

Consider:
- Minimize total distance
- Avoid backtracking
- Consider traffic patterns

Return only the JSON array of indices in optimal order.`;

      const startTime = Date.now();

      let optimizedOrder: number[];

      if (process.env.AI_PROVIDER === 'openai' && process.env.OPENAI_API_KEY) {
        const completion = await openai.chat.completions.create({
          model: 'gpt-4-turbo-preview',
          messages: [
            {
              role: 'system',
              content: 'You are a route optimization assistant. Return only valid JSON.',
            },
            { role: 'user', content: prompt },
          ],
          temperature: 0.3,
          max_tokens: 200,
        });

        const response = completion.choices[0].message.content || '[]';
        optimizedOrder = JSON.parse(response);
      } else {
        // Fallback: simple nearest neighbor algorithm
        optimizedOrder = nearestNeighbor(stops);
      }

      const processingTime = Date.now() - startTime;

      // Reorder stops
      const optimizedStops = optimizedOrder.map((i) => stops[i]);

      // Calculate total distance
      let totalDistance = 0;
      for (let i = 0; i < optimizedStops.length - 1; i++) {
        totalDistance += calculateDistance(
          optimizedStops[i].latitude,
          optimizedStops[i].longitude,
          optimizedStops[i + 1].latitude,
          optimizedStops[i + 1].longitude
        );
      }

      // Log AI event
      await prisma.aiEvent.create({
        data: {
          eventType: 'ROUTE_OPTIMIZATION',
          prompt: JSON.stringify({ stops }),
          response: JSON.stringify({ optimizedOrder, totalDistance }),
          processingTimeMs: processingTime,
          organizationId: req.user!.organizationId!,
          userId: req.user!.id,
        },
      });

      res.json({
        optimizedStops,
        optimizedOrder,
        totalDistance,
        estimatedTime: Math.round(totalDistance / 55 * 60), // 55 mph average
      });
    } catch (error) {
      console.error('Route optimization error:', error);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: 'Failed to optimize route',
      });
    }
  }
);

// AI Profitability Analysis
router.post(
  '/profitability-analysis',
  [
    body('shipmentId').optional().isUUID(),
    body('period').optional().isIn(['week', 'month', 'quarter', 'year']),
  ],
  async (req: AuthRequest, res) => {
    const { shipmentId, period = 'month' } = req.body;

    try {
      const startDate = getPeriodStart(period);

      // Get shipments in period
      const shipments = await prisma.shipment.findMany({
        where: {
          organizationId: req.user!.organizationId,
          createdAt: { gte: startDate },
          status: 'DELIVERED',
        },
        include: {
          invoice: true,
        },
      });

      // Calculate metrics
      const totalRevenue = shipments.reduce((sum, s) => sum + s.rate, 0);
      const totalMiles = shipments.reduce((sum, s) => sum + (s.distance || 0), 0);
      const totalWeight = shipments.reduce((sum, s) => sum + s.weight, 0);

      // Estimate costs (industry averages)
      const fuelCost = totalMiles * 0.65; // $0.65 per mile
      const driverPay = totalRevenue * 0.35; // 35% of revenue
      const maintenanceCost = totalMiles * 0.15; // $0.15 per mile
      const insuranceCost = totalRevenue * 0.08; // 8% of revenue
      const otherCosts = totalRevenue * 0.03; // 3% other

      const totalCosts = fuelCost + driverPay + maintenanceCost + insuranceCost + otherCosts;
      const netProfit = totalRevenue - totalCosts;
      const profitMargin = (netProfit / totalRevenue) * 100;

      const analysis = {
        period,
        shipments: shipments.length,
        totalRevenue,
        totalMiles,
        totalWeight,
        costs: {
          fuel: Math.round(fuelCost * 100) / 100,
          driverPay: Math.round(driverPay * 100) / 100,
          maintenance: Math.round(maintenanceCost * 100) / 100,
          insurance: Math.round(insuranceCost * 100) / 100,
          other: Math.round(otherCosts * 100) / 100,
          total: Math.round(totalCosts * 100) / 100,
        },
        netProfit: Math.round(netProfit * 100) / 100,
        profitMargin: Math.round(profitMargin * 100) / 100,
        revenuePerMile: Math.round((totalRevenue / totalMiles) * 100) / 100,
        costPerMile: Math.round((totalCosts / totalMiles) * 100) / 100,
      };

      // Log AI event
      await prisma.aiEvent.create({
        data: {
          eventType: 'PROFITABILITY_ANALYSIS',
          prompt: JSON.stringify({ period, shipmentId }),
          response: JSON.stringify(analysis),
          organizationId: req.user!.organizationId!,
          userId: req.user!.id,
        },
      });

      res.json(analysis);
    } catch (error) {
      console.error('Profitability analysis error:', error);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: 'Failed to generate profitability analysis',
      });
    }
  }
);

// Natural Language Command Processing
router.post(
  '/command',
  [body('command').notEmpty().trim()],
  async (req: AuthRequest, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        details: errors.array(),
      });
    }

    const { command } = req.body;

    try {
      const startTime = Date.now();

      let response: any;

      if (process.env.AI_PROVIDER === 'openai' && process.env.OPENAI_API_KEY) {
        const completion = await openai.chat.completions.create({
          model: 'gpt-4-turbo-preview',
          messages: [
            {
              role: 'system',
              content: `You are an AI assistant for a freight management system. 
              Parse user commands and return JSON with:
              - action: the action to take (find_loads, get_status, create_shipment, etc.)
              - parameters: any extracted parameters
              - response: a natural language response
              
              Available actions:
              - find_loads: Find available loads
              - get_status: Get shipment status
              - create_shipment: Create a new shipment
              - get_analytics: Get business analytics
              - help: Provide help information`,
            },
            { role: 'user', content: command },
          ],
          temperature: 0.3,
          max_tokens: 500,
        });

        const aiResponse = completion.choices[0].message.content || '{}';
        response = JSON.parse(aiResponse);
      } else {
        // Fallback: simple keyword matching
        response = parseCommandFallback(command);
      }

      const processingTime = Date.now() - startTime;

      // Log AI event
      await prisma.aiEvent.create({
        data: {
          eventType: 'VOICE_COMMAND',
          prompt: command,
          response: JSON.stringify(response),
          processingTimeMs: processingTime,
          organizationId: req.user!.organizationId!,
          userId: req.user!.id,
        },
      });

      res.json({
        command,
        ...response,
        processingTimeMs: processingTime,
      });
    } catch (error) {
      console.error('Command processing error:', error);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: 'Failed to process command',
      });
    }
  }
);

// Helper functions
function calculateLoadScore(rate: number, distance: number, distanceToPickup: number): number {
  const ratePerMile = rate / distance;
  const proximityScore = Math.max(0, 100 - distanceToPickup);
  const rateScore = Math.min(ratePerMile * 20, 100);
  return Math.round((proximityScore * 0.3 + rateScore * 0.7) * 10) / 10;
}

function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959;
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
      Math.cos(toRadians(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

function toRadians(degrees: number): number {
  return degrees * (Math.PI / 180);
}

function nearestNeighbor(stops: any[]): number[] {
  const n = stops.length;
  const visited = new Array(n).fill(false);
  const order: number[] = [0];
  visited[0] = true;

  for (let i = 0; i < n - 1; i++) {
    const current = order[order.length - 1];
    let nearest = -1;
    let minDist = Infinity;

    for (let j = 0; j < n; j++) {
      if (!visited[j]) {
        const dist = calculateDistance(
          stops[current].latitude,
          stops[current].longitude,
          stops[j].latitude,
          stops[j].longitude
        );
        if (dist < minDist) {
          minDist = dist;
          nearest = j;
        }
      }
    }

    order.push(nearest);
    visited[nearest] = true;
  }

  return order;
}

function getPeriodStart(period: string): Date {
  const now = new Date();
  switch (period) {
    case 'week':
      return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    case 'month':
      return new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    case 'quarter':
      return new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
    case 'year':
      return new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
    default:
      return new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  }
}

function parseCommandFallback(command: string): any {
  const lowerCommand = command.toLowerCase();

  if (lowerCommand.includes('find') || lowerCommand.includes('load')) {
    return {
      action: 'find_loads',
      parameters: {},
      response: 'Finding available loads near you...',
    };
  }

  if (lowerCommand.includes('status')) {
    return {
      action: 'get_status',
      parameters: {},
      response: 'Getting your shipment status...',
    };
  }

  if (lowerCommand.includes('analytics') || lowerCommand.includes('profit')) {
    return {
      action: 'get_analytics',
      parameters: {},
      response: 'Getting your business analytics...',
    };
  }

  return {
    action: 'help',
    parameters: {},
    response: 'I can help you find loads, check shipment status, or view analytics. What would you like to do?',
  };
}

export default router;
