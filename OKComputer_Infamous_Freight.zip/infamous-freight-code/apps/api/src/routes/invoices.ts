import { Router } from 'express';
import { body, param, query } from 'express-validator';
import { PrismaClient, InvoiceStatus, PaymentMethod } from '@prisma/client';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/errorHandler';
import { logger } from '../utils/logger';

const router = Router();
const prisma = new PrismaClient();

// Validation middleware
const createInvoiceValidators = [
  body('shipmentId').isUUID().withMessage('Valid shipment ID is required'),
  body('dueDate').isISO8601().withMessage('Valid due date is required'),
  body('lineItems').isArray({ min: 1 }).withMessage('At least one line item is required'),
  body('lineItems.*.description').trim().notEmpty(),
  body('lineItems.*.amount').isFloat({ min: 0 }),
  validate,
];

const updateInvoiceValidators = [
  param('id').isUUID().withMessage('Valid invoice ID is required'),
  body('status').optional().isIn(Object.values(InvoiceStatus)),
  body('dueDate').optional().isISO8601(),
  validate,
];

const recordPaymentValidators = [
  param('id').isUUID().withMessage('Valid invoice ID is required'),
  body('amount').isFloat({ min: 0.01 }),
  body('method').isIn(Object.values(PaymentMethod)),
  body('date').isISO8601(),
  validate,
];

// Get all invoices with filtering and pagination
router.get(
  '/',
  authenticate,
  [
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 100 }),
    query('status').optional().isIn(Object.values(InvoiceStatus)),
    query('customer').optional().trim(),
    query('startDate').optional().isISO8601(),
    query('endDate').optional().isISO8601(),
    query('overdue').optional().isBoolean(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const skip = (page - 1) * limit;
      const status = req.query.status as InvoiceStatus;
      const customer = req.query.customer as string;
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : null;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : null;
      const overdue = req.query.overdue === 'true';

      const where: any = {
        organizationId: req.user!.organizationId,
      };

      if (status) {
        where.status = status;
      }

      if (customer) {
        where.shipment = {
          customerName: { contains: customer, mode: 'insensitive' },
        };
      }

      if (startDate || endDate) {
        where.invoiceDate = {};
        if (startDate) where.invoiceDate.gte = startDate;
        if (endDate) where.invoiceDate.lte = endDate;
      }

      if (overdue) {
        where.status = { in: ['SENT', 'PARTIAL'] };
        where.dueDate = { lt: new Date() };
      }

      const [invoices, total] = await Promise.all([
        prisma.invoice.findMany({
          where,
          skip,
          take: limit,
          orderBy: { createdAt: 'desc' },
          include: {
            shipment: {
              select: {
                id: true,
                referenceNumber: true,
                customerName: true,
                origin: true,
                destination: true,
              },
            },
            payments: true,
            _count: {
              select: {
                payments: true,
              },
            },
          },
        }),
        prisma.invoice.count({ where }),
      ]);

      // Calculate totals
      const totals = await prisma.invoice.aggregate({
        where: {
          organizationId: req.user!.organizationId,
        },
        _sum: {
          subtotal: true,
          taxAmount: true,
          totalAmount: true,
          amountPaid: true,
          balanceDue: true,
        },
      });

      res.json({
        invoices,
        totals: {
          subtotal: totals._sum.subtotal || 0,
          tax: totals._sum.taxAmount || 0,
          total: totals._sum.totalAmount || 0,
          paid: totals._sum.amountPaid || 0,
          balance: totals._sum.balanceDue || 0,
        },
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get invoice by ID
router.get(
  '/:id',
  authenticate,
  [param('id').isUUID().withMessage('Valid invoice ID is required'), validate],
  async (req, res, next) => {
    try {
      const invoice = await prisma.invoice.findFirst({
        where: {
          id: req.params.id,
          organizationId: req.user!.organizationId,
        },
        include: {
          shipment: {
            include: {
              stops: true,
              driver: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                },
              },
              vehicle: {
                select: {
                  id: true,
                  unitNumber: true,
                },
              },
            },
          },
          payments: {
            orderBy: { date: 'desc' },
          },
          organization: {
            select: {
              name: true,
              address: true,
              city: true,
              state: true,
              zip: true,
              phone: true,
              email: true,
            },
          },
        },
      });

      if (!invoice) {
        return res.status(404).json({ error: 'Invoice not found' });
      }

      res.json(invoice);
    } catch (error) {
      next(error);
    }
  }
);

// Create new invoice
router.post(
  '/',
  authenticate,
  createInvoiceValidators,
  async (req, res, next) => {
    try {
      const { shipmentId, dueDate, lineItems, notes, terms } = req.body;

      // Verify shipment belongs to organization
      const shipment = await prisma.shipment.findFirst({
        where: {
          id: shipmentId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!shipment) {
        return res.status(404).json({ error: 'Shipment not found' });
      }

      // Check if invoice already exists for shipment
      const existingInvoice = await prisma.invoice.findFirst({
        where: { shipmentId },
      });

      if (existingInvoice) {
        return res.status(409).json({
          error: 'Invoice already exists for this shipment',
          invoiceId: existingInvoice.id,
        });
      }

      // Calculate totals
      const subtotal = lineItems.reduce((sum: number, item: any) => sum + item.amount, 0);
      const taxRate = 0; // Configure based on organization settings
      const taxAmount = subtotal * taxRate;
      const totalAmount = subtotal + taxAmount;

      // Generate invoice number
      const invoiceCount = await prisma.invoice.count({
        where: { organizationId: req.user!.organizationId },
      });
      const invoiceNumber = `INV-${Date.now().toString(36).toUpperCase()}-${(invoiceCount + 1).toString().padStart(4, '0')}`;

      const invoice = await prisma.invoice.create({
        data: {
          invoiceNumber,
          shipmentId,
          organizationId: req.user!.organizationId,
          invoiceDate: new Date(),
          dueDate: new Date(dueDate),
          lineItems: JSON.stringify(lineItems),
          subtotal,
          taxRate,
          taxAmount,
          totalAmount,
          amountPaid: 0,
          balanceDue: totalAmount,
          notes,
          terms: terms || 'Net 30',
          status: InvoiceStatus.DRAFT,
        },
      });

      logger.info({ invoiceId: invoice.id }, 'Invoice created successfully');

      res.status(201).json({
        message: 'Invoice created successfully',
        invoice,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Update invoice
router.patch(
  '/:id',
  authenticate,
  updateInvoiceValidators,
  async (req, res, next) => {
    try {
      const invoiceId = req.params.id;

      // Verify invoice belongs to organization
      const existingInvoice = await prisma.invoice.findFirst({
        where: {
          id: invoiceId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!existingInvoice) {
        return res.status(404).json({ error: 'Invoice not found' });
      }

      // Don't allow updates to paid invoices
      if (existingInvoice.status === InvoiceStatus.PAID) {
        return res.status(400).json({ error: 'Cannot update a paid invoice' });
      }

      const updateData: any = {};
      const allowedFields = ['status', 'dueDate', 'notes', 'terms'];

      allowedFields.forEach((field) => {
        if (req.body[field] !== undefined) {
          if (field === 'dueDate') {
            updateData[field] = new Date(req.body[field]);
          } else {
            updateData[field] = req.body[field];
          }
        }
      });

      const invoice = await prisma.invoice.update({
        where: { id: invoiceId },
        data: updateData,
      });

      logger.info({ invoiceId }, 'Invoice updated successfully');

      res.json({
        message: 'Invoice updated successfully',
        invoice,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Delete invoice
router.delete(
  '/:id',
  authenticate,
  [param('id').isUUID().withMessage('Valid invoice ID is required'), validate],
  async (req, res, next) => {
    try {
      const invoiceId = req.params.id;

      // Verify invoice belongs to organization
      const invoice = await prisma.invoice.findFirst({
        where: {
          id: invoiceId,
          organizationId: req.user!.organizationId,
        },
        include: {
          payments: true,
        },
      });

      if (!invoice) {
        return res.status(404).json({ error: 'Invoice not found' });
      }

      // Don't allow deletion of paid invoices
      if (invoice.status === InvoiceStatus.PAID || invoice.payments.length > 0) {
        return res.status(400).json({ error: 'Cannot delete an invoice with payments' });
      }

      await prisma.invoice.delete({
        where: { id: invoiceId },
      });

      logger.info({ invoiceId }, 'Invoice deleted successfully');

      res.json({ message: 'Invoice deleted successfully' });
    } catch (error) {
      next(error);
    }
  }
);

// Send invoice to customer
router.post(
  '/:id/send',
  authenticate,
  [param('id').isUUID().withMessage('Valid invoice ID is required'), validate],
  async (req, res, next) => {
    try {
      const invoiceId = req.params.id;

      // Verify invoice belongs to organization
      const invoice = await prisma.invoice.findFirst({
        where: {
          id: invoiceId,
          organizationId: req.user!.organizationId,
        },
        include: {
          shipment: true,
        },
      });

      if (!invoice) {
        return res.status(404).json({ error: 'Invoice not found' });
      }

      if (invoice.status !== InvoiceStatus.DRAFT) {
        return res.status(400).json({ error: 'Invoice has already been sent' });
      }

      // Update invoice status
      const updatedInvoice = await prisma.invoice.update({
        where: { id: invoiceId },
        data: {
          status: InvoiceStatus.SENT,
          sentAt: new Date(),
        },
      });

      // TODO: Send email notification to customer
      logger.info({ invoiceId, customerEmail: invoice.shipment.customerEmail }, 'Invoice sent to customer');

      res.json({
        message: 'Invoice sent successfully',
        invoice: updatedInvoice,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Record payment
router.post(
  '/:id/payments',
  authenticate,
  recordPaymentValidators,
  async (req, res, next) => {
    try {
      const invoiceId = req.params.id;
      const { amount, method, date, reference, notes } = req.body;

      // Verify invoice belongs to organization
      const invoice = await prisma.invoice.findFirst({
        where: {
          id: invoiceId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!invoice) {
        return res.status(404).json({ error: 'Invoice not found' });
      }

      if (invoice.status === InvoiceStatus.PAID) {
        return res.status(400).json({ error: 'Invoice is already fully paid' });
      }

      if (amount > invoice.balanceDue) {
        return res.status(400).json({
          error: 'Payment amount exceeds balance due',
          balanceDue: invoice.balanceDue,
        });
      }

      // Create payment record
      const payment = await prisma.payment.create({
        data: {
          invoiceId,
          amount,
          method,
          date: new Date(date),
          reference,
          notes,
        },
      });

      // Update invoice
      const newAmountPaid = invoice.amountPaid + amount;
      const newBalanceDue = invoice.totalAmount - newAmountPaid;
      let newStatus = InvoiceStatus.PARTIAL;

      if (newBalanceDue <= 0) {
        newStatus = InvoiceStatus.PAID;
      }

      const updatedInvoice = await prisma.invoice.update({
        where: { id: invoiceId },
        data: {
          amountPaid: newAmountPaid,
          balanceDue: newBalanceDue,
          status: newStatus,
          paidAt: newStatus === InvoiceStatus.PAID ? new Date() : null,
        },
      });

      logger.info({ invoiceId, paymentId: payment.id, amount }, 'Payment recorded');

      res.status(201).json({
        message: 'Payment recorded successfully',
        payment,
        invoice: updatedInvoice,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get invoice aging report
router.get(
  '/reports/aging',
  authenticate,
  async (req, res, next) => {
    try {
      const now = new Date();
      const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      const sixtyDaysAgo = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000);
      const ninetyDaysAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);

      const [current, thirtyDays, sixtyDays, ninetyDays] = await Promise.all([
        // Current (0-30 days)
        prisma.invoice.aggregate({
          where: {
            organizationId: req.user!.organizationId,
            status: { in: ['SENT', 'PARTIAL'] },
            dueDate: { gte: thirtyDaysAgo },
          },
          _sum: { balanceDue: true },
          _count: true,
        }),
        // 31-60 days
        prisma.invoice.aggregate({
          where: {
            organizationId: req.user!.organizationId,
            status: { in: ['SENT', 'PARTIAL'] },
            dueDate: { gte: sixtyDaysAgo, lt: thirtyDaysAgo },
          },
          _sum: { balanceDue: true },
          _count: true,
        }),
        // 61-90 days
        prisma.invoice.aggregate({
          where: {
            organizationId: req.user!.organizationId,
            status: { in: ['SENT', 'PARTIAL'] },
            dueDate: { gte: ninetyDaysAgo, lt: sixtyDaysAgo },
          },
          _sum: { balanceDue: true },
          _count: true,
        }),
        // Over 90 days
        prisma.invoice.aggregate({
          where: {
            organizationId: req.user!.organizationId,
            status: { in: ['SENT', 'PARTIAL'] },
            dueDate: { lt: ninetyDaysAgo },
          },
          _sum: { balanceDue: true },
          _count: true,
        }),
      ]);

      res.json({
        aging: {
          current: {
            count: current._count,
            amount: current._sum.balanceDue || 0,
          },
          thirtyDays: {
            count: thirtyDays._count,
            amount: thirtyDays._sum.balanceDue || 0,
          },
          sixtyDays: {
            count: sixtyDays._count,
            amount: sixtyDays._sum.balanceDue || 0,
          },
          ninetyDays: {
            count: ninetyDays._count,
            amount: ninetyDays._sum.balanceDue || 0,
          },
        },
        totalOutstanding: (current._sum.balanceDue || 0) +
          (thirtyDays._sum.balanceDue || 0) +
          (sixtyDays._sum.balanceDue || 0) +
          (ninetyDays._sum.balanceDue || 0),
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get revenue summary
router.get(
  '/reports/revenue',
  authenticate,
  [
    query('startDate').optional().isISO8601(),
    query('endDate').optional().isISO8601(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const startDate = req.query.startDate
        ? new Date(req.query.startDate as string)
        : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : new Date();

      const invoices = await prisma.invoice.findMany({
        where: {
          organizationId: req.user!.organizationId,
          invoiceDate: {
            gte: startDate,
            lte: endDate,
          },
        },
        include: {
          payments: true,
        },
      });

      const summary = {
        totalInvoiced: 0,
        totalPaid: 0,
        totalOutstanding: 0,
        invoiceCount: invoices.length,
        paidCount: 0,
        partialCount: 0,
        unpaidCount: 0,
      };

      invoices.forEach((invoice) => {
        summary.totalInvoiced += invoice.totalAmount;
        summary.totalPaid += invoice.amountPaid;
        summary.totalOutstanding += invoice.balanceDue;

        if (invoice.status === 'PAID') {
          summary.paidCount++;
        } else if (invoice.status === 'PARTIAL') {
          summary.partialCount++;
        } else {
          summary.unpaidCount++;
        }
      });

      res.json({
        period: {
          startDate,
          endDate,
        },
        summary,
      });
    } catch (error) {
      next(error);
    }
  }
);

export default router;
