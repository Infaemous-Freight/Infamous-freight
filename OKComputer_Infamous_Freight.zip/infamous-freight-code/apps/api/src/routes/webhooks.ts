import { Router } from 'express';
import { body, param } from 'express-validator';
import { PrismaClient, WebhookEvent } from '@prisma/client';
import crypto from 'crypto';
import { authenticate, requireRole } from '../middleware/auth';
import { validate } from '../middleware/errorHandler';
import { logger } from '../utils/logger';

const router = Router();
const prisma = new PrismaClient();

// Validation middleware
const createWebhookValidators = [
  body('url').isURL().withMessage('Valid URL is required'),
  body('events').isArray({ min: 1 }).withMessage('At least one event is required'),
  body('events.*').isIn(Object.values(WebhookEvent)),
  body('secret').optional().trim(),
  body('description').optional().trim(),
  validate,
];

const updateWebhookValidators = [
  param('id').isUUID().withMessage('Valid webhook ID is required'),
  body('url').optional().isURL(),
  body('events').optional().isArray(),
  body('events.*').optional().isIn(Object.values(WebhookEvent)),
  body('active').optional().isBoolean(),
  validate,
];

// Get all webhooks
router.get('/', authenticate, async (req, res, next) => {
  try {
    const webhooks = await prisma.webhook.findMany({
      where: {
        organizationId: req.user!.organizationId,
      },
      orderBy: { createdAt: 'desc' },
      include: {
        _count: {
          select: {
            deliveries: true,
          },
        },
      },
    });

    // Mask secrets
    const sanitizedWebhooks = webhooks.map((webhook) => ({
      ...webhook,
      secret: webhook.secret ? '********' : null,
    }));

    res.json(sanitizedWebhooks);
  } catch (error) {
    next(error);
  }
});

// Get webhook by ID
router.get(
  '/:id',
  authenticate,
  [param('id').isUUID().withMessage('Valid webhook ID is required'), validate],
  async (req, res, next) => {
    try {
      const webhook = await prisma.webhook.findFirst({
        where: {
          id: req.params.id,
          organizationId: req.user!.organizationId,
        },
        include: {
          deliveries: {
            orderBy: { createdAt: 'desc' },
            take: 50,
          },
        },
      });

      if (!webhook) {
        return res.status(404).json({ error: 'Webhook not found' });
      }

      // Mask secret
      webhook.secret = webhook.secret ? '********' : null;

      res.json(webhook);
    } catch (error) {
      next(error);
    }
  }
);

// Create new webhook
router.post(
  '/',
  authenticate,
  requireRole(['ADMIN', 'MANAGER']),
  createWebhookValidators,
  async (req, res, next) => {
    try {
      const { url, events, secret, description } = req.body;

      // Generate secret if not provided
      const webhookSecret = secret || generateWebhookSecret();

      const webhook = await prisma.webhook.create({
        data: {
          url,
          events,
          secret: webhookSecret,
          description,
          organizationId: req.user!.organizationId,
          active: true,
        },
      });

      logger.info({ webhookId: webhook.id }, 'Webhook created successfully');

      res.status(201).json({
        message: 'Webhook created successfully',
        webhook: {
          ...webhook,
          secret: webhookSecret, // Show secret only on creation
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

// Update webhook
router.patch(
  '/:id',
  authenticate,
  requireRole(['ADMIN', 'MANAGER']),
  updateWebhookValidators,
  async (req, res, next) => {
    try {
      const webhookId = req.params.id;

      // Verify webhook belongs to organization
      const existingWebhook = await prisma.webhook.findFirst({
        where: {
          id: webhookId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!existingWebhook) {
        return res.status(404).json({ error: 'Webhook not found' });
      }

      const updateData: any = {};
      const allowedFields = ['url', 'events', 'active', 'description'];

      allowedFields.forEach((field) => {
        if (req.body[field] !== undefined) {
          updateData[field] = req.body[field];
        }
      });

      const webhook = await prisma.webhook.update({
        where: { id: webhookId },
        data: updateData,
      });

      logger.info({ webhookId }, 'Webhook updated successfully');

      res.json({
        message: 'Webhook updated successfully',
        webhook: {
          ...webhook,
          secret: '********',
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

// Delete webhook
router.delete(
  '/:id',
  authenticate,
  requireRole(['ADMIN']),
  [param('id').isUUID().withMessage('Valid webhook ID is required'), validate],
  async (req, res, next) => {
    try {
      const webhookId = req.params.id;

      // Verify webhook belongs to organization
      const webhook = await prisma.webhook.findFirst({
        where: {
          id: webhookId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!webhook) {
        return res.status(404).json({ error: 'Webhook not found' });
      }

      await prisma.webhook.delete({
        where: { id: webhookId },
      });

      logger.info({ webhookId }, 'Webhook deleted successfully');

      res.json({ message: 'Webhook deleted successfully' });
    } catch (error) {
      next(error);
    }
  }
);

// Regenerate webhook secret
router.post(
  '/:id/regenerate-secret',
  authenticate,
  requireRole(['ADMIN']),
  [param('id').isUUID().withMessage('Valid webhook ID is required'), validate],
  async (req, res, next) => {
    try {
      const webhookId = req.params.id;

      // Verify webhook belongs to organization
      const webhook = await prisma.webhook.findFirst({
        where: {
          id: webhookId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!webhook) {
        return res.status(404).json({ error: 'Webhook not found' });
      }

      const newSecret = generateWebhookSecret();

      await prisma.webhook.update({
        where: { id: webhookId },
        data: { secret: newSecret },
      });

      logger.info({ webhookId }, 'Webhook secret regenerated');

      res.json({
        message: 'Webhook secret regenerated successfully',
        secret: newSecret,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Test webhook
router.post(
  '/:id/test',
  authenticate,
  requireRole(['ADMIN', 'MANAGER']),
  [param('id').isUUID().withMessage('Valid webhook ID is required'), validate],
  async (req, res, next) => {
    try {
      const webhookId = req.params.id;

      // Verify webhook belongs to organization
      const webhook = await prisma.webhook.findFirst({
        where: {
          id: webhookId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!webhook) {
        return res.status(404).json({ error: 'Webhook not found' });
      }

      // Send test payload
      const testPayload = {
        event: 'test',
        data: {
          message: 'This is a test webhook event',
          timestamp: new Date().toISOString(),
        },
      };

      const result = await deliverWebhook(webhook, testPayload);

      res.json({
        message: 'Test webhook sent',
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get webhook delivery history
router.get(
  '/:id/deliveries',
  authenticate,
  [
    param('id').isUUID().withMessage('Valid webhook ID is required'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const webhookId = req.params.id;

      // Verify webhook belongs to organization
      const webhook = await prisma.webhook.findFirst({
        where: {
          id: webhookId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!webhook) {
        return res.status(404).json({ error: 'Webhook not found' });
      }

      const deliveries = await prisma.webhookDelivery.findMany({
        where: { webhookId },
        orderBy: { createdAt: 'desc' },
        take: 100,
      });

      res.json(deliveries);
    } catch (error) {
      next(error);
    }
  }
);

// Retry failed delivery
router.post(
  '/deliveries/:id/retry',
  authenticate,
  requireRole(['ADMIN', 'MANAGER']),
  [param('id').isUUID().withMessage('Valid delivery ID is required'), validate],
  async (req, res, next) => {
    try {
      const deliveryId = req.params.id;

      const delivery = await prisma.webhookDelivery.findFirst({
        where: { id: deliveryId },
        include: {
          webhook: true,
        },
      });

      if (!delivery) {
        return res.status(404).json({ error: 'Delivery not found' });
      }

      // Verify webhook belongs to organization
      if (delivery.webhook.organizationId !== req.user!.organizationId) {
        return res.status(403).json({ error: 'Not authorized' });
      }

      const result = await deliverWebhook(delivery.webhook, delivery.payload as any);

      res.json({
        message: 'Delivery retry attempted',
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Helper function to generate webhook secret
function generateWebhookSecret(): string {
  return crypto.randomBytes(32).toString('hex');
}

// Helper function to deliver webhook
async function deliverWebhook(
  webhook: any,
  payload: any
): Promise<{ success: boolean; statusCode?: number; error?: string }> {
  const timestamp = Date.now().toString();
  const signature = generateSignature(webhook.secret, payload, timestamp);

  try {
    const response = await fetch(webhook.url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Webhook-Signature': signature,
        'X-Webhook-Timestamp': timestamp,
        'X-Webhook-Event': payload.event,
        'User-Agent': 'InfamousFreight-Webhook/1.0',
      },
      body: JSON.stringify(payload),
    });

    const success = response.status >= 200 && response.status < 300;

    // Record delivery
    await prisma.webhookDelivery.create({
      data: {
        webhookId: webhook.id,
        event: payload.event,
        payload,
        responseStatus: response.status,
        responseBody: success ? null : await response.text(),
        success,
        attemptedAt: new Date(),
      },
    });

    return {
      success,
      statusCode: response.status,
    };
  } catch (error: any) {
    // Record failed delivery
    await prisma.webhookDelivery.create({
      data: {
        webhookId: webhook.id,
        event: payload.event,
        payload,
        responseStatus: 0,
        responseBody: error.message,
        success: false,
        attemptedAt: new Date(),
      },
    });

    return {
      success: false,
      error: error.message,
    };
  }
}

// Helper function to generate webhook signature
function generateSignature(secret: string, payload: any, timestamp: string): string {
  const data = `${timestamp}.${JSON.stringify(payload)}`;
  return crypto.createHmac('sha256', secret).update(data).digest('hex');
}

// Export function to trigger webhooks (used by other routes)
export async function triggerWebhook(
  organizationId: string,
  event: WebhookEvent,
  data: any
): Promise<void> {
  try {
    const webhooks = await prisma.webhook.findMany({
      where: {
        organizationId,
        active: true,
        events: {
          has: event,
        },
      },
    });

    const payload = {
      event,
      data,
      timestamp: new Date().toISOString(),
    };

    // Deliver to all matching webhooks
    await Promise.all(
      webhooks.map((webhook) => deliverWebhook(webhook, payload))
    );
  } catch (error) {
    logger.error({ error, event }, 'Failed to trigger webhooks');
  }
}

export default router;
