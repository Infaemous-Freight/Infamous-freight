import { Router } from 'express';
import { body, param, query } from 'express-validator';
import { PrismaClient } from '@prisma/client';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/errorHandler';
import { logger } from '../utils/logger';

const router = Router();
const prisma = new PrismaClient();

// Create tracking event (can be called by GPS devices without full auth)
router.post(
  '/events',
  [
    body('shipmentId').isUUID(),
    body('latitude').isFloat({ min: -90, max: 90 }),
    body('longitude').isFloat({ min: -180, max: 180 }),
    body('speed').optional().isFloat({ min: 0 }),
    body('heading').optional().isFloat({ min: 0, max: 360 }),
    body('odometer').optional().isFloat({ min: 0 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const {
        shipmentId,
        latitude,
        longitude,
        speed,
        heading,
        odometer,
        ignitionStatus,
        engineHours,
        batteryVoltage,
      } = req.body;

      // Verify shipment exists
      const shipment = await prisma.shipment.findUnique({
        where: { id: shipmentId },
      });

      if (!shipment) {
        return res.status(404).json({ error: 'Shipment not found' });
      }

      const event = await prisma.trackingEvent.create({
        data: {
          shipmentId,
          latitude,
          longitude,
          speed,
          heading,
          odometer,
          ignitionStatus,
          engineHours,
          batteryVoltage,
          recordedAt: new Date(),
        },
      });

      // Update shipment's current location
      await prisma.shipment.update({
        where: { id: shipmentId },
        data: {
          currentLatitude: latitude,
          currentLongitude: longitude,
        },
      });

      res.status(201).json({
        message: 'Tracking event recorded',
        event,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get tracking history for a shipment
router.get(
  '/shipments/:id',
  authenticate,
  [
    param('id').isUUID().withMessage('Valid shipment ID is required'),
    query('startTime').optional().isISO8601(),
    query('endTime').optional().isISO8601(),
    query('limit').optional().isInt({ min: 1, max: 1000 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const shipmentId = req.params.id;
      const startTime = req.query.startTime
        ? new Date(req.query.startTime as string)
        : new Date(Date.now() - 24 * 60 * 60 * 1000);
      const endTime = req.query.endTime ? new Date(req.query.endTime as string) : new Date();
      const limit = parseInt(req.query.limit as string) || 100;

      // Verify shipment belongs to organization
      const shipment = await prisma.shipment.findFirst({
        where: {
          id: shipmentId,
          organizationId: req.user!.organizationId,
        },
        include: {
          driver: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              phone: true,
            },
          },
          vehicle: {
            select: {
              id: true,
              unitNumber: true,
              gpsDeviceId: true,
            },
          },
          stops: true,
        },
      });

      if (!shipment) {
        return res.status(404).json({ error: 'Shipment not found' });
      }

      const trackingEvents = await prisma.trackingEvent.findMany({
        where: {
          shipmentId,
          recordedAt: {
            gte: startTime,
            lte: endTime,
          },
        },
        orderBy: { recordedAt: 'desc' },
        take: limit,
      });

      // Calculate current status
      const currentLocation = trackingEvents[0] || null;
      const nextStop = shipment.stops.find((s) => !s.actualArrival && !s.actualDeparture);

      res.json({
        shipment: {
          id: shipment.id,
          referenceNumber: shipment.referenceNumber,
          status: shipment.status,
          driver: shipment.driver,
          vehicle: shipment.vehicle,
        },
        currentLocation: currentLocation
          ? {
              latitude: currentLocation.latitude,
              longitude: currentLocation.longitude,
              speed: currentLocation.speed,
              heading: currentLocation.heading,
              recordedAt: currentLocation.recordedAt,
            }
          : null,
        nextStop: nextStop
          ? {
              sequence: nextStop.sequence,
              type: nextStop.type,
              name: nextStop.name,
              address: nextStop.address,
              city: nextStop.city,
              state: nextStop.state,
              zip: nextStop.zip,
              scheduledArrival: nextStop.scheduledArrival,
            }
          : null,
        trackingEvents,
        route: trackingEvents
          .slice()
          .reverse()
          .map((e) => ({
            lat: e.latitude,
            lng: e.longitude,
            timestamp: e.recordedAt,
            speed: e.speed,
          })),
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get current location for all active shipments
router.get(
  '/active',
  authenticate,
  async (req, res, next) => {
    try {
      const activeShipments = await prisma.shipment.findMany({
        where: {
          organizationId: req.user!.organizationId,
          status: { in: ['IN_TRANSIT', 'PICKED_UP', 'AT_PICKUP'] },
        },
        include: {
          driver: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              phone: true,
            },
          },
          vehicle: {
            select: {
              id: true,
              unitNumber: true,
            },
          },
          stops: {
            orderBy: { sequence: 'asc' },
          },
        },
      });

      const locations = await Promise.all(
        activeShipments.map(async (shipment) => {
          const latestEvent = await prisma.trackingEvent.findFirst({
            where: { shipmentId: shipment.id },
            orderBy: { recordedAt: 'desc' },
          });

          const nextStop = shipment.stops.find((s) => !s.actualArrival);

          return {
            shipment: {
              id: shipment.id,
              referenceNumber: shipment.referenceNumber,
              status: shipment.status,
              customerName: shipment.customerName,
            },
            driver: shipment.driver,
            vehicle: shipment.vehicle,
            location: latestEvent
              ? {
                  latitude: latestEvent.latitude,
                  longitude: latestEvent.longitude,
                  speed: latestEvent.speed,
                  heading: latestEvent.heading,
                  lastUpdated: latestEvent.recordedAt,
                }
              : shipment.currentLatitude && shipment.currentLongitude
                ? {
                    latitude: shipment.currentLatitude,
                    longitude: shipment.currentLongitude,
                    lastUpdated: shipment.updatedAt,
                  }
                : null,
            nextStop: nextStop
              ? {
                  sequence: nextStop.sequence,
                  type: nextStop.type,
                  city: nextStop.city,
                  state: nextStop.state,
                  scheduledArrival: nextStop.scheduledArrival,
                }
              : null,
          };
        })
      );

      res.json({
        count: locations.length,
        locations,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Record manual check-in (for drivers without GPS)
router.post(
  '/checkin',
  authenticate,
  [
    body('shipmentId').isUUID(),
    body('latitude').isFloat({ min: -90, max: 90 }),
    body('longitude').isFloat({ min: -180, max: 180 }),
    body('locationName').optional().trim(),
    body('notes').optional().trim(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { shipmentId, latitude, longitude, locationName, notes } = req.body;

      // Verify shipment belongs to organization and is assigned to current user (if driver)
      const shipment = await prisma.shipment.findFirst({
        where: {
          id: shipmentId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!shipment) {
        return res.status(404).json({ error: 'Shipment not found' });
      }

      // If user is a driver, verify they're assigned to this shipment
      if (req.user!.role === 'DRIVER') {
        const driver = await prisma.driver.findFirst({
          where: { userId: req.user!.userId },
        });

        if (!driver || shipment.driverId !== driver.id) {
          return res.status(403).json({ error: 'Not authorized to check in for this shipment' });
        }
      }

      const event = await prisma.trackingEvent.create({
        data: {
          shipmentId,
          latitude,
          longitude,
          locationName,
          notes,
          recordedAt: new Date(),
          source: 'MANUAL',
        },
      });

      // Update shipment location
      await prisma.shipment.update({
        where: { id: shipmentId },
        data: {
          currentLatitude: latitude,
          currentLongitude: longitude,
        },
      });

      res.status(201).json({
        message: 'Check-in recorded successfully',
        event,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get ETA for shipment
router.get(
  '/shipments/:id/eta',
  authenticate,
  [param('id').isUUID().withMessage('Valid shipment ID is required'), validate],
  async (req, res, next) => {
    try {
      const shipmentId = req.params.id;

      // Verify shipment belongs to organization
      const shipment = await prisma.shipment.findFirst({
        where: {
          id: shipmentId,
          organizationId: req.user!.organizationId,
        },
        include: {
          stops: {
            orderBy: { sequence: 'asc' },
          },
        },
      });

      if (!shipment) {
        return res.status(404).json({ error: 'Shipment not found' });
      }

      const latestEvent = await prisma.trackingEvent.findFirst({
        where: { shipmentId },
        orderBy: { recordedAt: 'desc' },
      });

      const nextStop = shipment.stops.find((s) => !s.actualArrival);
      const finalDestination = shipment.stops[shipment.stops.length - 1];

      // Simple ETA calculation based on distance and average speed
      // In production, this would use a routing service like Google Maps or Mapbox
      let etaToNextStop = null;
      let etaToDestination = null;

      if (latestEvent && nextStop) {
        const distanceToNext = calculateDistance(
          latestEvent.latitude,
          latestEvent.longitude,
          nextStop.latitude,
          nextStop.longitude
        );
        const avgSpeed = latestEvent.speed || 55; // Default to 55 mph
        etaToNextStop = new Date(Date.now() + (distanceToNext / avgSpeed) * 60 * 60 * 1000);
      }

      if (latestEvent && finalDestination) {
        const distanceToFinal = calculateDistance(
          latestEvent.latitude,
          latestEvent.longitude,
          finalDestination.latitude,
          finalDestination.longitude
        );
        const avgSpeed = latestEvent.speed || 55;
        etaToDestination = new Date(Date.now() + (distanceToFinal / avgSpeed) * 60 * 60 * 1000);
      }

      res.json({
        shipmentId,
        currentLocation: latestEvent
          ? {
              latitude: latestEvent.latitude,
              longitude: latestEvent.longitude,
              lastUpdated: latestEvent.recordedAt,
            }
          : null,
        nextStop: nextStop
          ? {
              name: nextStop.name,
              city: nextStop.city,
              state: nextStop.state,
              scheduledArrival: nextStop.scheduledArrival,
              estimatedArrival: etaToNextStop,
            }
          : null,
        finalDestination: finalDestination
          ? {
              name: finalDestination.name,
              city: finalDestination.city,
              state: finalDestination.state,
              scheduledArrival: finalDestination.scheduledArrival,
              estimatedArrival: etaToDestination,
            }
          : null,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Geofence alerts
router.get(
  '/alerts',
  authenticate,
  [
    query('startDate').optional().isISO8601(),
    query('endDate').optional().isISO8601(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const startDate = req.query.startDate
        ? new Date(req.query.startDate as string)
        : new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : new Date();

      // This would integrate with a geofencing service
      // For now, return simulated alerts based on tracking events
      const alerts = await prisma.trackingEvent.findMany({
        where: {
          shipment: {
            organizationId: req.user!.organizationId,
          },
          recordedAt: {
            gte: startDate,
            lte: endDate,
          },
          speed: {
            gt: 80, // Speeding alert
          },
        },
        include: {
          shipment: {
            select: {
              id: true,
              referenceNumber: true,
              driver: {
                select: {
                  firstName: true,
                  lastName: true,
                },
              },
            },
          },
        },
        orderBy: { recordedAt: 'desc' },
        take: 50,
      });

      const formattedAlerts = alerts.map((event) => ({
        id: event.id,
        type: 'SPEEDING',
        severity: event.speed && event.speed > 85 ? 'HIGH' : 'MEDIUM',
        message: `Vehicle exceeded speed limit at ${event.speed?.toFixed(1)} mph`,
        location: {
          latitude: event.latitude,
          longitude: event.longitude,
        },
        timestamp: event.recordedAt,
        shipment: event.shipment,
      }));

      res.json({
        alerts: formattedAlerts,
        count: formattedAlerts.length,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Helper function to calculate distance between two points using Haversine formula
function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 3959; // Earth's radius in miles
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
      Math.cos(toRadians(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRadians(degrees: number): number {
  return degrees * (Math.PI / 180);
}

export default router;
