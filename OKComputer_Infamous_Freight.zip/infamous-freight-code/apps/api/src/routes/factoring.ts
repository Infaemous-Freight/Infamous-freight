import { Router } from 'express';
import { body } from 'express-validator';
import { authenticate } from '../middleware/auth';
import { FactoringService } from '../services/factoring';
import { logger } from '../utils/logger';

const router = Router();

// Get quote for invoice factoring
router.get('/quote/:invoiceId', authenticate, async (req, res, next) => {
  try {
    const { invoiceId } = req.params;
    const organizationId = (req as any).user.organizationId;

    const quote = await FactoringService.getQuote(invoiceId);
    
    logger.info({ invoiceId, organizationId }, 'Factoring quote requested');
    
    res.json({ quote });
  } catch (error) {
    next(error);
  }
});

// Apply for factoring
router.post(
  '/apply',
  authenticate,
  [
    body('invoiceId').isString().notEmpty(),
    body('advanceRate').isFloat({ min: 0.5, max: 0.95 }),
    body('feeRate').isFloat({ min: 0.01, max: 0.1 }),
  ],
  async (req, res, next) => {
    try {
      const { invoiceId, advanceRate, feeRate } = req.body;
      const organizationId = (req as any).user.organizationId;

      const result = await FactoringService.apply({
        invoiceId,
        organizationId,
        advanceRate,
        feeRate,
      });

      logger.info(
        { factoringId: result.factoring.id, invoiceId, organizationId },
        'Factoring application submitted'
      );

      res.status(201).json(result);
    } catch (error) {
      next(error);
    }
  }
);

// Get factoring status
router.get('/status/:invoiceId', authenticate, async (req, res, next) => {
  try {
    const { invoiceId } = req.params;
    
    const status = await FactoringService.getStatus(invoiceId);
    
    if (!status) {
      return res.status(404).json({ error: 'No factoring application found' });
    }

    res.json({ status });
  } catch (error) {
    next(error);
  }
});

// Get dashboard data
router.get('/dashboard', authenticate, async (req, res, next) => {
  try {
    const organizationId = (req as any).user.organizationId;
    
    const dashboard = await FactoringService.getDashboard(organizationId);
    
    res.json(dashboard);
  } catch (error) {
    next(error);
  }
});

// Get all factoring applications
router.get('/', authenticate, async (req, res, next) => {
  try {
    const organizationId = (req as any).user.organizationId;
    const { status, page = '1', limit = '10' } = req.query;

    const where: any = { organizationId };
    if (status) {
      where.status = status;
    }

    const [factorings, total] = await Promise.all([
      (req as any).prisma.factoring.findMany({
        where,
        include: {
          invoice: {
            select: {
              invoiceNumber: true,
              totalAmount: true,
              customerName: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip: (parseInt(page as string) - 1) * parseInt(limit as string),
        take: parseInt(limit as string),
      }),
      (req as any).prisma.factoring.count({ where }),
    ]);

    res.json({
      factorings,
      pagination: {
        page: parseInt(page as string),
        limit: parseInt(limit as string),
        total,
        totalPages: Math.ceil(total / parseInt(limit as string)),
      },
    });
  } catch (error) {
    next(error);
  }
});

export default router;
