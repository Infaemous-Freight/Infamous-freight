import { Router } from 'express';
import { body, param, query } from 'express-validator';
import { PrismaClient, DriverStatus } from '@prisma/client';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/errorHandler';
import { logger } from '../utils/logger';

const router = Router();
const prisma = new PrismaClient();

// Validation middleware
const createDriverValidators = [
  body('firstName').trim().notEmpty().withMessage('First name is required'),
  body('lastName').trim().notEmpty().withMessage('Last name is required'),
  body('email').isEmail().normalizeEmail().withMessage('Valid email is required'),
  body('phone').optional().trim(),
  body('cdlNumber').trim().notEmpty().withMessage('CDL number is required'),
  body('cdlState').trim().isLength({ min: 2, max: 2 }).withMessage('CDL state must be 2 characters'),
  body('cdlExpiration').isISO8601().withMessage('Valid CDL expiration date is required'),
  body('medicalExpiration').optional().isISO8601(),
  body('hireDate').optional().isISO8601(),
  validate,
];

const updateDriverValidators = [
  param('id').isUUID().withMessage('Valid driver ID is required'),
  body('firstName').optional().trim().notEmpty(),
  body('lastName').optional().trim().notEmpty(),
  body('phone').optional().trim(),
  body('cdlExpiration').optional().isISO8601(),
  body('medicalExpiration').optional().isISO8601(),
  body('status').optional().isIn(Object.values(DriverStatus)),
  validate,
];

// Get all drivers with filtering and pagination
router.get(
  '/',
  authenticate,
  [
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 100 }),
    query('status').optional().isIn(Object.values(DriverStatus)),
    query('search').optional().trim(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const skip = (page - 1) * limit;
      const status = req.query.status as DriverStatus;
      const search = req.query.search as string;

      const where: any = {
        organizationId: req.user!.organizationId,
      };

      if (status) {
        where.status = status;
      }

      if (search) {
        where.OR = [
          { firstName: { contains: search, mode: 'insensitive' } },
          { lastName: { contains: search, mode: 'insensitive' } },
          { email: { contains: search, mode: 'insensitive' } },
          { cdlNumber: { contains: search, mode: 'insensitive' } },
        ];
      }

      const [drivers, total] = await Promise.all([
        prisma.driver.findMany({
          where,
          skip,
          take: limit,
          orderBy: { createdAt: 'desc' },
          include: {
            user: {
              select: {
                id: true,
                email: true,
                status: true,
                lastLoginAt: true,
              },
            },
            _count: {
              select: {
                shipments: true,
                hosLogs: true,
              },
            },
          },
        }),
        prisma.driver.count({ where }),
      ]);

      res.json({
        drivers,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get driver by ID
router.get(
  '/:id',
  authenticate,
  [param('id').isUUID().withMessage('Valid driver ID is required'), validate],
  async (req, res, next) => {
    try {
      const driver = await prisma.driver.findFirst({
        where: {
          id: req.params.id,
          organizationId: req.user!.organizationId,
        },
        include: {
          user: {
            select: {
              id: true,
              email: true,
              status: true,
              lastLoginAt: true,
              createdAt: true,
            },
          },
          shipments: {
            where: {
              status: { in: ['IN_TRANSIT', 'PICKED_UP', 'AT_PICKUP'] },
            },
            include: {
              stops: true,
            },
          },
          hosLogs: {
            orderBy: { createdAt: 'desc' },
            take: 7,
          },
          vehicles: {
            include: {
              vehicle: true,
            },
          },
        },
      });

      if (!driver) {
        return res.status(404).json({ error: 'Driver not found' });
      }

      // Calculate HOS summary
      const hosSummary = await calculateHosSummary(driver.id);

      res.json({
        ...driver,
        hosSummary,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Create new driver
router.post(
  '/',
  authenticate,
  createDriverValidators,
  async (req, res, next) => {
    try {
      const {
        firstName,
        lastName,
        email,
        phone,
        cdlNumber,
        cdlState,
        cdlExpiration,
        cdlClass,
        medicalExpiration,
        hireDate,
        emergencyContactName,
        emergencyContactPhone,
        address,
        dateOfBirth,
      } = req.body;

      // Check if driver with email already exists
      const existingDriver = await prisma.driver.findUnique({
        where: { email },
      });

      if (existingDriver) {
        return res.status(409).json({ error: 'Driver with this email already exists' });
      }

      // Check if CDL number already exists
      const existingCdl = await prisma.driver.findUnique({
        where: { cdlNumber },
      });

      if (existingCdl) {
        return res.status(409).json({ error: 'Driver with this CDL number already exists' });
      }

      const driver = await prisma.driver.create({
        data: {
          firstName,
          lastName,
          email,
          phone,
          cdlNumber,
          cdlState: cdlState.toUpperCase(),
          cdlExpiration: new Date(cdlExpiration),
          cdlClass,
          medicalExpiration: medicalExpiration ? new Date(medicalExpiration) : null,
          hireDate: hireDate ? new Date(hireDate) : null,
          emergencyContactName,
          emergencyContactPhone,
          address,
          dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : null,
          organizationId: req.user!.organizationId,
          status: DriverStatus.AVAILABLE,
        },
      });

      logger.info({ driverId: driver.id }, 'Driver created successfully');

      res.status(201).json({
        message: 'Driver created successfully',
        driver,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Update driver
router.patch(
  '/:id',
  authenticate,
  updateDriverValidators,
  async (req, res, next) => {
    try {
      const driverId = req.params.id;

      // Verify driver belongs to organization
      const existingDriver = await prisma.driver.findFirst({
        where: {
          id: driverId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!existingDriver) {
        return res.status(404).json({ error: 'Driver not found' });
      }

      const updateData: any = {};
      const allowedFields = [
        'firstName',
        'lastName',
        'phone',
        'cdlExpiration',
        'medicalExpiration',
        'status',
        'emergencyContactName',
        'emergencyContactPhone',
        'address',
      ];

      allowedFields.forEach((field) => {
        if (req.body[field] !== undefined) {
          updateData[field] = req.body[field];
        }
      });

      const driver = await prisma.driver.update({
        where: { id: driverId },
        data: updateData,
      });

      logger.info({ driverId }, 'Driver updated successfully');

      res.json({
        message: 'Driver updated successfully',
        driver,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Delete driver
router.delete(
  '/:id',
  authenticate,
  [param('id').isUUID().withMessage('Valid driver ID is required'), validate],
  async (req, res, next) => {
    try {
      const driverId = req.params.id;

      // Verify driver belongs to organization and has no active shipments
      const driver = await prisma.driver.findFirst({
        where: {
          id: driverId,
          organizationId: req.user!.organizationId,
        },
        include: {
          shipments: {
            where: {
              status: { in: ['IN_TRANSIT', 'PICKED_UP', 'AT_PICKUP'] },
            },
          },
        },
      });

      if (!driver) {
        return res.status(404).json({ error: 'Driver not found' });
      }

      if (driver.shipments.length > 0) {
        return res.status(400).json({
          error: 'Cannot delete driver with active shipments',
          activeShipments: driver.shipments.length,
        });
      }

      await prisma.driver.delete({
        where: { id: driverId },
      });

      logger.info({ driverId }, 'Driver deleted successfully');

      res.json({ message: 'Driver deleted successfully' });
    } catch (error) {
      next(error);
    }
  }
);

// Get driver's HOS logs
router.get(
  '/:id/hos',
  authenticate,
  [
    param('id').isUUID().withMessage('Valid driver ID is required'),
    query('startDate').optional().isISO8601(),
    query('endDate').optional().isISO8601(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const driverId = req.params.id;
      const startDate = req.query.startDate
        ? new Date(req.query.startDate as string)
        : new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : new Date();

      // Verify driver belongs to organization
      const driver = await prisma.driver.findFirst({
        where: {
          id: driverId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!driver) {
        return res.status(404).json({ error: 'Driver not found' });
      }

      const hosLogs = await prisma.hosLog.findMany({
        where: {
          driverId,
          date: {
            gte: startDate,
            lte: endDate,
          },
        },
        orderBy: { date: 'desc' },
      });

      const summary = await calculateHosSummary(driverId);

      res.json({
        hosLogs,
        summary,
        period: {
          startDate,
          endDate,
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

// Create HOS log entry
router.post(
  '/:id/hos',
  authenticate,
  [
    param('id').isUUID().withMessage('Valid driver ID is required'),
    body('date').isISO8601().withMessage('Valid date is required'),
    body('dutyStatus').isIn(['OFF_DUTY', 'SB', 'D', 'ON_DUTY']),
    body('hours').isFloat({ min: 0, max: 24 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const driverId = req.params.id;
      const { date, dutyStatus, hours, startTime, endTime, location, remarks } = req.body;

      // Verify driver belongs to organization
      const driver = await prisma.driver.findFirst({
        where: {
          id: driverId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!driver) {
        return res.status(404).json({ error: 'Driver not found' });
      }

      const hosLog = await prisma.hosLog.create({
        data: {
          driverId,
          date: new Date(date),
          dutyStatus,
          hours,
          startTime: startTime ? new Date(startTime) : null,
          endTime: endTime ? new Date(endTime) : null,
          location,
          remarks,
        },
      });

      res.status(201).json({
        message: 'HOS log created successfully',
        hosLog,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get driver performance metrics
router.get(
  '/:id/performance',
  authenticate,
  [param('id').isUUID().withMessage('Valid driver ID is required'), validate],
  async (req, res, next) => {
    try {
      const driverId = req.params.id;

      // Verify driver belongs to organization
      const driver = await prisma.driver.findFirst({
        where: {
          id: driverId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!driver) {
        return res.status(404).json({ error: 'Driver not found' });
      }

      // Get completed shipments
      const shipments = await prisma.shipment.findMany({
        where: {
          driverId,
          status: 'DELIVERED',
          actualDeliveryDate: {
            gte: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000),
          },
        },
        include: {
          stops: true,
        },
      });

      // Calculate metrics
      const totalShipments = shipments.length;
      const onTimeDeliveries = shipments.filter(
        (s) => s.actualDeliveryDate && s.scheduledDeliveryDate &&
          new Date(s.actualDeliveryDate) <= new Date(s.scheduledDeliveryDate)
      ).length;
      const onTimePercentage = totalShipments > 0 ? (onTimeDeliveries / totalShipments) * 100 : 0;

      const totalMiles = shipments.reduce((sum, s) => sum + (s.totalMiles || 0), 0);
      const totalRevenue = shipments.reduce((sum, s) => sum + (s.rate || 0), 0);

      // Get HOS compliance
      const hosLogs = await prisma.hosLog.findMany({
        where: {
          driverId,
          date: {
            gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
          },
        },
      });

      const totalDrivingHours = hosLogs
        .filter((log) => log.dutyStatus === 'D')
        .reduce((sum, log) => sum + log.hours, 0);

      res.json({
        period: 'last_90_days',
        shipments: {
          total: totalShipments,
          onTime: onTimeDeliveries,
          onTimePercentage: Math.round(onTimePercentage * 100) / 100,
        },
        mileage: {
          total: totalMiles,
        },
        revenue: {
          total: totalRevenue,
        },
        hos: {
          totalDrivingHours: Math.round(totalDrivingHours * 100) / 100,
          averageDailyHours: Math.round((totalDrivingHours / 30) * 100) / 100,
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

// Helper function to calculate HOS summary
async function calculateHosSummary(driverId: string) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const sevenDaysAgo = new Date(today);
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

  const hosLogs = await prisma.hosLog.findMany({
    where: {
      driverId,
      date: {
        gte: sevenDaysAgo,
      },
    },
  });

  const todayLogs = hosLogs.filter((log) => {
    const logDate = new Date(log.date);
    logDate.setHours(0, 0, 0, 0);
    return logDate.getTime() === today.getTime();
  });

  const drivingHoursToday = todayLogs
    .filter((log) => log.dutyStatus === 'D')
    .reduce((sum, log) => sum + log.hours, 0);

  const onDutyHoursToday = todayLogs
    .filter((log) => log.dutyStatus === 'ON_DUTY' || log.dutyStatus === 'D')
    .reduce((sum, log) => sum + log.hours, 0);

  const drivingHours7Days = hosLogs
    .filter((log) => log.dutyStatus === 'D')
    .reduce((sum, log) => sum + log.hours, 0);

  return {
    drivingHoursToday: Math.round(drivingHoursToday * 100) / 100,
    onDutyHoursToday: Math.round(onDutyHoursToday * 100) / 100,
    drivingHours7Days: Math.round(drivingHours7Days * 100) / 100,
    drivingHoursRemaining: Math.round((11 - drivingHoursToday) * 100) / 100,
    onDutyHoursRemaining: Math.round((14 - onDutyHoursToday) * 100) / 100,
    cycleHoursRemaining: Math.round((60 - drivingHours7Days) * 100) / 100,
  };
}

export default router;
