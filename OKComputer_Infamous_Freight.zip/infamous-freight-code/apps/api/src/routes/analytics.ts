import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { query, validationResult } from 'express-validator';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();
const prisma = new PrismaClient();

router.use(authenticate);

// Get dashboard analytics
router.get(
  '/dashboard',
  [
    query('period').optional().isIn(['week', 'month', 'quarter', 'year']),
  ],
  async (req: AuthRequest, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        details: errors.array(),
      });
    }

    const period = (req.query.period as string) || 'month';
    const startDate = getPeriodStart(period);

    try {
      // Get counts
      const [
        activeShipments,
        deliveredShipments,
        totalShipments,
        availableDrivers,
        activeVehicles,
        pendingInvoices,
        paidInvoices,
      ] = await Promise.all([
        prisma.shipment.count({
          where: {
            organizationId: req.user!.organizationId,
            status: { in: ['ASSIGNED', 'IN_TRANSIT'] },
          },
        }),
        prisma.shipment.count({
          where: {
            organizationId: req.user!.organizationId,
            status: 'DELIVERED',
            createdAt: { gte: startDate },
          },
        }),
        prisma.shipment.count({
          where: {
            organizationId: req.user!.organizationId,
            createdAt: { gte: startDate },
          },
        }),
        prisma.driver.count({
          where: {
            organizationId: req.user!.organizationId,
            status: { in: ['AVAILABLE', 'ON_DUTY'] },
          },
        }),
        prisma.vehicle.count({
          where: {
            organizationId: req.user!.organizationId,
            status: 'ACTIVE',
          },
        }),
        prisma.invoice.count({
          where: {
            organizationId: req.user!.organizationId,
            status: { in: ['DRAFT', 'SENT'] },
          },
        }),
        prisma.invoice.count({
          where: {
            organizationId: req.user!.organizationId,
            status: 'PAID',
            paidAt: { gte: startDate },
          },
        }),
      ]);

      // Get revenue
      const revenueData = await prisma.invoice.aggregate({
        where: {
          organizationId: req.user!.organizationId,
          status: 'PAID',
          paidAt: { gte: startDate },
        },
        _sum: {
          amount: true,
        },
      });

      // Get total miles
      const mileageData = await prisma.shipment.aggregate({
        where: {
          organizationId: req.user!.organizationId,
          status: 'DELIVERED',
          createdAt: { gte: startDate },
        },
        _sum: {
          distance: true,
        },
      });

      // Get average driver rating
      const ratingData = await prisma.driver.aggregate({
        where: {
          organizationId: req.user!.organizationId,
        },
        _avg: {
          rating: true,
        },
      });

      res.json({
        period,
        counts: {
          activeShipments,
          deliveredShipments,
          totalShipments,
          availableDrivers,
          activeVehicles,
          pendingInvoices,
          paidInvoices,
        },
        revenue: {
          total: revenueData._sum.amount || 0,
          currency: 'USD',
        },
        mileage: {
          total: mileageData._sum.distance || 0,
          unit: 'miles',
        },
        performance: {
          averageDriverRating: Math.round((ratingData._avg.rating || 0) * 10) / 10,
        },
      });
    } catch (error) {
      console.error('Dashboard analytics error:', error);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: 'Failed to fetch dashboard analytics',
      });
    }
  }
);

// Get revenue analytics
router.get(
  '/revenue',
  [
    query('period').optional().isIn(['week', 'month', 'quarter', 'year']),
  ],
  async (req: AuthRequest, res) => {
    const period = (req.query.period as string) || 'month';
    const startDate = getPeriodStart(period);

    try {
      // Get daily revenue for the period
      const invoices = await prisma.invoice.findMany({
        where: {
          organizationId: req.user!.organizationId,
          status: 'PAID',
          paidAt: { gte: startDate },
        },
        select: {
          amount: true,
          paidAt: true,
        },
        orderBy: {
          paidAt: 'asc',
        },
      });

      // Group by day/week/month depending on period
      const groupedData = groupByPeriod(invoices, period);

      // Get revenue by shipment status
      const revenueByStatus = await prisma.shipment.groupBy({
        by: ['status'],
        where: {
          organizationId: req.user!.organizationId,
          createdAt: { gte: startDate },
        },
        _sum: {
          rate: true,
        },
      });

      res.json({
        period,
        timeline: groupedData,
        byStatus: revenueByStatus.map((item) => ({
          status: item.status,
          revenue: item._sum.rate || 0,
        })),
        total: invoices.reduce((sum, inv) => sum + inv.amount, 0),
      });
    } catch (error) {
      console.error('Revenue analytics error:', error);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: 'Failed to fetch revenue analytics',
      });
    }
  }
);

// Get driver performance analytics
router.get('/drivers/performance', async (req: AuthRequest, res) => {
  try {
    const drivers = await prisma.driver.findMany({
      where: {
        organizationId: req.user!.organizationId,
      },
      include: {
        user: {
          select: {
            name: true,
            email: true,
          },
        },
        shipments: {
          where: {
            status: 'DELIVERED',
          },
          select: {
            rate: true,
            distance: true,
            deliveryDate: true,
            estimatedDeliveryDate: true,
          },
        },
      },
    });

    const driverPerformance = drivers.map((driver) => {
      const totalRevenue = driver.shipments.reduce((sum, s) => sum + s.rate, 0);
      const totalMiles = driver.shipments.reduce((sum, s) => sum + (s.distance || 0), 0);
      const onTimeDeliveries = driver.shipments.filter(
        (s) => s.deliveryDate && s.estimatedDeliveryDate && s.deliveryDate <= s.estimatedDeliveryDate
      ).length;
      const onTimeRate = driver.shipments.length > 0 ? (onTimeDeliveries / driver.shipments.length) * 100 : 0;

      return {
        id: driver.id,
        name: driver.user?.name || 'Unknown',
        rating: driver.rating,
        totalMiles: driver.totalMiles,
        shipmentsDelivered: driver.shipments.length,
        totalRevenue,
        revenuePerMile: totalMiles > 0 ? Math.round((totalRevenue / totalMiles) * 100) / 100 : 0,
        onTimeRate: Math.round(onTimeRate * 10) / 10,
      };
    });

    // Sort by revenue
    driverPerformance.sort((a, b) => b.totalRevenue - a.totalRevenue);

    res.json({
      drivers: driverPerformance,
      summary: {
        totalDrivers: drivers.length,
        averageRating: Math.round((drivers.reduce((sum, d) => sum + d.rating, 0) / drivers.length) * 10) / 10,
        totalRevenue: driverPerformance.reduce((sum, d) => sum + d.totalRevenue, 0),
      },
    });
  } catch (error) {
    console.error('Driver performance error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Failed to fetch driver performance',
    });
  }
});

// Helper functions
function getPeriodStart(period: string): Date {
  const now = new Date();
  switch (period) {
    case 'week':
      return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    case 'month':
      return new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    case 'quarter':
      return new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
    case 'year':
      return new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
    default:
      return new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  }
}

function groupByPeriod(
  invoices: Array<{ amount: number; paidAt: Date | null }>,
  period: string
): Array<{ period: string; revenue: number }> {
  const grouped = new Map<string, number>();

  invoices.forEach((invoice) => {
    if (!invoice.paidAt) return;

    let key: string;
    const date = new Date(invoice.paidAt);

    switch (period) {
      case 'week':
        key = date.toISOString().split('T')[0]; // Daily
        break;
      case 'month':
        key = `Week ${Math.ceil(date.getDate() / 7)}`; // Weekly
        break;
      case 'quarter':
        key = `Month ${date.getMonth() + 1}`; // Monthly
        break;
      case 'year':
        key = `Month ${date.getMonth() + 1}`; // Monthly
        break;
      default:
        key = date.toISOString().split('T')[0];
    }

    grouped.set(key, (grouped.get(key) || 0) + invoice.amount);
  });

  return Array.from(grouped.entries()).map(([period, revenue]) => ({
    period,
    revenue: Math.round(revenue * 100) / 100,
  }));
}

export default router;
