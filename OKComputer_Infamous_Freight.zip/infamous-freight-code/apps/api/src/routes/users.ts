import { Router } from 'express';
import { body, param, query } from 'express-validator';
import { PrismaClient, UserStatus, UserRole } from '@prisma/client';
import bcrypt from 'bcrypt';
import { authenticate, requireRole } from '../middleware/auth';
import { validate } from '../middleware/errorHandler';
import { logger } from '../utils/logger';

const router = Router();
const prisma = new PrismaClient();

// Validation middleware
const createUserValidators = [
  body('email').isEmail().normalizeEmail().withMessage('Valid email is required'),
  body('firstName').trim().notEmpty().withMessage('First name is required'),
  body('lastName').trim().notEmpty().withMessage('Last name is required'),
  body('role').isIn(Object.values(UserRole)).withMessage('Valid role is required'),
  body('password')
    .optional()
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters'),
  validate,
];

const updateUserValidators = [
  param('id').isUUID().withMessage('Valid user ID is required'),
  body('firstName').optional().trim(),
  body('lastName').optional().trim(),
  body('role').optional().isIn(Object.values(UserRole)),
  body('status').optional().isIn(Object.values(UserStatus)),
  validate,
];

// Get all users (admin only)
router.get(
  '/',
  authenticate,
  requireRole(['ADMIN', 'MANAGER']),
  [
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 100 }),
    query('status').optional().isIn(Object.values(UserStatus)),
    query('role').optional().isIn(Object.values(UserRole)),
    query('search').optional().trim(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const skip = (page - 1) * limit;
      const status = req.query.status as UserStatus;
      const role = req.query.role as UserRole;
      const search = req.query.search as string;

      const where: any = {
        organizationId: req.user!.organizationId,
      };

      if (status) {
        where.status = status;
      }

      if (role) {
        where.role = role;
      }

      if (search) {
        where.OR = [
          { firstName: { contains: search, mode: 'insensitive' } },
          { lastName: { contains: search, mode: 'insensitive' } },
          { email: { contains: search, mode: 'insensitive' } },
        ];
      }

      const [users, total] = await Promise.all([
        prisma.user.findMany({
          where,
          skip,
          take: limit,
          orderBy: { createdAt: 'desc' },
          select: {
            id: true,
            email: true,
            firstName: true,
            lastName: true,
            role: true,
            status: true,
            lastLoginAt: true,
            createdAt: true,
            driver: {
              select: {
                id: true,
                cdlNumber: true,
              },
            },
          },
        }),
        prisma.user.count({ where }),
      ]);

      res.json({
        users,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get current user profile
router.get('/me', authenticate, async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.userId },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        status: true,
        lastLoginAt: true,
        createdAt: true,
        organization: {
          select: {
            id: true,
            name: true,
            status: true,
          },
        },
        driver: {
          include: {
            vehicles: {
              include: {
                vehicle: true,
              },
            },
          },
        },
        preferences: true,
      },
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(user);
  } catch (error) {
    next(error);
  }
});

// Update current user profile
router.patch(
  '/me',
  authenticate,
  [
    body('firstName').optional().trim(),
    body('lastName').optional().trim(),
    body('phone').optional().trim(),
    body('currentPassword').optional(),
    body('newPassword')
      .optional()
      .isLength({ min: 8 })
      .withMessage('Password must be at least 8 characters'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { firstName, lastName, phone, currentPassword, newPassword } = req.body;

      const updateData: any = {};

      if (firstName) updateData.firstName = firstName;
      if (lastName) updateData.lastName = lastName;
      if (phone) updateData.phone = phone;

      // Handle password change
      if (newPassword) {
        if (!currentPassword) {
          return res.status(400).json({ error: 'Current password is required to change password' });
        }

        const user = await prisma.user.findUnique({
          where: { id: req.user!.userId },
          select: { password: true },
        });

        const isValidPassword = await bcrypt.compare(currentPassword, user!.password);

        if (!isValidPassword) {
          return res.status(401).json({ error: 'Current password is incorrect' });
        }

        updateData.password = await bcrypt.hash(newPassword, 10);
      }

      const updatedUser = await prisma.user.update({
        where: { id: req.user!.userId },
        data: updateData,
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          role: true,
          status: true,
          lastLoginAt: true,
        },
      });

      res.json({
        message: 'Profile updated successfully',
        user: updatedUser,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get user by ID (admin only)
router.get(
  '/:id',
  authenticate,
  requireRole(['ADMIN', 'MANAGER']),
  [param('id').isUUID().withMessage('Valid user ID is required'), validate],
  async (req, res, next) => {
    try {
      const user = await prisma.user.findFirst({
        where: {
          id: req.params.id,
          organizationId: req.user!.organizationId,
        },
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          role: true,
          status: true,
          lastLoginAt: true,
          createdAt: true,
          phone: true,
          driver: {
            include: {
              shipments: {
                where: {
                  status: { in: ['IN_TRANSIT', 'PICKED_UP', 'AT_PICKUP'] },
                },
              },
            },
          },
          sessions: {
            where: {
              expiresAt: { gt: new Date() },
            },
            select: {
              id: true,
              createdAt: true,
              expiresAt: true,
              ipAddress: true,
              userAgent: true,
            },
          },
        },
      });

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      res.json(user);
    } catch (error) {
      next(error);
    }
  }
);

// Create new user (admin only)
router.post(
  '/',
  authenticate,
  requireRole(['ADMIN']),
  createUserValidators,
  async (req, res, next) => {
    try {
      const { email, firstName, lastName, role, phone, password } = req.body;

      // Check if user with email already exists
      const existingUser = await prisma.user.findUnique({
        where: { email },
      });

      if (existingUser) {
        return res.status(409).json({ error: 'User with this email already exists' });
      }

      // Generate temporary password if not provided
      const tempPassword = password || generateTemporaryPassword();
      const hashedPassword = await bcrypt.hash(tempPassword, 10);

      const user = await prisma.user.create({
        data: {
          email,
          password: hashedPassword,
          firstName,
          lastName,
          role,
          phone,
          organizationId: req.user!.organizationId,
          status: UserStatus.ACTIVE,
          emailVerified: false,
        },
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          role: true,
          status: true,
          createdAt: true,
        },
      });

      // TODO: Send welcome email with temporary password

      logger.info({ userId: user.id }, 'User created successfully');

      res.status(201).json({
        message: 'User created successfully',
        user,
        temporaryPassword: password ? undefined : tempPassword,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Update user (admin only)
router.patch(
  '/:id',
  authenticate,
  requireRole(['ADMIN']),
  updateUserValidators,
  async (req, res, next) => {
    try {
      const userId = req.params.id;

      // Verify user belongs to organization
      const existingUser = await prisma.user.findFirst({
        where: {
          id: userId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!existingUser) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Prevent modifying own role
      if (userId === req.user!.userId && req.body.role && req.body.role !== existingUser.role) {
        return res.status(400).json({ error: 'Cannot change your own role' });
      }

      const updateData: any = {};
      const allowedFields = ['firstName', 'lastName', 'role', 'status', 'phone'];

      allowedFields.forEach((field) => {
        if (req.body[field] !== undefined) {
          updateData[field] = req.body[field];
        }
      });

      const user = await prisma.user.update({
        where: { id: userId },
        data: updateData,
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          role: true,
          status: true,
          phone: true,
          lastLoginAt: true,
        },
      });

      logger.info({ userId }, 'User updated successfully');

      res.json({
        message: 'User updated successfully',
        user,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Delete user (admin only)
router.delete(
  '/:id',
  authenticate,
  requireRole(['ADMIN']),
  [param('id').isUUID().withMessage('Valid user ID is required'), validate],
  async (req, res, next) => {
    try {
      const userId = req.params.id;

      // Prevent self-deletion
      if (userId === req.user!.userId) {
        return res.status(400).json({ error: 'Cannot delete your own account' });
      }

      // Verify user belongs to organization
      const user = await prisma.user.findFirst({
        where: {
          id: userId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      await prisma.user.delete({
        where: { id: userId },
      });

      logger.info({ userId }, 'User deleted successfully');

      res.json({ message: 'User deleted successfully' });
    } catch (error) {
      next(error);
    }
  }
);

// Reset user password (admin only)
router.post(
  '/:id/reset-password',
  authenticate,
  requireRole(['ADMIN']),
  [param('id').isUUID().withMessage('Valid user ID is required'), validate],
  async (req, res, next) => {
    try {
      const userId = req.params.id;

      // Verify user belongs to organization
      const user = await prisma.user.findFirst({
        where: {
          id: userId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      const tempPassword = generateTemporaryPassword();
      const hashedPassword = await bcrypt.hash(tempPassword, 10);

      await prisma.user.update({
        where: { id: userId },
        data: {
          password: hashedPassword,
          passwordChangedAt: new Date(),
        },
      });

      // Invalidate all existing sessions
      await prisma.session.deleteMany({
        where: { userId },
      });

      // TODO: Send email with temporary password

      logger.info({ userId }, 'Password reset successfully');

      res.json({
        message: 'Password reset successfully',
        temporaryPassword: tempPassword,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get user activity log
router.get(
  '/:id/activity',
  authenticate,
  requireRole(['ADMIN', 'MANAGER']),
  [
    param('id').isUUID().withMessage('Valid user ID is required'),
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 100 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const userId = req.params.id;
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const skip = (page - 1) * limit;

      // Verify user belongs to organization
      const user = await prisma.user.findFirst({
        where: {
          id: userId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      const [activities, total] = await Promise.all([
        prisma.activityLog.findMany({
          where: { userId },
          skip,
          take: limit,
          orderBy: { createdAt: 'desc' },
        }),
        prisma.activityLog.count({ where: { userId } }),
      ]);

      res.json({
        activities,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

// Update user preferences
router.patch(
  '/me/preferences',
  authenticate,
  [
    body('theme').optional().isIn(['light', 'dark', 'system']),
    body('notifications').optional().isObject(),
    body('timezone').optional().trim(),
    body('dateFormat').optional().trim(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const preferences = req.body;

      const user = await prisma.user.update({
        where: { id: req.user!.userId },
        data: {
          preferences: {
            ...preferences,
          },
        },
        select: {
          preferences: true,
        },
      });

      res.json({
        message: 'Preferences updated successfully',
        preferences: user.preferences,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Helper function to generate temporary password
function generateTemporaryPassword(): string {
  const length = 12;
  const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
  let password = '';
  for (let i = 0; i < length; i++) {
    password += charset.charAt(Math.floor(Math.random() * charset.length));
  }
  return password;
}

export default router;
