import { Router } from 'express';
import { PrismaClient, ReferralStatus } from '@prisma/client';
import { authenticate } from '../middleware/auth';
import { logger } from '../utils/logger';

const router = Router();
const prisma = new PrismaClient();

// Get referral program details
router.get('/program', authenticate, async (req, res, next) => {
  try {
    const program = await prisma.referralProgram.findFirst({
      where: { isActive: true },
    });

    if (!program) {
      return res.status(404).json({ error: 'Referral program not found' });
    }

    res.json({ program });
  } catch (error) {
    next(error);
  }
});

// Get user's referral link and stats
router.get('/my-referrals', authenticate, async (req, res, next) => {
  try {
    const userId = (req as any).user.id;
    const organizationId = (req as any).user.organizationId;

    // Get or create referral code
    let referralCode = await prisma.referralCode.findUnique({
      where: { userId },
    });

    if (!referralCode) {
      // Generate unique code
      const code = generateReferralCode();
      referralCode = await prisma.referralCode.create({
        data: {
          code,
          userId,
          organizationId,
        },
      });
    }

    // Get referral statistics
    const referrals = await prisma.referral.findMany({
      where: { referrerId: userId },
      include: {
        referred: {
          select: {
            firstName: true,
            lastName: true,
            email: true,
            createdAt: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    const stats = {
      totalReferrals: referrals.length,
      pending: referrals.filter((r) => r.status === ReferralStatus.PENDING).length,
      converted: referrals.filter((r) => r.status === ReferralStatus.CONVERTED).length,
      rewarded: referrals.filter((r) => r.status === ReferralStatus.REWARDED).length,
      totalRewards: referrals
        .filter((r) => r.status === ReferralStatus.REWARDED)
        .reduce((sum, r) => sum + (r.rewardAmount || 0), 0),
    };

    res.json({
      referralCode: referralCode.code,
      referralLink: `${process.env.FRONTEND_URL}/signup?ref=${referralCode.code}`,
      stats,
      referrals,
    });
  } catch (error) {
    next(error);
  }
});

// Track referral signup
router.post('/track', async (req, res, next) => {
  try {
    const { code, referredEmail } = req.body;

    if (!code || !referredEmail) {
      return res.status(400).json({ error: 'Referral code and email are required' });
    }

    // Find referrer
    const referralCode = await prisma.referralCode.findUnique({
      where: { code },
      include: { user: true },
    });

    if (!referralCode) {
      return res.status(404).json({ error: 'Invalid referral code' });
    }

    // Check if email was already referred
    const existingReferral = await prisma.referral.findFirst({
      where: { referredEmail },
    });

    if (existingReferral) {
      return res.status(400).json({ error: 'Email already referred' });
    }

    // Create referral record
    const referral = await prisma.referral.create({
      data: {
        referrerId: referralCode.userId,
        referredEmail,
        code,
        status: ReferralStatus.PENDING,
      },
    });

    logger.info({ referralId: referral.id, referrerId: referralCode.userId }, 'Referral tracked');

    res.status(201).json({ referral });
  } catch (error) {
    next(error);
  }
});

// Convert referral (when referred user completes signup)
router.post('/convert', authenticate, async (req, res, next) => {
  try {
    const userId = (req as any).user.id;
    const { referralCode: code } = req.body;

    const referralCode = await prisma.referralCode.findUnique({
      where: { code },
    });

    if (!referralCode) {
      return res.status(404).json({ error: 'Invalid referral code' });
    }

    // Don't allow self-referral
    if (referralCode.userId === userId) {
      return res.status(400).json({ error: 'Cannot refer yourself' });
    }

    // Update referral
    const referral = await prisma.referral.updateMany({
      where: {
        code,
        status: ReferralStatus.PENDING,
      },
      data: {
        referredId: userId,
        status: ReferralStatus.CONVERTED,
        convertedAt: new Date(),
      },
    });

    // Get program details for reward
    const program = await prisma.referralProgram.findFirst({
      where: { isActive: true },
    });

    if (program && referral.count > 0) {
      // Create reward
      await prisma.referralReward.create({
        data: {
          referral: {
            connect: {
              referrerId_referredId: {
                referrerId: referralCode.userId,
                referredId: userId,
              },
            },
          },
          referrerId: referralCode.userId,
          amount: program.referrerReward,
          type: 'ACCOUNT_CREDIT',
          status: 'PENDING',
          description: `Referral reward for ${req.body.email || 'new user'}`,
        },
      });

      // Apply credit to referrer's organization
      await prisma.organization.update({
        where: { id: referralCode.organizationId },
        data: {
          accountCredit: {
            increment: program.referrerReward,
          },
        },
      });

      // Update referral status to rewarded
      await prisma.referral.updateMany({
        where: {
          code,
          referredId: userId,
        },
        data: {
          status: ReferralStatus.REWARDED,
          rewardAmount: program.referrerReward,
          rewardedAt: new Date(),
        },
      });
    }

    res.json({ success: true, message: 'Referral converted successfully' });
  } catch (error) {
    next(error);
  }
});

// Get referral leaderboard
router.get('/leaderboard', authenticate, async (req, res, next) => {
  try {
    const leaderboard = await prisma.referral.groupBy({
      by: ['referrerId'],
      where: {
        status: {
          in: [ReferralStatus.CONVERTED, ReferralStatus.REWARDED],
        },
      },
      _count: {
        id: true,
      },
      orderBy: {
        _count: {
          id: 'desc',
        },
      },
      take: 10,
    });

    // Get user details
    const leaderboardWithUsers = await Promise.all(
      leaderboard.map(async (entry) => {
        const user = await prisma.user.findUnique({
          where: { id: entry.referrerId },
          select: {
            firstName: true,
            lastName: true,
            organization: {
              select: { name: true },
            },
          },
        });

        const totalRewards = await prisma.referral.aggregate({
          where: {
            referrerId: entry.referrerId,
            status: ReferralStatus.REWARDED,
          },
          _sum: {
            rewardAmount: true,
          },
        });

        return {
          user: {
            name: `${user?.firstName} ${user?.lastName}`,
            organization: user?.organization?.name,
          },
          referrals: entry._count.id,
          totalRewards: totalRewards._sum.rewardAmount || 0,
        };
      })
    );

    res.json({ leaderboard: leaderboardWithUsers });
  } catch (error) {
    next(error);
  }
});

// Admin: Create/update referral program
router.post('/program', authenticate, async (req, res, next) => {
  try {
    const userRole = (req as any).user.role;
    if (!['ADMIN', 'SUPER_ADMIN'].includes(userRole)) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const {
      name,
      description,
      referrerReward,
      referredReward,
      minimumSpend,
      rewardType,
      startDate,
      endDate,
    } = req.body;

    const program = await prisma.referralProgram.upsert({
      where: { id: req.body.id || '' },
      update: {
        name,
        description,
        referrerReward,
        referredReward,
        minimumSpend,
        rewardType,
        startDate,
        endDate,
      },
      create: {
        name,
        description,
        referrerReward,
        referredReward,
        minimumSpend,
        rewardType,
        startDate,
        endDate,
        isActive: true,
      },
    });

    res.json({ program });
  } catch (error) {
    next(error);
  }
});

function generateReferralCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = 'REF';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

export default router;
