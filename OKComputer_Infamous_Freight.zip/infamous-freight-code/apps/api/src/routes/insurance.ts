import { Router } from 'express';
import { body } from 'express-validator';
import { authenticate } from '../middleware/auth';
import { InsuranceService } from '../services/insurance';
import { logger } from '../utils/logger';

const router = Router();

// Get coverage types
router.get('/coverage-types', authenticate, async (req, res) => {
  const types = InsuranceService.getCoverageTypes();
  res.json({ types });
});

// Get insurance quote
router.post(
  '/quote',
  authenticate,
  [
    body('shipmentId').isString().notEmpty(),
    body('cargoValue').isFloat({ min: 100 }),
    body('cargoType').isString(),
    body('coverageType').isIn(['ALL_RISK', 'NAMED_PERILS', 'TOTAL_LOSS']),
  ],
  async (req, res, next) => {
    try {
      const quote = await InsuranceService.getQuote(req.body);
      res.json({ quote });
    } catch (error) {
      next(error);
    }
  }
);

// Purchase insurance
router.post(
  '/purchase',
  authenticate,
  [
    body('shipmentId').isString().notEmpty(),
    body('quote').isObject(),
    body('coverageType').isIn(['ALL_RISK', 'NAMED_PERILS', 'TOTAL_LOSS']),
  ],
  async (req, res, next) => {
    try {
      const { shipmentId, quote, coverageType } = req.body;
      const organizationId = (req as any).user.organizationId;

      const insurance = await InsuranceService.purchase(
        shipmentId,
        organizationId,
        quote,
        coverageType
      );

      logger.info(
        { insuranceId: insurance.id, shipmentId, organizationId },
        'Insurance purchased'
      );

      res.status(201).json({ insurance });
    } catch (error) {
      next(error);
    }
  }
);

// File a claim
router.post(
  '/claims',
  authenticate,
  [
    body('insuranceId').isString().notEmpty(),
    body('incidentDate').isISO8601(),
    body('incidentType').isString().notEmpty(),
    body('description').isString().notEmpty(),
    body('estimatedLoss').isFloat({ min: 0 }),
  ],
  async (req, res, next) => {
    try {
      const { insuranceId, ...claimData } = req.body;
      const organizationId = (req as any).user.organizationId;

      const claim = await InsuranceService.fileClaim(insuranceId, organizationId, claimData);

      logger.info(
        { claimId: claim.id, insuranceId, organizationId },
        'Insurance claim filed'
      );

      res.status(201).json({ claim });
    } catch (error) {
      next(error);
    }
  }
);

// Get insurance details
router.get('/:id', authenticate, async (req, res, next) => {
  try {
    const { id } = req.params;
    const organizationId = (req as any).user.organizationId;

    const insurance = await InsuranceService.getDetails(id, organizationId);
    res.json({ insurance });
  } catch (error) {
    next(error);
  }
});

// Get insurance history
router.get('/history/all', authenticate, async (req, res, next) => {
  try {
    const organizationId = (req as any).user.organizationId;
    const history = await InsuranceService.getHistory(organizationId);
    res.json(history);
  } catch (error) {
    next(error);
  }
});

// Get all insurance policies
router.get('/', authenticate, async (req, res, next) => {
  try {
    const organizationId = (req as any).user.organizationId;
    const { status, page = '1', limit = '10' } = req.query;

    const where: any = { organizationId };
    if (status) {
      where.status = status;
    }

    const [policies, total] = await Promise.all([
      (req as any).prisma.insurance.findMany({
        where,
        include: {
          shipment: {
            select: {
              referenceNumber: true,
              originCity: true,
              originState: true,
              destinationCity: true,
              destinationState: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip: (parseInt(page as string) - 1) * parseInt(limit as string),
        take: parseInt(limit as string),
      }),
      (req as any).prisma.insurance.count({ where }),
    ]);

    res.json({
      policies,
      pagination: {
        page: parseInt(page as string),
        limit: parseInt(limit as string),
        total,
        totalPages: Math.ceil(total / parseInt(limit as string)),
      },
    });
  } catch (error) {
    next(error);
  }
});

export default router;
