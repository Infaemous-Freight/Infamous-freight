import { Router } from 'express';
import { body, param, query } from 'express-validator';
import { PrismaClient, VehicleStatus, VehicleType } from '@prisma/client';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/errorHandler';
import { logger } from '../utils/logger';

const router = Router();
const prisma = new PrismaClient();

// Validation middleware
const createVehicleValidators = [
  body('unitNumber').trim().notEmpty().withMessage('Unit number is required'),
  body('type').isIn(Object.values(VehicleType)).withMessage('Valid vehicle type is required'),
  body('make').trim().notEmpty().withMessage('Make is required'),
  body('model').trim().notEmpty().withMessage('Model is required'),
  body('year').isInt({ min: 1900, max: new Date().getFullYear() + 1 }),
  body('vin').trim().isLength({ min: 17, max: 17 }).withMessage('VIN must be 17 characters'),
  body('licensePlate').trim().notEmpty(),
  body('licensePlateState').trim().isLength({ min: 2, max: 2 }),
  body('gvw').optional().isInt({ min: 0 }),
  body('fuelType').optional().trim(),
  validate,
];

const updateVehicleValidators = [
  param('id').isUUID().withMessage('Valid vehicle ID is required'),
  body('make').optional().trim(),
  body('model').optional().trim(),
  body('year').optional().isInt(),
  body('licensePlate').optional().trim(),
  body('status').optional().isIn(Object.values(VehicleStatus)),
  validate,
];

// Get all vehicles with filtering and pagination
router.get(
  '/',
  authenticate,
  [
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 100 }),
    query('status').optional().isIn(Object.values(VehicleStatus)),
    query('type').optional().isIn(Object.values(VehicleType)),
    query('search').optional().trim(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const skip = (page - 1) * limit;
      const status = req.query.status as VehicleStatus;
      const type = req.query.type as VehicleType;
      const search = req.query.search as string;

      const where: any = {
        organizationId: req.user!.organizationId,
      };

      if (status) {
        where.status = status;
      }

      if (type) {
        where.type = type;
      }

      if (search) {
        where.OR = [
          { unitNumber: { contains: search, mode: 'insensitive' } },
          { make: { contains: search, mode: 'insensitive' } },
          { model: { contains: search, mode: 'insensitive' } },
          { vin: { contains: search, mode: 'insensitive' } },
          { licensePlate: { contains: search, mode: 'insensitive' } },
        ];
      }

      const [vehicles, total] = await Promise.all([
        prisma.vehicle.findMany({
          where,
          skip,
          take: limit,
          orderBy: { unitNumber: 'asc' },
          include: {
            drivers: {
              include: {
                driver: {
                  select: {
                    id: true,
                    firstName: true,
                    lastName: true,
                    status: true,
                  },
                },
              },
            },
            _count: {
              select: {
                shipments: true,
                maintenanceRecords: true,
              },
            },
          },
        }),
        prisma.vehicle.count({ where }),
      ]);

      res.json({
        vehicles,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get vehicle by ID
router.get(
  '/:id',
  authenticate,
  [param('id').isUUID().withMessage('Valid vehicle ID is required'), validate],
  async (req, res, next) => {
    try {
      const vehicle = await prisma.vehicle.findFirst({
        where: {
          id: req.params.id,
          organizationId: req.user!.organizationId,
        },
        include: {
          drivers: {
            include: {
              driver: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  email: true,
                  phone: true,
                  status: true,
                },
              },
            },
          },
          shipments: {
            where: {
              status: { in: ['IN_TRANSIT', 'PICKED_UP', 'AT_PICKUP'] },
            },
            include: {
              stops: true,
              driver: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                },
              },
            },
          },
          maintenanceRecords: {
            orderBy: { date: 'desc' },
            take: 10,
          },
        },
      });

      if (!vehicle) {
        return res.status(404).json({ error: 'Vehicle not found' });
      }

      res.json(vehicle);
    } catch (error) {
      next(error);
    }
  }
);

// Create new vehicle
router.post(
  '/',
  authenticate,
  createVehicleValidators,
  async (req, res, next) => {
    try {
      const {
        unitNumber,
        type,
        make,
        model,
        year,
        vin,
        licensePlate,
        licensePlateState,
        gvw,
        fuelType,
        color,
        registrationExpiration,
        insuranceExpiration,
        iftaStatus,
        eldDeviceId,
        gpsDeviceId,
      } = req.body;

      // Check if VIN already exists
      const existingVin = await prisma.vehicle.findUnique({
        where: { vin: vin.toUpperCase() },
      });

      if (existingVin) {
        return res.status(409).json({ error: 'Vehicle with this VIN already exists' });
      }

      // Check if unit number already exists in organization
      const existingUnit = await prisma.vehicle.findFirst({
        where: {
          unitNumber: unitNumber.toUpperCase(),
          organizationId: req.user!.organizationId,
        },
      });

      if (existingUnit) {
        return res.status(409).json({ error: 'Vehicle with this unit number already exists' });
      }

      const vehicle = await prisma.vehicle.create({
        data: {
          unitNumber: unitNumber.toUpperCase(),
          type,
          make,
          model,
          year,
          vin: vin.toUpperCase(),
          licensePlate: licensePlate.toUpperCase(),
          licensePlateState: licensePlateState.toUpperCase(),
          gvw,
          fuelType,
          color,
          registrationExpiration: registrationExpiration ? new Date(registrationExpiration) : null,
          insuranceExpiration: insuranceExpiration ? new Date(insuranceExpiration) : null,
          iftaStatus: iftaStatus || false,
          eldDeviceId,
          gpsDeviceId,
          organizationId: req.user!.organizationId,
          status: VehicleStatus.ACTIVE,
        },
      });

      logger.info({ vehicleId: vehicle.id }, 'Vehicle created successfully');

      res.status(201).json({
        message: 'Vehicle created successfully',
        vehicle,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Update vehicle
router.patch(
  '/:id',
  authenticate,
  updateVehicleValidators,
  async (req, res, next) => {
    try {
      const vehicleId = req.params.id;

      // Verify vehicle belongs to organization
      const existingVehicle = await prisma.vehicle.findFirst({
        where: {
          id: vehicleId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!existingVehicle) {
        return res.status(404).json({ error: 'Vehicle not found' });
      }

      const updateData: any = {};
      const allowedFields = [
        'make',
        'model',
        'year',
        'licensePlate',
        'licensePlateState',
        'gvw',
        'fuelType',
        'color',
        'registrationExpiration',
        'insuranceExpiration',
        'iftaStatus',
        'eldDeviceId',
        'gpsDeviceId',
        'status',
        'currentMileage',
      ];

      allowedFields.forEach((field) => {
        if (req.body[field] !== undefined) {
          if (field.includes('Expiration')) {
            updateData[field] = new Date(req.body[field]);
          } else {
            updateData[field] = req.body[field];
          }
        }
      });

      const vehicle = await prisma.vehicle.update({
        where: { id: vehicleId },
        data: updateData,
      });

      logger.info({ vehicleId }, 'Vehicle updated successfully');

      res.json({
        message: 'Vehicle updated successfully',
        vehicle,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Delete vehicle
router.delete(
  '/:id',
  authenticate,
  [param('id').isUUID().withMessage('Valid vehicle ID is required'), validate],
  async (req, res, next) => {
    try {
      const vehicleId = req.params.id;

      // Verify vehicle belongs to organization and has no active shipments
      const vehicle = await prisma.vehicle.findFirst({
        where: {
          id: vehicleId,
          organizationId: req.user!.organizationId,
        },
        include: {
          shipments: {
            where: {
              status: { in: ['IN_TRANSIT', 'PICKED_UP', 'AT_PICKUP'] },
            },
          },
        },
      });

      if (!vehicle) {
        return res.status(404).json({ error: 'Vehicle not found' });
      }

      if (vehicle.shipments.length > 0) {
        return res.status(400).json({
          error: 'Cannot delete vehicle with active shipments',
          activeShipments: vehicle.shipments.length,
        });
      }

      await prisma.vehicle.delete({
        where: { id: vehicleId },
      });

      logger.info({ vehicleId }, 'Vehicle deleted successfully');

      res.json({ message: 'Vehicle deleted successfully' });
    } catch (error) {
      next(error);
    }
  }
);

// Assign driver to vehicle
router.post(
  '/:id/drivers',
  authenticate,
  [
    param('id').isUUID().withMessage('Valid vehicle ID is required'),
    body('driverId').isUUID().withMessage('Valid driver ID is required'),
    body('isPrimary').optional().isBoolean(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const vehicleId = req.params.id;
      const { driverId, isPrimary = false } = req.body;

      // Verify vehicle belongs to organization
      const vehicle = await prisma.vehicle.findFirst({
        where: {
          id: vehicleId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!vehicle) {
        return res.status(404).json({ error: 'Vehicle not found' });
      }

      // Verify driver belongs to organization
      const driver = await prisma.driver.findFirst({
        where: {
          id: driverId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!driver) {
        return res.status(404).json({ error: 'Driver not found' });
      }

      // Check if assignment already exists
      const existingAssignment = await prisma.driverVehicle.findUnique({
        where: {
          driverId_vehicleId: {
            driverId,
            vehicleId,
          },
        },
      });

      if (existingAssignment) {
        return res.status(409).json({ error: 'Driver is already assigned to this vehicle' });
      }

      const assignment = await prisma.driverVehicle.create({
        data: {
          driverId,
          vehicleId,
          isPrimary,
          assignedAt: new Date(),
        },
      });

      logger.info({ vehicleId, driverId }, 'Driver assigned to vehicle');

      res.status(201).json({
        message: 'Driver assigned to vehicle successfully',
        assignment,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Remove driver from vehicle
router.delete(
  '/:id/drivers/:driverId',
  authenticate,
  [
    param('id').isUUID().withMessage('Valid vehicle ID is required'),
    param('driverId').isUUID().withMessage('Valid driver ID is required'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const vehicleId = req.params.id;
      const driverId = req.params.driverId;

      // Verify vehicle belongs to organization
      const vehicle = await prisma.vehicle.findFirst({
        where: {
          id: vehicleId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!vehicle) {
        return res.status(404).json({ error: 'Vehicle not found' });
      }

      await prisma.driverVehicle.delete({
        where: {
          driverId_vehicleId: {
            driverId,
            vehicleId,
          },
        },
      });

      logger.info({ vehicleId, driverId }, 'Driver removed from vehicle');

      res.json({ message: 'Driver removed from vehicle successfully' });
    } catch (error) {
      next(error);
    }
  }
);

// Get maintenance records
router.get(
  '/:id/maintenance',
  authenticate,
  [
    param('id').isUUID().withMessage('Valid vehicle ID is required'),
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 100 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const vehicleId = req.params.id;
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const skip = (page - 1) * limit;

      // Verify vehicle belongs to organization
      const vehicle = await prisma.vehicle.findFirst({
        where: {
          id: vehicleId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!vehicle) {
        return res.status(404).json({ error: 'Vehicle not found' });
      }

      const [records, total] = await Promise.all([
        prisma.maintenanceRecord.findMany({
          where: { vehicleId },
          skip,
          take: limit,
          orderBy: { date: 'desc' },
        }),
        prisma.maintenanceRecord.count({ where: { vehicleId } }),
      ]);

      res.json({
        records,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

// Create maintenance record
router.post(
  '/:id/maintenance',
  authenticate,
  [
    param('id').isUUID().withMessage('Valid vehicle ID is required'),
    body('date').isISO8601().withMessage('Valid date is required'),
    body('type').trim().notEmpty(),
    body('description').trim().notEmpty(),
    body('cost').optional().isFloat({ min: 0 }),
    body('mileage').optional().isInt({ min: 0 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const vehicleId = req.params.id;
      const { date, type, description, cost, mileage, vendor, invoiceNumber, notes } = req.body;

      // Verify vehicle belongs to organization
      const vehicle = await prisma.vehicle.findFirst({
        where: {
          id: vehicleId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!vehicle) {
        return res.status(404).json({ error: 'Vehicle not found' });
      }

      const record = await prisma.maintenanceRecord.create({
        data: {
          vehicleId,
          date: new Date(date),
          type,
          description,
          cost,
          mileage,
          vendor,
          invoiceNumber,
          notes,
        },
      });

      // Update vehicle mileage if provided
      if (mileage && mileage > (vehicle.currentMileage || 0)) {
        await prisma.vehicle.update({
          where: { id: vehicleId },
          data: { currentMileage: mileage },
        });
      }

      res.status(201).json({
        message: 'Maintenance record created successfully',
        record,
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get vehicle utilization stats
router.get(
  '/:id/utilization',
  authenticate,
  [param('id').isUUID().withMessage('Valid vehicle ID is required'), validate],
  async (req, res, next) => {
    try {
      const vehicleId = req.params.id;

      // Verify vehicle belongs to organization
      const vehicle = await prisma.vehicle.findFirst({
        where: {
          id: vehicleId,
          organizationId: req.user!.organizationId,
        },
      });

      if (!vehicle) {
        return res.status(404).json({ error: 'Vehicle not found' });
      }

      // Get completed shipments in last 90 days
      const shipments = await prisma.shipment.findMany({
        where: {
          vehicleId,
          status: 'DELIVERED',
          actualDeliveryDate: {
            gte: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000),
          },
        },
      });

      const totalShipments = shipments.length;
      const totalMiles = shipments.reduce((sum, s) => sum + (s.totalMiles || 0), 0);
      const totalRevenue = shipments.reduce((sum, s) => sum + (s.rate || 0), 0);

      // Get maintenance costs
      const maintenanceRecords = await prisma.maintenanceRecord.findMany({
        where: {
          vehicleId,
          date: {
            gte: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000),
          },
        },
      });

      const totalMaintenanceCost = maintenanceRecords.reduce((sum, r) => sum + (r.cost || 0), 0);

      res.json({
        period: 'last_90_days',
        shipments: {
          total: totalShipments,
          averagePerMonth: Math.round((totalShipments / 3) * 100) / 100,
        },
        mileage: {
          total: totalMiles,
          averagePerShipment: totalShipments > 0 ? Math.round((totalMiles / totalShipments) * 100) / 100 : 0,
        },
        financial: {
          revenue: totalRevenue,
          maintenanceCost: totalMaintenanceCost,
          netContribution: totalRevenue - totalMaintenanceCost,
          revenuePerMile: totalMiles > 0 ? Math.round((totalRevenue / totalMiles) * 100) / 100 : 0,
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

export default router;
