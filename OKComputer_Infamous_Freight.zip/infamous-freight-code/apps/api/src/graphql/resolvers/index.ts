import { PrismaClient } from '@prisma/client';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { PubSub } from 'graphql-subscriptions';
import { logger } from '../../utils/logger';
import { MLPredictionService } from '../../ml/predictionService';

const prisma = new PrismaClient();
export const pubsub = new PubSub();

// Auth helpers
const generateTokens = (user: any) => {
  const accessToken = jwt.sign(
    { userId: user.id, role: user.role, organizationId: user.organizationId },
    process.env.JWT_SECRET!,
    { expiresIn: '15m' }
  );
  const refreshToken = jwt.sign(
    { userId: user.id, type: 'refresh' },
    process.env.JWT_SECRET!,
    { expiresIn: '7d' }
  );
  return { accessToken, refreshToken };
};

export const resolvers = {
  DateTime: {
    __parseValue(value: any) {
      return new Date(value);
    },
    __serialize(value: any) {
      return value instanceof Date ? value.toISOString() : value;
    },
    __parseLiteral(ast: any) {
      return new Date(ast.value);
    },
  },

  Query: {
    // Me & Organization
    me: async (_: any, __: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return prisma.user.findUnique({
        where: { id: user.userId },
        include: { organization: true },
      });
    },

    myOrganization: async (_: any, __: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return prisma.organization.findUnique({
        where: { id: user.organizationId },
      });
    },

    organization: async (_: any, { id }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return prisma.organization.findUnique({ where: { id } });
    },

    organizations: async (_: any, __: any, { user }: any) => {
      if (!user || user.role !== 'SUPER_ADMIN') throw new Error('Unauthorized');
      return prisma.organization.findMany();
    },

    // Users
    user: async (_: any, { id }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return prisma.user.findFirst({
        where: { id, organizationId: user.organizationId },
      });
    },

    users: async (_: any, { role, status }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const where: any = { organizationId: user.organizationId };
      if (role) where.role = role;
      if (status) where.status = status;
      return prisma.user.findMany({ where });
    },

    // Drivers
    driver: async (_: any, { id }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return prisma.driver.findFirst({
        where: { id, organizationId: user.organizationId },
        include: { user: true },
      });
    },

    drivers: async (_: any, { status, available }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const where: any = { organizationId: user.organizationId };
      if (status) where.status = status;
      if (available) where.status = 'AVAILABLE';
      return prisma.driver.findMany({
        where,
        include: { user: true },
      });
    },

    driverPerformance: async (_: any, { id }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const driver = await prisma.driver.findFirst({
        where: { id, organizationId: user.organizationId },
      });
      if (!driver) throw new Error('Driver not found');

      const shipments = await prisma.shipment.findMany({
        where: { driverId: id },
      });

      const onTimeDeliveries = shipments.filter(
        (s) => s.actualDeliveryDate && s.scheduledDeliveryDate &&
          new Date(s.actualDeliveryDate) <= new Date(s.scheduledDeliveryDate)
      ).length;

      const totalMiles = shipments.reduce((sum, s) => sum + (s.totalMiles || 0), 0);

      return {
        totalShipments: shipments.length,
        onTimeDeliveries,
        onTimeRate: shipments.length > 0 ? (onTimeDeliveries / shipments.length) * 100 : 0,
        totalMiles,
        averageMilesPerDay: totalMiles / 30, // Simplified
        fuelEfficiency: 7.5, // Placeholder
        safetyScore: driver.safetyScore || 100,
        customerRating: driver.rating || 5,
      };
    },

    // Vehicles
    vehicle: async (_: any, { id }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return prisma.vehicle.findFirst({
        where: { id, organizationId: user.organizationId },
        include: { drivers: { include: { driver: true } } },
      });
    },

    vehicles: async (_: any, { status }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const where: any = { organizationId: user.organizationId };
      if (status) where.status = status;
      return prisma.vehicle.findMany({ where });
    },

    vehicleHealth: async (_: any, { id }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const vehicle = await prisma.vehicle.findFirst({
        where: { id, organizationId: user.organizationId },
      });
      if (!vehicle) throw new Error('Vehicle not found');

      // Use ML service for predictions
      return MLPredictionService.predictMaintenance(vehicle);
    },

    // Shipments
    shipment: async (_: any, { id }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return prisma.shipment.findFirst({
        where: { id, organizationId: user.organizationId },
        include: {
          driver: { include: { user: true } },
          vehicle: true,
          stops: true,
          invoice: true,
        },
      });
    },

    shipments: async (_: any, args: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const where: any = { organizationId: user.organizationId };
      if (args.status) where.status = args.status;
      if (args.driverId) where.driverId = args.driverId;
      if (args.vehicleId) where.vehicleId = args.vehicleId;
      if (args.startDate || args.endDate) {
        where.createdAt = {};
        if (args.startDate) where.createdAt.gte = args.startDate;
        if (args.endDate) where.createdAt.lte = args.endDate;
      }

      return prisma.shipment.findMany({
        where,
        include: {
          driver: { include: { user: true } },
          vehicle: true,
        },
        take: args.limit || 50,
        skip: args.offset || 0,
        orderBy: { createdAt: 'desc' },
      });
    },

    shipmentCount: async (_: any, { status }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const where: any = { organizationId: user.organizationId };
      if (status) where.status = status;
      return prisma.shipment.count({ where });
    },

    trackingHistory: async (_: any, { shipmentId }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return prisma.trackingEvent.findMany({
        where: { shipmentId },
        orderBy: { recordedAt: 'desc' },
      });
    },

    // Invoices
    invoice: async (_: any, { id }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return prisma.invoice.findFirst({
        where: { id, organizationId: user.organizationId },
        include: {
          shipment: true,
          payments: true,
          factoring: true,
        },
      });
    },

    invoices: async (_: any, { status, overdue }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const where: any = { organizationId: user.organizationId };
      if (status) where.status = status;
      if (overdue) {
        where.status = 'OVERDUE';
        where.dueDate = { lt: new Date() };
      }
      return prisma.invoice.findMany({
        where,
        include: { shipment: true },
        orderBy: { createdAt: 'desc' },
      });
    },

    invoiceAging: async (_: any, __: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const now = new Date();
      const invoices = await prisma.invoice.findMany({
        where: {
          organizationId: user.organizationId,
          status: { in: ['SENT', 'VIEWED', 'PARTIAL', 'OVERDUE'] },
        },
      });

      const aging = {
        current: 0,
        days1to30: 0,
        days31to60: 0,
        days61to90: 0,
        days90Plus: 0,
      };

      invoices.forEach((inv) => {
        const daysOverdue = Math.floor(
          (now.getTime() - inv.dueDate.getTime()) / (1000 * 60 * 60 * 24)
        );
        const amount = inv.balanceDue;

        if (daysOverdue <= 0) aging.current += amount;
        else if (daysOverdue <= 30) aging.days1to30 += amount;
        else if (daysOverdue <= 60) aging.days31to60 += amount;
        else if (daysOverdue <= 90) aging.days61to90 += amount;
        else aging.days90Plus += amount;
      });

      return aging;
    },

    revenueReport: async (_: any, { startDate, endDate }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const shipments = await prisma.shipment.findMany({
        where: {
          organizationId: user.organizationId,
          actualDeliveryDate: {
            gte: startDate,
            lte: endDate,
          },
        },
        include: { invoice: true },
      });

      const totalRevenue = shipments.reduce((sum, s) => sum + (s.rate || 0), 0);
      const totalMiles = shipments.reduce((sum, s) => sum + (s.totalMiles || 0), 0);

      return {
        totalRevenue,
        totalShipments: shipments.length,
        totalMiles,
        revenuePerMile: totalMiles > 0 ? totalRevenue / totalMiles : 0,
        averageRate: shipments.length > 0 ? totalRevenue / shipments.length : 0,
      };
    },

    // Analytics
    dashboardStats: async (_: any, __: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const orgId = user.organizationId;
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const thisMonth = new Date(today.getFullYear(), today.getMonth(), 1);
      const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);

      const [
        activeShipments,
        availableDrivers,
        activeVehicles,
        pendingInvoices,
        todayDeliveries,
        revenueToday,
        revenueThisMonth,
        revenueLastMonth,
        completedShipments,
        onTimeDeliveries,
        totalMiles,
        totalFuelCost,
      ] = await Promise.all([
        prisma.shipment.count({
          where: { organizationId: orgId, status: { in: ['DISPATCHED', 'IN_TRANSIT'] } },
        }),
        prisma.driver.count({
          where: { organizationId: orgId, status: 'AVAILABLE' },
        }),
        prisma.vehicle.count({
          where: { organizationId: orgId, status: 'ACTIVE' },
        }),
        prisma.invoice.count({
          where: { organizationId: orgId, status: { in: ['SENT', 'VIEWED', 'PARTIAL'] } },
        }),
        prisma.shipment.count({
          where: {
            organizationId: orgId,
            status: 'DELIVERED',
            actualDeliveryDate: { gte: today },
          },
        }),
        prisma.shipment.aggregate({
          where: {
            organizationId: orgId,
            actualDeliveryDate: { gte: today },
          },
          _sum: { rate: true },
        }),
        prisma.shipment.aggregate({
          where: {
            organizationId: orgId,
            actualDeliveryDate: { gte: thisMonth },
          },
          _sum: { rate: true },
        }),
        prisma.shipment.aggregate({
          where: {
            organizationId: orgId,
            actualDeliveryDate: { gte: lastMonth, lt: thisMonth },
          },
          _sum: { rate: true },
        }),
        prisma.shipment.findMany({
          where: {
            organizationId: orgId,
            actualDeliveryDate: { gte: thisMonth },
          },
        }),
        prisma.shipment.count({
          where: {
            organizationId: orgId,
            status: 'DELIVERED',
            actualDeliveryDate: { gte: thisMonth },
            scheduledDeliveryDate: {
              gte: prisma.shipment.fields.actualDeliveryDate,
            },
          },
        }),
        prisma.shipment.aggregate({
          where: { organizationId: orgId },
          _sum: { totalMiles: true },
        }),
        prisma.shipment.aggregate({
          where: { organizationId: orgId },
          _sum: { actualFuelCost: true },
        }),
      ]);

      const completedCount = completedShipments.length;
      const revenueGrowth = revenueLastMonth._sum.rate
        ? ((revenueThisMonth._sum.rate! - revenueLastMonth._sum.rate!) / revenueLastMonth._sum.rate!) * 100
        : 0;

      return {
        activeShipments,
        availableDrivers,
        activeVehicles,
        pendingInvoices,
        todayDeliveries,
        revenueToday: revenueToday._sum.rate || 0,
        revenueThisMonth: revenueThisMonth._sum.rate || 0,
        revenueGrowth,
        onTimeDeliveryRate: completedCount > 0 ? (onTimeDeliveries / completedCount) * 100 : 0,
        averageTransitTime: 24, // Simplified
        costPerMile: totalMiles._sum.totalMiles
          ? (totalFuelCost._sum.actualFuelCost || 0) / totalMiles._sum.totalMiles
          : 0,
        revenuePerMile: totalMiles._sum.totalMiles
          ? (revenueThisMonth._sum.rate || 0) / totalMiles._sum.totalMiles
          : 0,
        driverUtilization: 75, // Placeholder
        fuelEfficiency: 7.2, // Placeholder
      };
    },

    kpis: async (_: any, __: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const stats = await resolvers.Query.dashboardStats(_, __, { user });
      return {
        onTimeDelivery: stats.onTimeDeliveryRate,
        averageTransitTime: stats.averageTransitTime,
        costPerMile: stats.costPerMile,
        revenuePerMile: stats.revenuePerMile,
        driverUtilization: stats.driverUtilization,
        fuelEfficiency: stats.fuelEfficiency,
      };
    },

    executiveSummary: async (_: any, __: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      if (!['ADMIN', 'SUPER_ADMIN'].includes(user.role)) {
        throw new Error('Unauthorized');
      }

      const orgId = user.organizationId;
      const now = new Date();
      const startOfYear = new Date(now.getFullYear(), 0, 1);

      const [
        totalCustomers,
        totalShipments,
        totalRevenue,
        activeUsers,
        churnRisk,
      ] = await Promise.all([
        prisma.shipment.groupBy({
          by: ['customerName'],
          where: { organizationId: orgId },
        }).then((g) => g.length),
        prisma.shipment.count({ where: { organizationId: orgId } }),
        prisma.shipment.aggregate({
          where: { organizationId: orgId },
          _sum: { rate: true },
        }),
        prisma.user.count({
          where: { organizationId: orgId, status: 'ACTIVE' },
        }),
        MLPredictionService.predictChurnRisk(orgId),
      ]);

      return {
        totalCustomers,
        totalShipments,
        totalRevenue: totalRevenue._sum.rate || 0,
        activeUsers,
        churnRisk,
        growthMetrics: {
          customerGrowth: 15,
          revenueGrowth: 42,
          shipmentGrowth: 28,
        },
        efficiencyMetrics: {
          averageLoadTime: 4.2,
          dispatcherProductivity: 18,
          automatedMatches: 67,
        },
      };
    },

    // AI
    loadRecommendations: async (_: any, { driverId, limit = 5 }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return MLPredictionService.getLoadRecommendations(user.organizationId, driverId, limit);
    },

    routeOptimization: async (_: any, { shipmentId }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const shipment = await prisma.shipment.findFirst({
        where: { id: shipmentId, organizationId: user.organizationId },
        include: { stops: true },
      });
      if (!shipment) throw new Error('Shipment not found');
      return MLPredictionService.optimizeRoute(shipment);
    },

    // Predictions
    churnRisks: async (_: any, __: any, { user }: any) => {
      if (!user || user.role !== 'SUPER_ADMIN') throw new Error('Unauthorized');
      return MLPredictionService.getAllChurnRisks();
    },

    fraudAlerts: async (_: any, __: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return MLPredictionService.getFraudAlerts(user.organizationId);
    },

    demandForecast: async (_: any, { region, days = 30 }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return MLPredictionService.forecastDemand(region, days);
    },

    dynamicPrice: async (_: any, { origin, destination, equipmentType }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return MLPredictionService.getDynamicPrice(origin, destination, equipmentType);
    },

    // Notifications
    notifications: async (_: any, { unreadOnly }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const where: any = { userId: user.userId };
      if (unreadOnly) where.read = false;
      return prisma.notification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: 50,
      });
    },

    notificationCount: async (_: any, __: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return prisma.notification.count({
        where: { userId: user.userId, read: false },
      });
    },
  },

  Mutation: {
    // Auth
    login: async (_: any, { email, password }: any) => {
      const user = await prisma.user.findUnique({
        where: { email },
        include: { organization: true },
      });

      if (!user || !(await bcrypt.compare(password, user.password))) {
        throw new Error('Invalid credentials');
      }

      if (user.status !== 'ACTIVE') {
        throw new Error('Account is not active');
      }

      await prisma.user.update({
        where: { id: user.id },
        data: { lastLoginAt: new Date() },
      });

      const tokens = generateTokens(user);
      return { user, ...tokens };
    },

    logout: async (_: any, __: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      // Invalidate refresh token logic here
      return true;
    },

    refreshToken: async (_: any, __: any, { refreshToken }: any) => {
      try {
        const decoded = jwt.verify(refreshToken, process.env.JWT_SECRET!) as any;
        const user = await prisma.user.findUnique({
          where: { id: decoded.userId },
          include: { organization: true },
        });
        if (!user) throw new Error('User not found');
        const tokens = generateTokens(user);
        return { user, ...tokens };
      } catch (error) {
        throw new Error('Invalid refresh token');
      }
    },

    // Users
    createUser: async (_: any, { input }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const hashedPassword = await bcrypt.hash(input.password, 10);
      return prisma.user.create({
        data: {
          ...input,
          password: hashedPassword,
          organizationId: user.organizationId,
        },
      });
    },

    updateUser: async (_: any, { id, input }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return prisma.user.updateMany({
        where: { id, organizationId: user.organizationId },
        data: input,
      }).then(() => prisma.user.findUnique({ where: { id } }));
    },

    deleteUser: async (_: any, { id }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      await prisma.user.deleteMany({
        where: { id, organizationId: user.organizationId },
      });
      return true;
    },

    // Shipments
    createShipment: async (_: any, { input }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const shipment = await prisma.shipment.create({
        data: {
          ...input,
          referenceNumber: `SHP-${Date.now()}`,
          organizationId: user.organizationId,
        },
        include: { driver: true, vehicle: true },
      });

      // Publish event
      pubsub.publish('SHIPMENT_UPDATED', {
        shipmentUpdated: shipment,
      });

      return shipment;
    },

    updateShipment: async (_: any, { id, input }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      const shipment = await prisma.shipment.updateMany({
        where: { id, organizationId: user.organizationId },
        data: input,
      }).then(() =>
        prisma.shipment.findUnique({
          where: { id },
          include: { driver: true, vehicle: true },
        })
      );

      pubsub.publish('SHIPMENT_UPDATED', { shipmentUpdated: shipment });
      return shipment;
    },

    updateShipmentStatus: async (_: any, { id, status, notes }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');

      const updateData: any = { status };
      if (status === 'PICKED_UP') updateData.actualPickupDate = new Date();
      if (status === 'DELIVERED') updateData.actualDeliveryDate = new Date();

      const shipment = await prisma.shipment.update({
        where: { id },
        data: updateData,
        include: { driver: true, vehicle: true },
      });

      // Create tracking event
      await prisma.trackingEvent.create({
        data: {
          shipmentId: id,
          latitude: shipment.currentLatitude || 0,
          longitude: shipment.currentLongitude || 0,
          notes: `Status changed to ${status}${notes ? `: ${notes}` : ''}`,
          recordedAt: new Date(),
        },
      });

      pubsub.publish('SHIPMENT_UPDATED', { shipmentUpdated: shipment });
      return shipment;
    },

    addTrackingEvent: async (_: any, { shipmentId, input }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');

      const event = await prisma.trackingEvent.create({
        data: {
          ...input,
          shipmentId,
          recordedAt: new Date(),
        },
      });

      // Update shipment location
      await prisma.shipment.update({
        where: { id: shipmentId },
        data: {
          currentLatitude: input.latitude,
          currentLongitude: input.longitude,
        },
      });

      pubsub.publish('TRACKING_UPDATE', { trackingUpdate: event });
      return event;
    },

    // Notifications
    markNotificationRead: async (_: any, { id }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      return prisma.notification.update({
        where: { id },
        data: { read: true },
      });
    },

    markAllNotificationsRead: async (_: any, __: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      await prisma.notification.updateMany({
        where: { userId: user.userId, read: false },
        data: { read: true },
      });
      return true;
    },

    processNaturalLanguageCommand: async (_: any, { command }: any, { user }: any) => {
      if (!user) throw new Error('Not authenticated');
      // Integrate with OpenAI for NLP processing
      return {
        success: true,
        action: 'CREATE_SHIPMENT',
        message: 'Shipment created successfully',
        data: { shipmentId: '123' },
      };
    },
  },

  Subscription: {
    shipmentUpdated: {
      subscribe: () => pubsub.asyncIterator(['SHIPMENT_UPDATED']),
    },
    trackingUpdate: {
      subscribe: (_: any, { shipmentId }: any) =>
        pubsub.asyncIterator(['TRACKING_UPDATE']),
    },
    notificationReceived: {
      subscribe: (_: any, __: any, { user }: any) => {
        if (!user) throw new Error('Not authenticated');
        return pubsub.asyncIterator(['NOTIFICATION_RECEIVED']);
      },
    },
    organizationStatsUpdated: {
      subscribe: (_: any, { organizationId }: any, { user }: any) => {
        if (!user || user.organizationId !== organizationId) {
          throw new Error('Unauthorized');
        }
        return pubsub.asyncIterator(['ORG_STATS_UPDATED']);
      },
    },
  },

  // Field resolvers
  User: {
    fullName: (parent: any) => `${parent.firstName} ${parent.lastName}`,
    notificationCount: async (parent: any) => {
      return prisma.notification.count({
        where: { userId: parent.id, read: false },
      });
    },
  },

  Driver: {
    fullName: (parent: any) => `${parent.firstName} ${parent.lastName}`,
    hosSummary: async (parent: any) => {
      // Calculate HOS summary
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const todayLogs = await prisma.hosLog.findMany({
        where: { driverId: parent.id, date: today },
      });

      const dailyDrivingHours = todayLogs
        .filter((l) => l.dutyStatus === 'D')
        .reduce((sum, l) => sum + l.hours, 0);

      const dailyDutyHours = todayLogs.reduce((sum, l) => sum + l.hours, 0);

      return {
        dailyDrivingHours,
        dailyDutyHours,
        weeklyHours: 50, // Simplified
        remainingDrivingHours: Math.max(0, 11 - dailyDrivingHours),
        remainingDutyHours: Math.max(0, 14 - dailyDutyHours),
        lastRestBreak: null,
        violations: [],
      };
    },
  },

  Shipment: {
    currentLocation: (parent: any) => {
      if (!parent.currentLatitude || !parent.currentLongitude) return null;
      return {
        latitude: parent.currentLatitude,
        longitude: parent.currentLongitude,
        timestamp: parent.updatedAt,
      };
    },
    eta: async (parent: any) => {
      // Calculate ETA based on current location and route
      if (!parent.currentLatitude || !parent.scheduledDeliveryDate) return null;
      return {
        estimatedArrival: parent.scheduledDeliveryDate,
        confidence: 0.85,
        remainingDistance: 150,
        remainingDuration: 180,
        factors: ['traffic', 'weather'],
      };
    },
  },

  Organization: {
    stats: async (parent: any) => {
      const [
        totalShipments,
        activeShipments,
        totalDrivers,
        availableDrivers,
        totalVehicles,
        activeVehicles,
      ] = await Promise.all([
        prisma.shipment.count({ where: { organizationId: parent.id } }),
        prisma.shipment.count({
          where: {
            organizationId: parent.id,
            status: { in: ['DISPATCHED', 'IN_TRANSIT'] },
          },
        }),
        prisma.driver.count({ where: { organizationId: parent.id } }),
        prisma.driver.count({
          where: { organizationId: parent.id, status: 'AVAILABLE' },
        }),
        prisma.vehicle.count({ where: { organizationId: parent.id } }),
        prisma.vehicle.count({
          where: { organizationId: parent.id, status: 'ACTIVE' },
        }),
      ]);

      return {
        totalShipments,
        activeShipments,
        totalDrivers,
        availableDrivers,
        totalVehicles,
        activeVehicles,
        totalRevenue: 0,
        outstandingInvoices: 0,
        onTimeDeliveryRate: 95,
        averageTransitTime: 24,
      };
    },
  },
};
