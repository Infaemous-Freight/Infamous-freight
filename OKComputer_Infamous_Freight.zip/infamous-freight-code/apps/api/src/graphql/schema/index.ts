import { gql } from 'apollo-server-express';

export const typeDefs = gql`
  scalar DateTime
  scalar JSON

  enum UserRole {
    ADMIN
    MANAGER
    DISPATCHER
    DRIVER
    ACCOUNTANT
    SHIPPER
  }

  enum ShipmentStatus {
    PENDING
    DISPATCHED
    AT_PICKUP
    PICKED_UP
    IN_TRANSIT
    AT_DROPOFF
    DELIVERED
    CANCELLED
  }

  enum DriverStatus {
    AVAILABLE
    ON_DUTY
    OFF_DUTY
    IN_TRANSIT
    SLEEPER_BERTH
  }

  enum VehicleStatus {
    ACTIVE
    INACTIVE
    MAINTENANCE
    RETIRED
  }

  enum InvoiceStatus {
    DRAFT
    SENT
    VIEWED
    PARTIAL
    PAID
    OVERDUE
    CANCELLED
  }

  type Organization {
    id: ID!
    name: String!
    email: String!
    phone: String
    address: String
    city: String
    state: String
    zip: String
    country: String!
    timezone: String!
    currency: String!
    status: String!
    plan: String!
    accountCredit: Float!
    createdAt: DateTime!
    updatedAt: DateTime!
    users: [User!]!
    shipments: [Shipment!]!
    drivers: [Driver!]!
    vehicles: [Vehicle!]!
    invoices: [Invoice!]!
    stats: OrganizationStats!
  }

  type OrganizationStats {
    totalShipments: Int!
    activeShipments: Int!
    totalDrivers: Int!
    availableDrivers: Int!
    totalVehicles: Int!
    activeVehicles: Int!
    totalRevenue: Float!
    outstandingInvoices: Float!
    onTimeDeliveryRate: Float!
    averageTransitTime: Float!
  }

  type User {
    id: ID!
    email: String!
    firstName: String!
    lastName: String!
    fullName: String!
    role: UserRole!
    status: String!
    phone: String
    emailVerified: Boolean!
    lastLoginAt: DateTime
    organization: Organization!
    organizationId: ID!
    createdAt: DateTime!
    updatedAt: DateTime!
    driver: Driver
    notifications: [Notification!]!
    notificationCount: Int!
  }

  type Driver {
    id: ID!
    firstName: String!
    lastName: String!
    fullName: String!
    email: String!
    phone: String
    licenseNumber: String!
    licenseState: String!
    licenseExpiration: DateTime!
    licenseClass: String
    medicalExpiration: DateTime
    status: DriverStatus!
    hireDate: DateTime
    terminationDate: DateTime
    emergencyContactName: String
    emergencyContactPhone: String
    address: String
    city: String
    state: String
    zip: String
    dateOfBirth: DateTime
    rating: Float
    currentHosStatus: String
    user: User
    userId: ID
    organization: Organization!
    organizationId: ID!
    vehicles: [Vehicle!]!
    shipments: [Shipment!]!
    hosLogs: [HosLog!]!
    hosSummary: HosSummary!
    performance: DriverPerformance!
    createdAt: DateTime!
    updatedAt: DateTime!
  }

  type HosLog {
    id: ID!
    driver: Driver!
    driverId: ID!
    date: DateTime!
    dutyStatus: String!
    hours: Float!
    startTime: DateTime
    endTime: DateTime
    location: String
    remarks: String
    createdAt: DateTime!
  }

  type HosSummary {
    dailyDrivingHours: Float!
    dailyDutyHours: Float!
    weeklyHours: Float!
    remainingDrivingHours: Float!
    remainingDutyHours: Float!
    lastRestBreak: DateTime
    violations: [HosViolation!]!
  }

  type HosViolation {
    type: String!
    description: String!
    severity: String!
    timestamp: DateTime!
  }

  type DriverPerformance {
    totalShipments: Int!
    onTimeDeliveries: Int!
    onTimeRate: Float!
    totalMiles: Float!
    averageMilesPerDay: Float!
    fuelEfficiency: Float!
    safetyScore: Float!
    customerRating: Float!
  }

  type Vehicle {
    id: ID!
    unitNumber: String!
    type: String!
    make: String!
    model: String!
    year: Int!
    vin: String!
    licensePlate: String!
    licensePlateState: String!
    status: VehicleStatus!
    gvw: Float
    fuelType: String
    color: String
    currentMileage: Float
    registrationExpiration: DateTime
    insuranceExpiration: DateTime
    iftaStatus: Boolean!
    eldDeviceId: String
    gpsDeviceId: String
    notes: String
    organization: Organization!
    organizationId: ID!
    drivers: [Driver!]!
    shipments: [Shipment!]!
    maintenanceRecords: [MaintenanceRecord!]!
    utilization: Float!
    healthScore: Float!
    predictedMaintenance: [PredictedMaintenance!]!
    createdAt: DateTime!
    updatedAt: DateTime!
  }

  type MaintenanceRecord {
    id: ID!
    vehicle: Vehicle!
    vehicleId: ID!
    date: DateTime!
    type: String!
    description: String!
    cost: Float
    mileage: Float
    vendor: String
    invoiceNumber: String
    notes: String
    createdAt: DateTime!
  }

  type PredictedMaintenance {
    component: String!
    probability: Float!
    estimatedDate: DateTime!
    estimatedMileage: Float!
    recommendedAction: String!
    urgency: String!
  }

  type Shipment {
    id: ID!
    referenceNumber: String!
    customerName: String!
    customerEmail: String
    customerPhone: String
    customerAddress: String
    customerCity: String
    customerState: String
    customerZip: String
    status: ShipmentStatus!
    equipmentType: String!
    weight: Float
    length: Float
    width: Float
    height: Float
    commodity: String
    hazmat: Boolean!
    hazmatClass: String
    temperature: Float
    rate: Float
    rateType: String!
    distance: Float
    totalMiles: Float
    estimatedFuelCost: Float
    actualFuelCost: Float
    origin: String!
    originAddress: String
    originCity: String!
    originState: String!
    originZip: String
    originLatitude: Float
    originLongitude: Float
    destination: String!
    destinationAddress: String
    destinationCity: String!
    destinationState: String!
    destinationZip: String
    destinationLatitude: Float
    destinationLongitude: Float
    scheduledPickupDate: DateTime
    scheduledDeliveryDate: DateTime
    actualPickupDate: DateTime
    actualDeliveryDate: DateTime
    driver: Driver
    driverId: ID
    vehicle: Vehicle
    vehicleId: ID
    organization: Organization!
    organizationId: ID!
    stops: [Stop!]!
    trackingEvents: [TrackingEvent!]!
    currentLocation: CurrentLocation
    eta: ETA
    invoice: Invoice
    documents: [Document!]!
    notes: String
    aiRecommendations: [AIRecommendation!]!
    createdAt: DateTime!
    updatedAt: DateTime!
  }

  type Stop {
    id: ID!
    shipment: Shipment!
    shipmentId: ID!
    sequence: Int!
    type: String!
    name: String
    address: String
    city: String!
    state: String!
    zip: String
    latitude: Float!
    longitude: Float!
    scheduledArrival: DateTime
    scheduledDeparture: DateTime
    actualArrival: DateTime
    actualDeparture: DateTime
    notes: String
    createdAt: DateTime!
    updatedAt: DateTime!
  }

  type TrackingEvent {
    id: ID!
    shipment: Shipment!
    shipmentId: ID!
    latitude: Float!
    longitude: Float!
    speed: Float
    heading: Float
    odometer: Float
    ignitionStatus: Boolean
    engineHours: Float
    batteryVoltage: Float
    locationName: String
    notes: String
    source: String
    recordedAt: DateTime!
    createdAt: DateTime!
  }

  type CurrentLocation {
    latitude: Float!
    longitude: Float!
    speed: Float
    heading: Float
    timestamp: DateTime!
  }

  type ETA {
    estimatedArrival: DateTime!
    confidence: Float!
    remainingDistance: Float!
    remainingDuration: Float!
    factors: [String!]!
  }

  type Invoice {
    id: ID!
    invoiceNumber: String!
    shipment: Shipment!
    shipmentId: ID!
    organization: Organization!
    organizationId: ID!
    customerName: String!
    customerEmail: String
    invoiceDate: DateTime!
    dueDate: DateTime!
    status: InvoiceStatus!
    lineItems: [InvoiceLineItem!]!
    subtotal: Float!
    taxRate: Float!
    taxAmount: Float!
    totalAmount: Float!
    amountPaid: Float!
    balanceDue: Float!
    notes: String
    terms: String
    sentAt: DateTime
    paidAt: DateTime
    payments: [Payment!]!
    factoring: Factoring
    isFactored: Boolean!
    createdAt: DateTime!
    updatedAt: DateTime!
  }

  type InvoiceLineItem {
    id: ID!
    description: String!
    quantity: Float!
    rate: Float!
    amount: Float!
  }

  type Payment {
    id: ID!
    invoice: Invoice!
    invoiceId: ID!
    amount: Float!
    method: String!
    date: DateTime!
    reference: String
    notes: String
    createdAt: DateTime!
  }

  type Factoring {
    id: ID!
    invoice: Invoice!
    invoiceId: ID!
    organization: Organization!
    organizationId: ID!
    advanceRate: Float!
    feeRate: Float!
    advanceAmount: Float!
    feeAmount: Float!
    reserveAmount: Float!
    status: String!
    partnerReference: String
    partnerStatus: String
    applicationDate: DateTime!
    reviewedAt: DateTime
    fundedAt: DateTime
    transferId: String
    createdAt: DateTime!
    updatedAt: DateTime!
  }

  type Document {
    id: ID!
    shipment: Shipment!
    shipmentId: ID!
    type: String!
    name: String!
    url: String!
    mimeType: String!
    size: Int!
    extractedData: JSON
    createdAt: DateTime!
  }

  type AIRecommendation {
    type: String!
    title: String!
    description: String!
    confidence: Float!
    action: String
    metadata: JSON
  }

  type Notification {
    id: ID!
    user: User!
    userId: ID!
    organization: Organization!
    organizationId: ID!
    type: String!
    title: String!
    message: String!
    read: Boolean!
    entityType: String
    entityId: ID
    createdAt: DateTime!
  }

  type DashboardStats {
    activeShipments: Int!
    availableDrivers: Int!
    activeVehicles: Int!
    pendingInvoices: Int!
    todayDeliveries: Int!
    revenueToday: Float!
    revenueThisMonth: Float!
    revenueGrowth: Float!
    onTimeDeliveryRate: Float!
    averageTransitTime: Float!
    costPerMile: Float!
    revenuePerMile: Float!
    driverUtilization: Float!
    fuelEfficiency: Float!
  }

  type KPIData {
    onTimeDelivery: Float!
    averageTransitTime: Float!
    costPerMile: Float!
    revenuePerMile: Float!
    driverUtilization: Float!
    fuelEfficiency: Float!
  }

  type LoadRecommendation {
    shipment: Shipment!
    score: Float!
    reasons: [String!]!
    estimatedProfit: Float!
    distanceToPickup: Float!
  }

  type RouteOptimization {
    optimizedStops: [Stop!]!
    totalDistance: Float!
    estimatedDuration: Float!
    fuelCost: Float!
    savings: Float!
  }

  type ChurnRisk {
    organizationId: ID!
    riskScore: Float!
    riskLevel: String!
    factors: [String!]!
    recommendedActions: [String!]!
  }

  type FraudAlert {
    id: ID!
    type: String!
    severity: String!
    description: String!
    entityType: String!
    entityId: ID!
    confidence: Float!
    status: String!
    createdAt: DateTime!
  }

  type DemandForecast {
    region: String!
    date: DateTime!
    predictedLoads: Int!
    confidence: Float!
    factors: [String!]!
  }

  type DynamicPrice {
    lane: String!
    baseRate: Float!
    adjustedRate: Float!
    adjustmentFactor: Float!
    marketConditions: [String!]!
    validUntil: DateTime!
  }

  type Query {
    # Organization
    me: User!
    myOrganization: Organization!
    organization(id: ID!): Organization
    organizations: [Organization!]!

    # Users
    user(id: ID!): User
    users(role: UserRole, status: String): [User!]!

    # Drivers
    driver(id: ID!): Driver
    drivers(status: DriverStatus, available: Boolean): [Driver!]!
    driverPerformance(id: ID!): DriverPerformance!

    # Vehicles
    vehicle(id: ID!): Vehicle
    vehicles(status: VehicleStatus): [Vehicle!]!
    vehicleHealth(id: ID!): [PredictedMaintenance!]!

    # Shipments
    shipment(id: ID!): Shipment
    shipments(
      status: ShipmentStatus
      driverId: ID
      vehicleId: ID
      startDate: DateTime
      endDate: DateTime
      limit: Int
      offset: Int
    ): [Shipment!]!
    shipmentCount(status: ShipmentStatus): Int!
    trackingHistory(shipmentId: ID!): [TrackingEvent!]!

    # Invoices
    invoice(id: ID!): Invoice
    invoices(status: InvoiceStatus, overdue: Boolean): [Invoice!]!
    invoiceAging: JSON!
    revenueReport(startDate: DateTime!, endDate: DateTime!): JSON!

    # Analytics
    dashboardStats: DashboardStats!
    kpis: KPIData!
    executiveSummary: JSON!

    # AI
    loadRecommendations(driverId: ID, limit: Int): [LoadRecommendation!]!
    routeOptimization(shipmentId: ID!): RouteOptimization!

    # Predictions
    churnRisks: [ChurnRisk!]!
    fraudAlerts: [FraudAlert!]!
    demandForecast(region: String!, days: Int): [DemandForecast!]!
    dynamicPrice(origin: String!, destination: String!, equipmentType: String): DynamicPrice!

    # Notifications
    notifications(unreadOnly: Boolean): [Notification!]!
    notificationCount: Int!
  }

  type Mutation {
    # Auth
    login(email: String!, password: String!): AuthPayload!
    logout: Boolean!
    refreshToken: AuthPayload!

    # Users
    createUser(input: CreateUserInput!): User!
    updateUser(id: ID!, input: UpdateUserInput!): User!
    deleteUser(id: ID!): Boolean!

    # Drivers
    createDriver(input: CreateDriverInput!): Driver!
    updateDriver(id: ID!, input: UpdateDriverInput!): Driver!
    deleteDriver(id: ID!): Boolean!
    assignDriverToVehicle(driverId: ID!, vehicleId: ID!): Driver!
    logHos(driverId: ID!, input: HosLogInput!): HosLog!

    # Vehicles
    createVehicle(input: CreateVehicleInput!): Vehicle!
    updateVehicle(id: ID!, input: UpdateVehicleInput!): Vehicle!
    deleteVehicle(id: ID!): Boolean!
    recordMaintenance(vehicleId: ID!, input: MaintenanceInput!): MaintenanceRecord!

    # Shipments
    createShipment(input: CreateShipmentInput!): Shipment!
    updateShipment(id: ID!, input: UpdateShipmentInput!): Shipment!
    deleteShipment(id: ID!): Boolean!
    assignShipment(id: ID!, driverId: ID, vehicleId: ID): Shipment!
    updateShipmentStatus(id: ID!, status: ShipmentStatus!, notes: String): Shipment!
    addTrackingEvent(shipmentId: ID!, input: TrackingEventInput!): TrackingEvent!

    # Invoices
    createInvoice(shipmentId: ID!): Invoice!
    sendInvoice(id: ID!): Invoice!
    recordPayment(invoiceId: ID!, input: PaymentInput!): Payment!
    voidInvoice(id: ID!): Invoice!

    # Factoring
    applyForFactoring(invoiceId: ID!, advanceRate: Float, feeRate: Float): Factoring!

    # Notifications
    markNotificationRead(id: ID!): Notification!
    markAllNotificationsRead: Boolean!
    deleteNotification(id: ID!): Boolean!

    # AI
    processNaturalLanguageCommand(command: String!): AICommandResult!
    extractDocument(documentUrl: String!, type: String!): JSON!
  }

  type Subscription {
    # Real-time updates
    shipmentUpdated(organizationId: ID): Shipment!
    trackingUpdate(shipmentId: ID): TrackingEvent!
    driverLocationUpdated(driverId: ID): CurrentLocation!
    notificationReceived: Notification!

    # Alerts
    hosViolation: HosViolation!
    fraudAlert: FraudAlert!

    # Organization events
    organizationStatsUpdated(organizationId: ID!): OrganizationStats!
  }

  type AuthPayload {
    user: User!
    accessToken: String!
    refreshToken: String!
  }

  type AICommandResult {
    success: Boolean!
    action: String!
    message: String!
    data: JSON
  }

  # Input Types
  input CreateUserInput {
    email: String!
    password: String!
    firstName: String!
    lastName: String!
    role: UserRole!
    phone: String
  }

  input UpdateUserInput {
    email: String
    firstName: String
    lastName: String
    role: UserRole
    phone: String
    status: String
  }

  input CreateDriverInput {
    firstName: String!
    lastName: String!
    email: String!
    phone: String
    licenseNumber: String!
    licenseState: String!
    licenseExpiration: DateTime!
    licenseClass: String
    hireDate: DateTime
  }

  input UpdateDriverInput {
    firstName: String
    lastName: String
    email: String
    phone: String
    licenseNumber: String
    licenseState: String
    licenseExpiration: DateTime
    status: DriverStatus
  }

  input HosLogInput {
    date: DateTime!
    dutyStatus: String!
    hours: Float!
    startTime: DateTime
    endTime: DateTime
    location: String
    remarks: String
  }

  input CreateVehicleInput {
    unitNumber: String!
    type: String!
    make: String!
    model: String!
    year: Int!
    vin: String!
    licensePlate: String!
    licensePlateState: String!
    gvw: Float
    fuelType: String
    color: String
    currentMileage: Float
  }

  input UpdateVehicleInput {
    unitNumber: String
    type: String
    make: String
    model: String
    year: Int
    status: VehicleStatus
    currentMileage: Float
  }

  input MaintenanceInput {
    date: DateTime!
    type: String!
    description: String!
    cost: Float
    mileage: Float
    vendor: String
    invoiceNumber: String
    notes: String
  }

  input CreateShipmentInput {
    customerName: String!
    customerEmail: String
    customerPhone: String
    equipmentType: String!
    weight: Float
    length: Float
    width: Float
    height: Float
    commodity: String
    hazmat: Boolean
    rate: Float
    rateType: String
    originCity: String!
    originState: String!
    originZip: String
    destinationCity: String!
    destinationState: String!
    destinationZip: String
    scheduledPickupDate: DateTime
    scheduledDeliveryDate: DateTime
    notes: String
  }

  input UpdateShipmentInput {
    customerName: String
    customerEmail: String
    customerPhone: String
    equipmentType: String
    weight: Float
    rate: Float
    scheduledPickupDate: DateTime
    scheduledDeliveryDate: DateTime
    notes: String
  }

  input TrackingEventInput {
    latitude: Float!
    longitude: Float!
    speed: Float
    heading: Float
    odometer: Float
    ignitionStatus: Boolean
    locationName: String
    notes: String
  }

  input PaymentInput {
    amount: Float!
    method: String!
    date: DateTime!
    reference: String
    notes: String
  }
`;
