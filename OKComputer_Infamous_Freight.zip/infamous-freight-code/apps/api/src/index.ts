import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';

import { errorHandler } from './middleware/errorHandler';
import { requestLogger } from './middleware/requestLogger';
import { rateLimiter } from './middleware/rateLimiter';

import authRoutes from './routes/auth';
import userRoutes from './routes/users';
import shipmentRoutes from './routes/shipments';
import driverRoutes from './routes/drivers';
import vehicleRoutes from './routes/vehicles';
import invoiceRoutes from './routes/invoices';
import trackingRoutes from './routes/tracking';
import aiRoutes from './routes/ai';
import analyticsRoutes from './routes/analytics';
import healthRoutes from './routes/health';
import webhookRoutes from './routes/webhooks';
import referralRoutes from './routes/referrals';
import factoringRoutes from './routes/factoring';
import insuranceRoutes from './routes/insurance';

import {
  authenticateConnection,
  handleMessage,
  handleDisconnect,
} from './websocket/handlers';
import { logger } from './utils/logger';

dotenv.config();

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

const PORT = process.env.API_PORT || 4000;

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));

app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? ['https://infamousfreight.com', 'https://app.infamousfreight.com']
    : ['http://localhost:3000', 'http://localhost:5173'],
  credentials: true,
}));

// Logging
app.use(morgan('combined', { stream: { write: (msg) => logger.info(msg.trim()) } }));
app.use(requestLogger);

// Rate limiting
app.use(rateLimiter);

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Routes
app.use('/api/health', healthRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/shipments', shipmentRoutes);
app.use('/api/drivers', driverRoutes);
app.use('/api/vehicles', vehicleRoutes);
app.use('/api/invoices', invoiceRoutes);
app.use('/api/tracking', trackingRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/webhooks', webhookRoutes);
app.use('/api/referrals', referralRoutes);
app.use('/api/factoring', factoringRoutes);
app.use('/api/insurance', insuranceRoutes);

// API Documentation endpoint
app.get('/api/docs', (req, res) => {
  res.json({
    name: 'Infamous Freight API',
    version: '2.2.0',
    documentation: 'https://docs.infamousfreight.com',
    endpoints: {
      auth: '/api/auth',
      users: '/api/users',
      shipments: '/api/shipments',
      drivers: '/api/drivers',
      vehicles: '/api/vehicles',
      invoices: '/api/invoices',
      tracking: '/api/tracking',
      ai: '/api/ai',
      analytics: '/api/analytics',
      referrals: '/api/referrals',
      factoring: '/api/factoring',
      insurance: '/api/insurance',
    },
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Not Found',
    message: `Route ${req.method} ${req.path} not found`,
  });
});

// Error handler
app.use(errorHandler);

// WebSocket setup
wss.on('connection', (ws, req) => {
  logger.info('New WebSocket connection');

  // Handle authentication
  const url = new URL(req.url || '', `http://${req.headers.host}`);
  const token = url.searchParams.get('token');

  if (token) {
    authenticateConnection(ws, token);
  } else {
    ws.send(JSON.stringify({ type: 'error', message: 'Authentication required' }));
    ws.close();
    return;
  }

  ws.on('message', (message: string) => {
    handleMessage(ws, message.toString());
  });

  ws.on('close', () => {
    handleDisconnect(ws);
  });

  ws.on('error', (error) => {
    logger.error({ error }, 'WebSocket error');
  });
});

// Start server
server.listen(PORT, () => {
  logger.info(`🚀 Infamous Freight API running on port ${PORT}`);
  logger.info(`📚 API Documentation: http://localhost:${PORT}/api/docs`);
  logger.info(`💚 Health Check: http://localhost:${PORT}/api/health`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully');
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  logger.info('SIGINT received, shutting down gracefully');
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});

export default app;
