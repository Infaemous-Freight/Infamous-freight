import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';

export interface ApiError extends Error {
  statusCode?: number;
  code?: string;
  details?: Record<string, unknown>;
}

export const errorHandler = (
  err: ApiError,
  req: Request,
  res: Response,
  _next: NextFunction
) => {
  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal Server Error';
  const code = err.code || 'INTERNAL_ERROR';

  // Log error
  logger.error({
    error: err.message,
    stack: err.stack,
    code,
    statusCode,
    path: req.path,
    method: req.method,
    userId: (req as any).user?.id,
  });

  // Don't leak error details in production
  const isDevelopment = process.env.NODE_ENV === 'development';

  res.status(statusCode).json({
    error: code,
    message: isDevelopment ? message : 'An error occurred',
    ...(isDevelopment && { stack: err.stack }),
    ...(err.details && { details: err.details }),
  });
};

export const createError = (
  message: string,
  statusCode: number = 500,
  code?: string,
  details?: Record<string, unknown>
): ApiError => {
  const error = new Error(message) as ApiError;
  error.statusCode = statusCode;
  error.code = code;
  error.details = details;
  return error;
};

export const badRequest = (message: string, details?: Record<string, unknown>) =>
  createError(message, 400, 'BAD_REQUEST', details);

export const unauthorized = (message: string = 'Unauthorized') =>
  createError(message, 401, 'UNAUTHORIZED');

export const forbidden = (message: string = 'Forbidden') =>
  createError(message, 403, 'FORBIDDEN');

export const notFound = (message: string = 'Not Found') =>
  createError(message, 404, 'NOT_FOUND');

export const conflict = (message: string) =>
  createError(message, 409, 'CONFLICT');

export const validationError = (message: string, details: Record<string, unknown>) =>
  createError(message, 422, 'VALIDATION_ERROR', details);
