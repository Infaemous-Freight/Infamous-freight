import rateLimit from 'express-rate-limit';
import Redis from 'ioredis';

const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

// General API rate limiter
export const rateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100, // 100 requests per minute per IP
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip || 'unknown',
  handler: (req, res) => {
    res.status(429).json({
      error: 'TOO_MANY_REQUESTS',
      message: 'Too many requests, please try again later',
      retryAfter: Math.ceil(60), // seconds
    });
  },
});

// Stricter rate limiter for authentication endpoints
export const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 attempts per 15 minutes
  skipSuccessfulRequests: true,
  keyGenerator: (req) => req.ip || 'unknown',
  handler: (req, res) => {
    res.status(429).json({
      error: 'TOO_MANY_ATTEMPTS',
      message: 'Too many login attempts. Please try again in 15 minutes.',
      retryAfter: Math.ceil(15 * 60),
    });
  },
});

// AI endpoint rate limiter (more expensive)
export const aiRateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 20, // 20 AI requests per minute
  keyGenerator: (req) => (req as any).user?.id || req.ip || 'unknown',
  handler: (req, res) => {
    res.status(429).json({
      error: 'AI_RATE_LIMIT',
      message: 'AI request limit reached. Please try again later.',
      retryAfter: Math.ceil(60),
    });
  },
});

// Custom rate limiter based on user tier
export const tieredRateLimiter = (tierLimits: Record<string, number>) => {
  return rateLimit({
    windowMs: 60 * 1000,
    max: (req) => {
      const userTier = (req as any).user?.tier || 'FREE';
      return tierLimits[userTier] || tierLimits['FREE'];
    },
    keyGenerator: (req) => (req as any).user?.id || req.ip || 'unknown',
  });
};
