import { PrismaClient } from '@prisma/client';
import { logger } from '../utils/logger';

const prisma = new PrismaClient();

export interface LoadRecommendation {
  shipment: any;
  score: number;
  reasons: string[];
  estimatedProfit: number;
  distanceToPickup: number;
}

export interface RouteOptimization {
  optimizedStops: any[];
  totalDistance: number;
  estimatedDuration: number;
  fuelCost: number;
  savings: number;
}

export interface ChurnRisk {
  organizationId: string;
  riskScore: number;
  riskLevel: string;
  factors: string[];
  recommendedActions: string[];
}

export interface FraudAlert {
  id: string;
  type: string;
  severity: string;
  description: string;
  entityType: string;
  entityId: string;
  confidence: number;
  status: string;
  createdAt: Date;
}

export interface DemandForecast {
  region: string;
  date: Date;
  predictedLoads: number;
  confidence: number;
  factors: string[];
}

export interface DynamicPrice {
  lane: string;
  baseRate: number;
  adjustedRate: number;
  adjustmentFactor: number;
  marketConditions: string[];
  validUntil: Date;
}

export interface PredictedMaintenance {
  component: string;
  probability: number;
  estimatedDate: Date;
  estimatedMileage: number;
  recommendedAction: string;
  urgency: string;
}

export class MLPredictionService {
  // Load recommendations based on driver preferences, location, and profitability
  static async getLoadRecommendations(
    organizationId: string,
    driverId?: string,
    limit: number = 5
  ): Promise<LoadRecommendation[]> {
    // Get available shipments
    const shipments = await prisma.shipment.findMany({
      where: {
        organizationId,
        status: 'PENDING',
        driverId: null,
      },
      include: {
        stops: true,
      },
      take: 50,
    });

    if (driverId) {
      const driver = await prisma.driver.findUnique({
        where: { id: driverId },
        include: { user: true },
      });

      if (!driver) return [];

      // Score each shipment for this driver
      const scoredShipments = await Promise.all(
        shipments.map(async (shipment) => {
          const score = await this.calculateLoadScore(shipment, driver);
          return {
            shipment,
            ...score,
          };
        })
      );

      return scoredShipments
        .sort((a, b) => b.score - a.score)
        .slice(0, limit);
    }

    // Return general recommendations
    return shipments
      .map((shipment) => ({
        shipment,
        score: 0.7,
        reasons: ['High rate', 'Good lane'],
        estimatedProfit: (shipment.rate || 0) * 0.25,
        distanceToPickup: 0,
      }))
      .slice(0, limit);
  }

  private static async calculateLoadScore(
    shipment: any,
    driver: any
  ): Promise<Omit<LoadRecommendation, 'shipment'>> {
    let score = 0.5;
    const reasons: string[] = [];

    // Rate factor (30%)
    const ratePerMile = shipment.rate && shipment.distance
      ? shipment.rate / shipment.distance
      : 0;
    if (ratePerMile > 2.5) {
      score += 0.15;
      reasons.push('Above-market rate');
    } else if (ratePerMile > 2.0) {
      score += 0.1;
      reasons.push('Competitive rate');
    }

    // Distance factor (20%)
    if (shipment.distance && shipment.distance < 500) {
      score += 0.1;
      reasons.push('Short haul - quick turnaround');
    }

    // Driver preference match (25%)
    // In production, would use driver's historical preferences
    score += 0.125;

    // Home time factor (15%)
    // Check if delivery is near driver's home
    score += 0.075;

    // Equipment match (10%)
    score += 0.05;

    const estimatedProfit = shipment.rate
      ? shipment.rate * 0.25 - (shipment.estimatedFuelCost || 0)
      : 0;

    return {
      score: Math.min(score, 1),
      reasons,
      estimatedProfit,
      distanceToPickup: Math.random() * 50, // Placeholder
    };
  }

  // Route optimization using nearest neighbor + 2-opt improvement
  static async optimizeRoute(shipment: any): Promise<RouteOptimization> {
    const stops = [...shipment.stops];
    if (stops.length < 2) {
      return {
        optimizedStops: stops,
        totalDistance: shipment.distance || 0,
        estimatedDuration: 480,
        fuelCost: shipment.estimatedFuelCost || 0,
        savings: 0,
      };
    }

    // Nearest neighbor algorithm
    const optimized = this.nearestNeighbor(stops);

    // 2-opt improvement
    const improved = this.twoOpt(optimized);

    const totalDistance = this.calculateTotalDistance(improved);
    const originalDistance = shipment.distance || totalDistance;
    const savings = originalDistance - totalDistance;

    return {
      optimizedStops: improved,
      totalDistance,
      estimatedDuration: (totalDistance / 55) * 60, // 55 mph average
      fuelCost: totalDistance * 0.45, // $0.45 per mile
      savings: Math.max(0, savings),
    };
  }

  private static nearestNeighbor(stops: any[]): any[] {
    if (stops.length === 0) return [];

    const unvisited = [...stops];
    const route: any[] = [];
    let current = unvisited.shift()!;
    route.push(current);

    while (unvisited.length > 0) {
      let nearest = unvisited[0];
      let minDistance = this.haversine(
        current.latitude,
        current.longitude,
        nearest.latitude,
        nearest.longitude
      );

      for (const stop of unvisited.slice(1)) {
        const distance = this.haversine(
          current.latitude,
          current.longitude,
          stop.latitude,
          stop.longitude
        );
        if (distance < minDistance) {
          minDistance = distance;
          nearest = stop;
        }
      }

      route.push(nearest);
      current = nearest;
      unvisited.splice(unvisited.indexOf(nearest), 1);
    }

    return route;
  }

  private static twoOpt(route: any[]): any[] {
    let improved = true;
    let best = [...route];

    while (improved) {
      improved = false;
      for (let i = 1; i < route.length - 2; i++) {
        for (let j = i + 1; j < route.length; j++) {
          const newRoute = this.twoOptSwap(best, i, j);
          if (this.calculateTotalDistance(newRoute) < this.calculateTotalDistance(best)) {
            best = newRoute;
            improved = true;
          }
        }
      }
    }

    return best;
  }

  private static twoOptSwap(route: any[], i: number, j: number): any[] {
    const newRoute = route.slice(0, i);
    const reversed = route.slice(i, j + 1).reverse();
    newRoute.push(...reversed);
    newRoute.push(...route.slice(j + 1));
    return newRoute;
  }

  private static calculateTotalDistance(stops: any[]): number {
    let total = 0;
    for (let i = 0; i < stops.length - 1; i++) {
      total += this.haversine(
        stops[i].latitude,
        stops[i].longitude,
        stops[i + 1].latitude,
        stops[i + 1].longitude
      );
    }
    return total;
  }

  private static haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 3959; // Earth's radius in miles
    const dLat = this.toRadians(lat2 - lat1);
    const dLon = this.toRadians(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRadians(lat1)) *
        Math.cos(this.toRadians(lat2)) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private static toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }

  // Predictive maintenance using vehicle telematics
  static async predictMaintenance(vehicle: any): Promise<PredictedMaintenance[]> {
    const predictions: PredictedMaintenance[] = [];
    const mileage = vehicle.currentMileage || 0;

    // Engine oil (every 25,000 miles)
    const oilLife = 25000 - (mileage % 25000);
    if (oilLife < 5000) {
      predictions.push({
        component: 'Engine Oil',
        probability: oilLife < 1000 ? 0.95 : 0.7,
        estimatedDate: new Date(Date.now() + (oilLife / 500) * 24 * 60 * 60 * 1000),
        estimatedMileage: mileage + oilLife,
        recommendedAction: 'Schedule oil change',
        urgency: oilLife < 1000 ? 'HIGH' : 'MEDIUM',
      });
    }

    // Tires (every 100,000 miles)
    const tireLife = 100000 - (mileage % 100000);
    if (tireLife < 15000) {
      predictions.push({
        component: 'Tires',
        probability: tireLife < 5000 ? 0.9 : 0.6,
        estimatedDate: new Date(Date.now() + (tireLife / 500) * 24 * 60 * 60 * 1000),
        estimatedMileage: mileage + tireLife,
        recommendedAction: 'Inspect and replace tires',
        urgency: tireLife < 5000 ? 'HIGH' : 'LOW',
      });
    }

    // Brake pads (every 75,000 miles)
    const brakeLife = 75000 - (mileage % 75000);
    if (brakeLife < 10000) {
      predictions.push({
        component: 'Brake Pads',
        probability: brakeLife < 3000 ? 0.85 : 0.55,
        estimatedDate: new Date(Date.now() + (brakeLife / 500) * 24 * 60 * 60 * 1000),
        estimatedMileage: mileage + brakeLife,
        recommendedAction: 'Inspect brake system',
        urgency: brakeLife < 3000 ? 'HIGH' : 'MEDIUM',
      });
    }

    // Battery (every 4 years or 150,000 miles)
    const batteryLife = 150000 - (mileage % 150000);
    if (batteryLife < 20000) {
      predictions.push({
        component: 'Battery',
        probability: batteryLife < 5000 ? 0.8 : 0.5,
        estimatedDate: new Date(Date.now() + (batteryLife / 500) * 24 * 60 * 60 * 1000),
        estimatedMileage: mileage + batteryLife,
        recommendedAction: 'Test battery and replace if needed',
        urgency: 'LOW',
      });
    }

    return predictions.sort((a, b) => b.probability - a.probability);
  }

  // Churn prediction based on usage patterns
  static async predictChurnRisk(organizationId: string): Promise<ChurnRisk> {
    const org = await prisma.organization.findUnique({
      where: { id: organizationId },
      include: {
        users: true,
        shipments: {
          orderBy: { createdAt: 'desc' },
          take: 30,
        },
        invoices: {
          where: { status: 'OVERDUE' },
        },
      },
    });

    if (!org) {
      return {
        organizationId,
        riskScore: 0,
        riskLevel: 'UNKNOWN',
        factors: [],
        recommendedActions: [],
      };
    }

    let riskScore = 0;
    const factors: string[] = [];

    // Factor 1: Login frequency (25%)
    const activeUsers = org.users.filter(
      (u) => u.lastLoginAt && new Date(u.lastLoginAt) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    ).length;
    const loginRate = org.users.length > 0 ? activeUsers / org.users.length : 0;
    if (loginRate < 0.3) {
      riskScore += 0.25;
      factors.push('Low user engagement');
    }

    // Factor 2: Shipment volume trend (25%)
    const recentShipments = org.shipments.filter(
      (s) => s.createdAt > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
    ).length;
    if (recentShipments < 5) {
      riskScore += 0.25;
      factors.push('Declining shipment volume');
    }

    // Factor 3: Payment issues (20%)
    if (org.invoices.length > 2) {
      riskScore += 0.2;
      factors.push('Multiple overdue invoices');
    }

    // Factor 4: Support tickets (15%)
    // Would query support system in production
    riskScore += 0;

    // Factor 5: Feature adoption (15%)
    // Would check feature usage in production
    riskScore += 0;

    const riskLevel = riskScore > 0.7 ? 'HIGH' : riskScore > 0.4 ? 'MEDIUM' : 'LOW';

    const recommendedActions: string[] = [];
    if (riskScore > 0.5) {
      recommendedActions.push('Schedule executive business review');
      recommendedActions.push('Offer training session');
    }
    if (org.invoices.length > 0) {
      recommendedActions.push('Discuss payment plan options');
    }
    if (recentShipments < 5) {
      recommendedActions.push('Share success stories from similar carriers');
    }

    return {
      organizationId,
      riskScore: Math.min(riskScore, 1),
      riskLevel,
      factors,
      recommendedActions,
    };
  }

  static async getAllChurnRisks(): Promise<ChurnRisk[]> {
    const organizations = await prisma.organization.findMany({
      where: { status: 'ACTIVE' },
    });

    const risks = await Promise.all(
      organizations.map((org) => this.predictChurnRisk(org.id))
    );

    return risks.sort((a, b) => b.riskScore - a.riskScore);
  }

  // Fraud detection
  static async getFraudAlerts(organizationId: string): Promise<FraudAlert[]> {
    const alerts: FraudAlert[] = [];

    // Check for suspicious patterns
    const recentShipments = await prisma.shipment.findMany({
      where: {
        organizationId,
        createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
      },
    });

    // Pattern 1: Unusually high rates
    const avgRate =
      recentShipments.reduce((sum, s) => sum + (s.rate || 0), 0) /
      (recentShipments.length || 1);
    const suspiciousRates = recentShipments.filter(
      (s) => s.rate && s.rate > avgRate * 3
    );

    for (const shipment of suspiciousRates) {
      alerts.push({
        id: `RATE-${shipment.id}`,
        type: 'SUSPICIOUS_RATE',
        severity: 'MEDIUM',
        description: `Rate $${shipment.rate} is 3x above average`,
        entityType: 'SHIPMENT',
        entityId: shipment.id,
        confidence: 0.75,
        status: 'ACTIVE',
        createdAt: new Date(),
      });
    }

    // Pattern 2: Multiple shipments to same customer in short period
    const customerCounts: Record<string, number> = {};
    for (const shipment of recentShipments) {
      customerCounts[shipment.customerName] =
        (customerCounts[shipment.customerName] || 0) + 1;
    }

    for (const [customer, count] of Object.entries(customerCounts)) {
      if (count > 10) {
        alerts.push({
          id: `VOLUME-${customer}`,
          type: 'HIGH_VOLUME_CUSTOMER',
          severity: 'LOW',
          description: `${count} shipments to ${customer} in 24 hours`,
          entityType: 'CUSTOMER',
          entityId: customer,
          confidence: 0.6,
          status: 'ACTIVE',
          createdAt: new Date(),
        });
      }
    }

    return alerts;
  }

  // Demand forecasting
  static async forecastDemand(region: string, days: number): Promise<DemandForecast[]> {
    const forecasts: DemandForecast[] = [];
    const baseDemand = this.getBaseDemandForRegion(region);

    for (let i = 0; i < days; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);

      // Seasonal adjustment
      const month = date.getMonth();
      const seasonalFactor = this.getSeasonalFactor(month);

      // Day of week adjustment
      const dayOfWeek = date.getDay();
      const dowFactor = dayOfWeek === 5 || dayOfWeek === 6 ? 1.2 : 1.0; // Higher on Fri/Sat

      const predictedLoads = Math.round(baseDemand * seasonalFactor * dowFactor);

      forecasts.push({
        region,
        date,
        predictedLoads,
        confidence: 0.75 - i * 0.01, // Confidence decreases over time
        factors: [
          `Seasonal factor: ${seasonalFactor.toFixed(2)}`,
          `Day of week factor: ${dowFactor.toFixed(2)}`,
        ],
      });
    }

    return forecasts;
  }

  private static getBaseDemandForRegion(region: string): number {
    const baseDemands: Record<string, number> = {
      'Northeast': 150,
      'Southeast': 200,
      'Midwest': 180,
      'Southwest': 120,
      'West': 160,
      'Northwest': 100,
    };
    return baseDemands[region] || 150;
  }

  private static getSeasonalFactor(month: number): number {
    const factors = [0.9, 0.9, 1.0, 1.0, 1.05, 1.1, 1.1, 1.05, 1.0, 1.0, 1.1, 1.2];
    return factors[month];
  }

  // Dynamic pricing based on market conditions
  static async getDynamicPrice(
    origin: string,
    destination: string,
    equipmentType: string = 'DRY_VAN'
  ): Promise<DynamicPrice> {
    const lane = `${origin}-${destination}`;

    // Base rate by equipment type
    const baseRates: Record<string, number> = {
      'DRY_VAN': 2.25,
      'REEFER': 2.75,
      'FLATBED': 2.5,
      'STEP_DECK': 2.75,
    };

    const baseRate = baseRates[equipmentType] || 2.25;

    // Market demand factor (would come from external API in production)
    const demandFactor = 1 + (Math.random() * 0.4 - 0.2); // ±20%

    // Fuel cost factor
    const fuelFactor = 1.05; // 5% increase

    // Seasonal factor
    const month = new Date().getMonth();
    const seasonalFactor = this.getSeasonalFactor(month);

    const adjustmentFactor = demandFactor * fuelFactor * seasonalFactor;
    const adjustedRate = baseRate * adjustmentFactor;

    const marketConditions: string[] = [];
    if (demandFactor > 1.1) marketConditions.push('High demand');
    if (demandFactor < 0.9) marketConditions.push('Low demand');
    if (fuelFactor > 1) marketConditions.push('Elevated fuel costs');
    if (seasonalFactor > 1.05) marketConditions.push('Peak season');

    return {
      lane,
      baseRate,
      adjustedRate: Math.round(adjustedRate * 100) / 100,
      adjustmentFactor: Math.round(adjustmentFactor * 100) / 100,
      marketConditions,
      validUntil: new Date(Date.now() + 24 * 60 * 60 * 1000),
    };
  }
}
