import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

// Test database configuration
export const testPrisma = new PrismaClient({
  datasources: {
    db: {
      url: process.env.TEST_DATABASE_URL || 'postgresql://infamous:infamous123@localhost:5432/infamous_freight_test',
    },
  },
});

// Test user credentials
export const testUser = {
  email: 'test@example.com',
  password: 'testpassword123',
  firstName: 'Test',
  lastName: 'User',
};

// Create test organization and user
export async function createTestUser() {
  const hashedPassword = await bcrypt.hash(testUser.password, 10);

  const organization = await testPrisma.organization.create({
    data: {
      name: 'Test Organization',
      email: 'org@test.com',
      country: 'US',
      timezone: 'America/New_York',
      currency: 'USD',
      status: 'ACTIVE',
      plan: 'FREE',
    },
  });

  const user = await testPrisma.user.create({
    data: {
      email: testUser.email,
      password: hashedPassword,
      firstName: testUser.firstName,
      lastName: testUser.lastName,
      role: 'ADMIN',
      status: 'ACTIVE',
      emailVerified: true,
      organizationId: organization.id,
    },
  });

  return { user, organization };
}

// Cleanup test data
export async function cleanupTestData() {
  const tables = [
    'Payment',
    'Invoice',
    'TrackingEvent',
    'Stop',
    'Shipment',
    'MaintenanceRecord',
    'DriverVehicle',
    'HosLog',
    'Driver',
    'Vehicle',
    'WebhookDelivery',
    'Webhook',
    'ApiKey',
    'Session',
    'ActivityLog',
    'AiEvent',
    'User',
    'Organization',
  ];

  for (const table of tables) {
    await testPrisma.$executeRawUnsafe(`DELETE FROM "${table}" WHERE 1=1`);
  }
}

// Generate auth token for tests
export function generateAuthToken(userId: string, organizationId: string): string {
  const jwt = require('jsonwebtoken');
  return jwt.sign(
    { userId, organizationId, role: 'ADMIN' },
    process.env.JWT_SECRET || 'test-secret',
    { expiresIn: '1h' }
  );
}

// Global test setup
beforeAll(async () => {
  // Ensure test database exists
  await testPrisma.$connect();
});

// Global test teardown
afterAll(async () => {
  await cleanupTestData();
  await testPrisma.$disconnect();
});

// Clean up after each test
afterEach(async () => {
  await cleanupTestData();
});
