import { WebSocket } from 'ws';
import { PrismaClient, ShipmentStatus } from '@prisma/client';
import jwt from 'jsonwebtoken';
import { logger } from '../utils/logger';

const prisma = new PrismaClient();

// Connected clients store
interface ConnectedClient {
  ws: WebSocket;
  userId?: string;
  organizationId?: string;
  role?: string;
  subscriptions: Set<string>;
}

const clients = new Map<string, ConnectedClient>();

// Authenticate WebSocket connection
export async function authenticateConnection(
  ws: WebSocket,
  token: string
): Promise<boolean> {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;

    const client: ConnectedClient = {
      ws,
      userId: decoded.userId,
      organizationId: decoded.organizationId,
      role: decoded.role,
      subscriptions: new Set(),
    };

    clients.set(decoded.userId, client);

    // Send connection success
    ws.send(
      JSON.stringify({
        type: 'connection',
        status: 'connected',
        userId: decoded.userId,
      })
    );

    logger.info({ userId: decoded.userId }, 'WebSocket client authenticated');
    return true;
  } catch (error) {
    ws.send(
      JSON.stringify({
        type: 'error',
        message: 'Authentication failed',
      })
    );
    ws.close();
    return false;
  }
}

// Handle incoming messages
export function handleMessage(ws: WebSocket, message: string): void {
  try {
    const data = JSON.parse(message);
    const client = findClientByWs(ws);

    if (!client) {
      ws.send(
        JSON.stringify({
          type: 'error',
          message: 'Not authenticated',
        })
      );
      return;
    }

    switch (data.type) {
      case 'subscribe':
        handleSubscribe(client, data);
        break;

      case 'unsubscribe':
        handleUnsubscribe(client, data);
        break;

      case 'location_update':
        handleLocationUpdate(client, data);
        break;

      case 'status_update':
        handleStatusUpdate(client, data);
        break;

      case 'ping':
        ws.send(JSON.stringify({ type: 'pong', timestamp: Date.now() }));
        break;

      default:
        ws.send(
          JSON.stringify({
            type: 'error',
            message: `Unknown message type: ${data.type}`,
          })
        );
    }
  } catch (error) {
    logger.error({ error, message }, 'Error handling WebSocket message');
    ws.send(
      JSON.stringify({
        type: 'error',
        message: 'Invalid message format',
      })
    );
  }
}

// Handle client disconnection
export function handleDisconnect(ws: WebSocket): void {
  const client = findClientByWs(ws);
  if (client) {
    clients.delete(client.userId!);
    logger.info({ userId: client.userId }, 'WebSocket client disconnected');
  }
}

// Handle subscription requests
function handleSubscribe(client: ConnectedClient, data: any): void {
  const { channel, shipmentId } = data;

  switch (channel) {
    case 'shipments':
      // Subscribe to all organization shipments
      client.subscriptions.add('shipments:all');
      client.ws.send(
        JSON.stringify({
          type: 'subscribed',
          channel: 'shipments:all',
        })
      );
      break;

    case 'shipment':
      if (shipmentId) {
        client.subscriptions.add(`shipment:${shipmentId}`);
        client.ws.send(
          JSON.stringify({
            type: 'subscribed',
            channel: `shipment:${shipmentId}`,
          })
        );
      }
      break;

    case 'tracking':
      if (shipmentId) {
        client.subscriptions.add(`tracking:${shipmentId}`);
        client.ws.send(
          JSON.stringify({
            type: 'subscribed',
            channel: `tracking:${shipmentId}`,
          })
        );
      }
      break;

    case 'notifications':
      client.subscriptions.add('notifications');
      client.ws.send(
        JSON.stringify({
          type: 'subscribed',
          channel: 'notifications',
        })
      );
      break;

    default:
      client.ws.send(
        JSON.stringify({
          type: 'error',
          message: `Unknown channel: ${channel}`,
        })
      );
  }
}

// Handle unsubscription requests
function handleUnsubscribe(client: ConnectedClient, data: any): void {
  const { channel, shipmentId } = data;

  if (channel === 'shipment' && shipmentId) {
    client.subscriptions.delete(`shipment:${shipmentId}`);
  } else if (channel === 'tracking' && shipmentId) {
    client.subscriptions.delete(`tracking:${shipmentId}`);
  } else {
    client.subscriptions.delete(channel);
  }

  client.ws.send(
    JSON.stringify({
      type: 'unsubscribed',
      channel: channel === 'shipment' || channel === 'tracking' ? `${channel}:${shipmentId}` : channel,
    })
  );
}

// Handle location updates from drivers
async function handleLocationUpdate(client: ConnectedClient, data: any): Promise<void> {
  const { shipmentId, latitude, longitude, speed, heading } = data;

  // Verify driver is assigned to shipment
  const shipment = await prisma.shipment.findFirst({
    where: {
      id: shipmentId,
      organizationId: client.organizationId,
    },
    include: {
      driver: true,
    },
  });

  if (!shipment) {
    client.ws.send(
      JSON.stringify({
        type: 'error',
        message: 'Shipment not found',
      })
    );
    return;
  }

  // Check if user is the assigned driver or an admin/dispatcher
  const isAssignedDriver = shipment.driver?.userId === client.userId;
  const canUpdate = isAssignedDriver || ['ADMIN', 'MANAGER', 'DISPATCHER'].includes(client.role || '');

  if (!canUpdate) {
    client.ws.send(
      JSON.stringify({
        type: 'error',
        message: 'Not authorized to update this shipment',
      })
    );
    return;
  }

  // Create tracking event
  const trackingEvent = await prisma.trackingEvent.create({
    data: {
      shipmentId,
      latitude,
      longitude,
      speed,
      heading,
      recordedAt: new Date(),
    },
  });

  // Update shipment location
  await prisma.shipment.update({
    where: { id: shipmentId },
    data: {
      currentLatitude: latitude,
      currentLongitude: longitude,
    },
  });

  // Broadcast to subscribers
  broadcastToShipment(shipmentId, {
    type: 'location_update',
    shipmentId,
    data: {
      latitude,
      longitude,
      speed,
      heading,
      timestamp: trackingEvent.recordedAt,
    },
  });
}

// Handle status updates
async function handleStatusUpdate(client: ConnectedClient, data: any): Promise<void> {
  const { shipmentId, status, notes } = data;

  // Verify user can update shipment
  const shipment = await prisma.shipment.findFirst({
    where: {
      id: shipmentId,
      organizationId: client.organizationId,
    },
    include: {
      driver: true,
    },
  });

  if (!shipment) {
    client.ws.send(
      JSON.stringify({
        type: 'error',
        message: 'Shipment not found',
      })
    );
    return;
  }

  const isAssignedDriver = shipment.driver?.userId === client.userId;
  const canUpdate = isAssignedDriver || ['ADMIN', 'MANAGER', 'DISPATCHER'].includes(client.role || '');

  if (!canUpdate) {
    client.ws.send(
      JSON.stringify({
        type: 'error',
        message: 'Not authorized to update this shipment',
      })
    );
    return;
  }

  // Update shipment status
  const updateData: any = { status };

  if (status === ShipmentStatus.IN_TRANSIT && !shipment.actualPickupDate) {
    updateData.actualPickupDate = new Date();
  }

  if (status === ShipmentStatus.DELIVERED && !shipment.actualDeliveryDate) {
    updateData.actualDeliveryDate = new Date();
  }

  const updatedShipment = await prisma.shipment.update({
    where: { id: shipmentId },
    data: updateData,
  });

  // Create tracking event for status change
  await prisma.trackingEvent.create({
    data: {
      shipmentId,
      latitude: shipment.currentLatitude || 0,
      longitude: shipment.currentLongitude || 0,
      notes: `Status changed to ${status}${notes ? `: ${notes}` : ''}`,
      recordedAt: new Date(),
    },
  });

  // Broadcast to subscribers
  broadcastToShipment(shipmentId, {
    type: 'status_update',
    shipmentId,
    data: {
      status: updatedShipment.status,
      previousStatus: shipment.status,
      timestamp: new Date().toISOString(),
      notes,
    },
  });

  // Send notification to organization users
  broadcastToOrganization(client.organizationId!, {
    type: 'notification',
    data: {
      title: 'Shipment Status Update',
      message: `Shipment ${shipment.referenceNumber} is now ${status}`,
      shipmentId,
      timestamp: new Date().toISOString(),
    },
  });
}

// Broadcast message to all subscribers of a shipment
export function broadcastToShipment(shipmentId: string, message: any): void {
  const channel = `shipment:${shipmentId}`;
  const trackingChannel = `tracking:${shipmentId}`;

  clients.forEach((client) => {
    if (
      client.subscriptions.has(channel) ||
      client.subscriptions.has(trackingChannel) ||
      client.subscriptions.has('shipments:all')
    ) {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify(message));
      }
    }
  });
}

// Broadcast message to all users in an organization
export function broadcastToOrganization(organizationId: string, message: any): void {
  clients.forEach((client) => {
    if (client.organizationId === organizationId) {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify(message));
      }
    }
  });
}

// Send notification to specific user
export function sendNotification(userId: string, notification: any): void {
  const client = clients.get(userId);
  if (client && client.subscriptions.has('notifications')) {
    if (client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(
        JSON.stringify({
          type: 'notification',
          data: notification,
        })
      );
    }
  }
}

// Find client by WebSocket instance
function findClientByWs(ws: WebSocket): ConnectedClient | undefined {
  for (const client of clients.values()) {
    if (client.ws === ws) {
      return client;
    }
  }
  return undefined;
}

// Get connected clients stats
export function getConnectionStats(): {
  totalConnections: number;
  byOrganization: Record<string, number>;
} {
  const byOrganization: Record<string, number> = {};

  clients.forEach((client) => {
    if (client.organizationId) {
      byOrganization[client.organizationId] =
        (byOrganization[client.organizationId] || 0) + 1;
    }
  });

  return {
    totalConnections: clients.size,
    byOrganization,
  };
}
