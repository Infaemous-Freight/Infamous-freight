import { Kafka, Producer, Consumer, logLevel } from 'kafkajs';
import { logger } from '../utils/logger';

const kafka = new Kafka({
  clientId: 'infamous-freight-api',
  brokers: (process.env.KAFKA_BROKERS || 'localhost:9092').split(','),
  logLevel: logLevel.ERROR,
  retry: {
    initialRetryTime: 100,
    retries: 8,
  },
});

export const producer: Producer = kafka.producer({
  allowAutoTopicCreation: true,
  transactionTimeout: 30000,
});

export const createConsumer = (groupId: string): Consumer => {
  return kafka.consumer({
    groupId,
    sessionTimeout: 30000,
    heartbeatInterval: 3000,
  });
};

// Event types
export enum EventType {
  // Shipment events
  SHIPMENT_CREATED = 'shipment.created',
  SHIPMENT_UPDATED = 'shipment.updated',
  SHIPMENT_ASSIGNED = 'shipment.assigned',
  SHIPMENT_PICKED_UP = 'shipment.picked_up',
  SHIPMENT_DELIVERED = 'shipment.delivered',
  SHIPMENT_CANCELLED = 'shipment.cancelled',

  // Driver events
  DRIVER_CREATED = 'driver.created',
  DRIVER_UPDATED = 'driver.updated',
  DRIVER_STATUS_CHANGED = 'driver.status_changed',
  HOS_VIOLATION = 'driver.hos_violation',

  // Vehicle events
  VEHICLE_CREATED = 'vehicle.created',
  VEHICLE_UPDATED = 'vehicle.updated',
  MAINTENANCE_DUE = 'vehicle.maintenance_due',

  // Invoice events
  INVOICE_CREATED = 'invoice.created',
  INVOICE_SENT = 'invoice.sent',
  INVOICE_PAID = 'invoice.paid',
  INVOICE_OVERDUE = 'invoice.overdue',

  // User events
  USER_REGISTERED = 'user.registered',
  USER_LOGIN = 'user.login',
  USER_UPDATED = 'user.updated',

  // AI events
  AI_RECOMMENDATION_GENERATED = 'ai.recommendation_generated',
  FRAUD_DETECTED = 'ai.fraud_detected',
  CHURN_RISK_DETECTED = 'ai.churn_risk_detected',

  // Analytics events
  METRIC_RECORDED = 'analytics.metric_recorded',
}

export interface Event {
  type: EventType;
  payload: any;
  metadata: {
    timestamp: string;
    correlationId: string;
    organizationId?: string;
    userId?: string;
    version: string;
  };
}

// Initialize producer
export const initProducer = async (): Promise<void> => {
  try {
    await producer.connect();
    logger.info('Kafka producer connected');
  } catch (error) {
    logger.error({ error }, 'Failed to connect Kafka producer');
    throw error;
  }
};

// Publish event
export const publishEvent = async (event: Event): Promise<void> => {
  try {
    const topic = event.type.split('.')[0]; // e.g., 'shipment' from 'shipment.created'

    await producer.send({
      topic,
      messages: [
        {
          key: event.payload.id || event.metadata.correlationId,
          value: JSON.stringify(event),
          headers: {
            'event-type': event.type,
            'correlation-id': event.metadata.correlationId,
          },
        },
      ],
    });

    logger.debug(
      { type: event.type, correlationId: event.metadata.correlationId },
      'Event published'
    );
  } catch (error) {
    logger.error({ error, event }, 'Failed to publish event');
    throw error;
  }
};

// Create event helper
export const createEvent = (
  type: EventType,
  payload: any,
  organizationId?: string,
  userId?: string
): Event => ({
  type,
  payload,
  metadata: {
    timestamp: new Date().toISOString(),
    correlationId: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    organizationId,
    userId,
    version: '1.0',
  },
});

// Event consumers
export class EventConsumer {
  private consumer: Consumer;
  private handlers: Map<EventType, (event: Event) => Promise<void>> = new Map();

  constructor(groupId: string) {
    this.consumer = createConsumer(groupId);
  }

  registerHandler(
    eventType: EventType,
    handler: (event: Event) => Promise<void>
  ): void {
    this.handlers.set(eventType, handler);
  }

  async start(topics: string[]): Promise<void> {
    await this.consumer.connect();

    for (const topic of topics) {
      await this.consumer.subscribe({ topic, fromBeginning: false });
    }

    await this.consumer.run({
      eachMessage: async ({ topic, partition, message }) => {
        try {
          const event: Event = JSON.parse(message.value!.toString());
          const handler = this.handlers.get(event.type);

          if (handler) {
            await handler(event);
            logger.debug(
              { type: event.type, topic, partition },
              'Event processed'
            );
          } else {
            logger.warn(
              { type: event.type, topic },
              'No handler registered for event type'
            );
          }
        } catch (error) {
          logger.error({ error, topic, partition }, 'Failed to process event');
          // In production, send to dead letter queue
        }
      },
    });

    logger.info({ topics }, 'Event consumer started');
  }

  async stop(): Promise<void> {
    await this.consumer.disconnect();
    logger.info('Event consumer stopped');
  }
}

// Initialize event streaming
export const initEventStreaming = async (): Promise<void> => {
  await initProducer();

  // Start consumers
  const notificationConsumer = new EventConsumer('notification-service');
  notificationConsumer.registerHandler(
    EventType.SHIPMENT_ASSIGNED,
    async (event) => {
      // Send notification to driver
      logger.info(
        { shipmentId: event.payload.id },
        'Sending shipment assignment notification'
      );
    }
  );
  notificationConsumer.registerHandler(
    EventType.INVOICE_OVERDUE,
    async (event) => {
      // Send payment reminder
      logger.info(
        { invoiceId: event.payload.id },
        'Sending overdue invoice notification'
      );
    }
  );
  await notificationConsumer.start(['shipment', 'invoice']);

  const analyticsConsumer = new EventConsumer('analytics-service');
  analyticsConsumer.registerHandler(
    EventType.SHIPMENT_DELIVERED,
    async (event) => {
      // Update analytics
      logger.info(
        { shipmentId: event.payload.id },
        'Updating delivery analytics'
      );
    }
  );
  await analyticsConsumer.start(['shipment']);

  logger.info('Event streaming initialized');
};
