import { PrismaClient } from '@prisma/client';
import Stripe from 'stripe';

const prisma = new PrismaClient();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2024-12-18.acacia',
});

export interface FactoringApplication {
  invoiceId: string;
  organizationId: string;
  advanceRate: number; // Percentage (e.g., 85 for 85%)
  feeRate: number; // Percentage (e.g., 3 for 3%)
}

export interface FactoringQuote {
  invoiceAmount: number;
  advanceAmount: number;
  feeAmount: number;
  reserveAmount: number;
  netProceeds: number;
}

export class FactoringService {
  // Get factoring quote
  static async getQuote(invoiceId: string): Promise<FactoringQuote> {
    const invoice = await prisma.invoice.findUnique({
      where: { id: invoiceId },
    });

    if (!invoice) {
      throw new Error('Invoice not found');
    }

    if (invoice.status !== 'SENT' && invoice.status !== 'VIEWED') {
      throw new Error('Invoice must be sent before factoring');
    }

    // Default rates (would come from configuration or partner API)
    const advanceRate = 0.85; // 85% advance
    const feeRate = 0.03; // 3% fee

    const invoiceAmount = invoice.totalAmount;
    const advanceAmount = invoiceAmount * advanceRate;
    const feeAmount = invoiceAmount * feeRate;
    const reserveAmount = invoiceAmount - advanceAmount - feeAmount;
    const netProceeds = advanceAmount - feeAmount;

    return {
      invoiceAmount,
      advanceAmount,
      feeAmount,
      reserveAmount,
      netProceeds,
    };
  }

  // Apply for factoring
  static async apply(application: FactoringApplication) {
    const { invoiceId, organizationId, advanceRate, feeRate } = application;

    const invoice = await prisma.invoice.findFirst({
      where: {
        id: invoiceId,
        organizationId,
      },
      include: {
        shipment: {
          include: {
            customer: true,
          },
        },
      },
    });

    if (!invoice) {
      throw new Error('Invoice not found');
    }

    // Check if already factored
    const existing = await prisma.factoring.findFirst({
      where: { invoiceId },
    });

    if (existing) {
      throw new Error('Invoice already has a factoring application');
    }

    const quote = await this.getQuote(invoiceId);

    // Create factoring record
    const factoring = await prisma.factoring.create({
      data: {
        invoiceId,
        organizationId,
        advanceRate,
        feeRate,
        advanceAmount: quote.advanceAmount,
        feeAmount: quote.feeAmount,
        reserveAmount: quote.reserveAmount,
        status: 'PENDING',
        applicationDate: new Date(),
      },
    });

    // Submit to factoring partner (async)
    this.submitToPartner(factoring.id).catch(console.error);

    return { factoring, quote };
  }

  // Submit to external factoring partner
  private static async submitToPartner(factoringId: string) {
    const factoring = await prisma.factoring.findUnique({
      where: { id: factoringId },
      include: {
        invoice: {
          include: {
            shipment: {
              include: {
                customer: true,
                organization: true,
              },
            },
          },
        },
      },
    });

    if (!factoring) return;

    try {
      // This would integrate with your factoring partner's API
      // For example: RTS, Triumph, OTR Capital, etc.
      const partnerResponse = await this.callFactoringPartnerAPI(factoring);

      await prisma.factoring.update({
        where: { id: factoringId },
        data: {
          partnerReference: partnerResponse.reference,
          partnerStatus: partnerResponse.status,
          status: partnerResponse.status === 'APPROVED' ? 'APPROVED' : 'UNDER_REVIEW',
          reviewedAt: new Date(),
        },
      });

      // If approved, create transfer
      if (partnerResponse.status === 'APPROVED') {
        await this.processAdvance(factoringId);
      }
    } catch (error) {
      console.error('Factoring partner submission failed:', error);
      await prisma.factoring.update({
        where: { id: factoringId },
        data: {
          status: 'ERROR',
          notes: `Partner submission failed: ${(error as Error).message}`,
        },
      });
    }
  }

  // Mock factoring partner API call
  private static async callFactoringPartnerAPI(factoring: any): Promise<any> {
    // In production, this would call the actual factoring partner API
    // For now, simulate approval
    return {
      reference: `FP-${Date.now()}`,
      status: 'APPROVED',
      approvedAmount: factoring.advanceAmount,
    };
  }

  // Process advance payment
  private static async processAdvance(factoringId: string) {
    const factoring = await prisma.factoring.findUnique({
      where: { id: factoringId },
      include: {
        invoice: true,
        organization: true,
      },
    });

    if (!factoring) return;

    // Create Stripe transfer to organization's connected account
    try {
      const transfer = await stripe.transfers.create({
        amount: Math.round(factoring.advanceAmount * 100), // Convert to cents
        currency: 'usd',
        destination: factoring.organization.stripeAccountId || '',
        description: `Factoring advance for invoice ${factoring.invoice.invoiceNumber}`,
      });

      await prisma.factoring.update({
        where: { id: factoringId },
        data: {
          status: 'FUNDED',
          fundedAt: new Date(),
          transferId: transfer.id,
        },
      });

      // Update invoice status
      await prisma.invoice.update({
        where: { id: factoring.invoiceId },
        data: {
          isFactored: true,
          factoringId,
        },
      });
    } catch (error) {
      console.error('Transfer failed:', error);
      throw error;
    }
  }

  // Get factoring status
  static async getStatus(invoiceId: string) {
    const factoring = await prisma.factoring.findFirst({
      where: { invoiceId },
      include: {
        payments: true,
      },
    });

    if (!factoring) {
      return null;
    }

    return {
      id: factoring.id,
      status: factoring.status,
      advanceAmount: factoring.advanceAmount,
      feeAmount: factoring.feeAmount,
      reserveAmount: factoring.reserveAmount,
      fundedAt: factoring.fundedAt,
      applicationDate: factoring.applicationDate,
      payments: factoring.payments,
    };
  }

  // Release reserve (when customer pays invoice)
  static async releaseReserve(factoringId: string) {
    const factoring = await prisma.factoring.findUnique({
      where: { id: factoringId },
      include: { organization: true },
    });

    if (!factoring || factoring.status !== 'FUNDED') {
      throw new Error('Invalid factoring status for reserve release');
    }

    // Transfer reserve amount minus any additional fees
    const reserveRelease = await stripe.transfers.create({
      amount: Math.round(factoring.reserveAmount * 100),
      currency: 'usd',
      destination: factoring.organization.stripeAccountId || '',
      description: `Factoring reserve release for ${factoring.id}`,
    });

    await prisma.factoring.update({
      where: { id: factoringId },
      data: {
        status: 'COMPLETED',
        reserveReleasedAt: new Date(),
        reserveTransferId: reserveRelease.id,
      },
    });

    return { success: true, transferId: reserveRelease.id };
  }

  // Get factoring dashboard data
  static async getDashboard(organizationId: string) {
    const [active, completed, totalAdvanced, totalFees] = await Promise.all([
      prisma.factoring.count({
        where: {
          organizationId,
          status: { in: ['PENDING', 'APPROVED', 'FUNDED'] },
        },
      }),
      prisma.factoring.count({
        where: {
          organizationId,
          status: 'COMPLETED',
        },
      }),
      prisma.factoring.aggregate({
        where: { organizationId },
        _sum: { advanceAmount: true },
      }),
      prisma.factoring.aggregate({
        where: { organizationId },
        _sum: { feeAmount: true },
      }),
    ]);

    return {
      activeApplications: active,
      completed: completed,
      totalAdvanced: totalAdvanced._sum.advanceAmount || 0,
      totalFees: totalFees._sum.feeAmount || 0,
    };
  }
}
