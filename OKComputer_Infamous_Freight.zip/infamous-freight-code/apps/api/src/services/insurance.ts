import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export interface InsuranceQuoteRequest {
  shipmentId: string;
  cargoValue: number;
  cargoType: string;
  origin: string;
  destination: string;
  coverageType: 'ALL_RISK' | 'NAMED_PERILS' | 'TOTAL_LOSS';
}

export interface InsuranceQuote {
  premium: number;
  coverageAmount: number;
  deductible: number;
  policyTerms: string;
  validUntil: Date;
}

export class InsuranceService {
  private static readonly RATES: Record<string, number> = {
    ALL_RISK: 0.005, // 0.5% of cargo value
    NAMED_PERILS: 0.003, // 0.3% of cargo value
    TOTAL_LOSS: 0.0015, // 0.15% of cargo value
  };

  private static readonly DEDUCTIBLES: Record<string, number> = {
    ALL_RISK: 1000,
    NAMED_PERILS: 2500,
    TOTAL_LOSS: 5000,
  };

  // Get insurance quote
  static async getQuote(request: InsuranceQuoteRequest): Promise<InsuranceQuote> {
    const { cargoValue, coverageType } = request;

    const baseRate = this.RATES[coverageType] || this.RATES.ALL_RISK;
    const deductible = this.DEDUCTIBLES[coverageType] || 1000;

    // Calculate premium with minimum
    let premium = cargoValue * baseRate;
    premium = Math.max(premium, 50); // Minimum $50 premium

    // Add distance factor (would use actual distance calculation)
    const distanceFactor = 1.0; // Placeholder
    premium *= distanceFactor;

    // Add cargo type adjustment
    const cargoTypeFactor = this.getCargoTypeFactor(request.cargoType);
    premium *= cargoTypeFactor;

    return {
      premium: Math.round(premium * 100) / 100,
      coverageAmount: cargoValue,
      deductible,
      policyTerms: this.getPolicyTerms(coverageType),
      validUntil: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
    };
  }

  // Purchase insurance
  static async purchase(
    shipmentId: string,
    organizationId: string,
    quote: InsuranceQuote,
    coverageType: string
  ) {
    const shipment = await prisma.shipment.findFirst({
      where: {
        id: shipmentId,
        organizationId,
      },
    });

    if (!shipment) {
      throw new Error('Shipment not found');
    }

    if (shipment.insurancePurchased) {
      throw new Error('Insurance already purchased for this shipment');
    }

    // Create insurance record
    const insurance = await prisma.insurance.create({
      data: {
        shipmentId,
        organizationId,
        coverageType,
        coverageAmount: quote.coverageAmount,
        premium: quote.premium,
        deductible: quote.deductible,
        policyNumber: this.generatePolicyNumber(),
        status: 'ACTIVE',
        startDate: new Date(),
        endDate: shipment.scheduledDeliveryDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        terms: quote.policyTerms,
      },
    });

    // Update shipment
    await prisma.shipment.update({
      where: { id: shipmentId },
      data: {
        insurancePurchased: true,
        insuranceId: insurance.id,
      },
    });

    // Process payment
    await this.processPayment(insurance.id, organizationId, quote.premium);

    return insurance;
  }

  // Process insurance payment
  private static async processPayment(
    insuranceId: string,
    organizationId: string,
    amount: number
  ) {
    // In production, integrate with Stripe or other payment processor
    // For now, create a charge record
    await prisma.insuranceCharge.create({
      data: {
        insuranceId,
        organizationId,
        amount,
        status: 'PAID',
        paidAt: new Date(),
      },
    });

    await prisma.insurance.update({
      where: { id: insuranceId },
      data: { paidAt: new Date() },
    });
  }

  // File a claim
  static async fileClaim(
    insuranceId: string,
    organizationId: string,
    claimData: {
      incidentDate: Date;
      incidentType: string;
      description: string;
      estimatedLoss: number;
      supportingDocuments?: string[];
    }
  ) {
    const insurance = await prisma.insurance.findFirst({
      where: {
        id: insuranceId,
        organizationId,
      },
    });

    if (!insurance) {
      throw new Error('Insurance policy not found');
    }

    if (insurance.status !== 'ACTIVE') {
      throw new Error('Insurance policy is not active');
    }

    const claim = await prisma.insuranceClaim.create({
      data: {
        insuranceId,
        organizationId,
        claimNumber: this.generateClaimNumber(),
        incidentDate: claimData.incidentDate,
        incidentType: claimData.incidentType,
        description: claimData.description,
        estimatedLoss: claimData.estimatedLoss,
        supportingDocuments: claimData.supportingDocuments || [],
        status: 'SUBMITTED',
        submittedAt: new Date(),
      },
    });

    // Notify claims department
    await this.notifyClaimsDepartment(claim);

    return claim;
  }

  // Get insurance details
  static async getDetails(insuranceId: string, organizationId: string) {
    const insurance = await prisma.insurance.findFirst({
      where: {
        id: insuranceId,
        organizationId,
      },
      include: {
        shipment: {
          select: {
            referenceNumber: true,
            originCity: true,
            originState: true,
            destinationCity: true,
            destinationState: true,
            status: true,
          },
        },
        claims: true,
      },
    });

    if (!insurance) {
      throw new Error('Insurance not found');
    }

    return insurance;
  }

  // Get organization's insurance history
  static async getHistory(organizationId: string) {
    const [policies, claims, stats] = await Promise.all([
      prisma.insurance.findMany({
        where: { organizationId },
        include: {
          shipment: {
            select: {
              referenceNumber: true,
              originCity: true,
              destinationCity: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.insuranceClaim.findMany({
        where: { organizationId },
        orderBy: { submittedAt: 'desc' },
      }),
      prisma.insurance.aggregate({
        where: { organizationId },
        _sum: {
          premium: true,
          coverageAmount: true,
        },
        _count: {
          id: true,
        },
      }),
    ]);

    return {
      policies,
      claims,
      stats: {
        totalPolicies: stats._count.id,
        totalPremium: stats._sum.premium || 0,
        totalCoverage: stats._sum.coverageAmount || 0,
      },
    };
  }

  // Get coverage types
  static getCoverageTypes() {
    return [
      {
        type: 'ALL_RISK',
        name: 'All Risk',
        description: 'Covers all risks of physical loss or damage except those specifically excluded',
        rate: this.RATES.ALL_RISK,
        deductible: this.DEDUCTIBLES.ALL_RISK,
      },
      {
        type: 'NAMED_PERILS',
        name: 'Named Perils',
        description: 'Covers only specific perils named in the policy (fire, theft, collision, etc.)',
        rate: this.RATES.NAMED_PERILS,
        deductible: this.DEDUCTIBLES.NAMED_PERILS,
      },
      {
        type: 'TOTAL_LOSS',
        name: 'Total Loss Only',
        description: 'Covers only complete loss of cargo, not partial damage',
        rate: this.RATES.TOTAL_LOSS,
        deductible: this.DEDUCTIBLES.TOTAL_LOSS,
      },
    ];
  }

  // Private helper methods
  private static getCargoTypeFactor(cargoType: string): number {
    const factors: Record<string, number> = {
      'HAZMAT': 1.5,
      'REFRIGERATED': 1.2,
      'HIGH_VALUE': 1.3,
      'FRAGILE': 1.25,
      'STANDARD': 1.0,
    };
    return factors[cargoType] || 1.0;
  }

  private static getPolicyTerms(coverageType: string): string {
    const terms: Record<string, string> = {
      ALL_RISK: 'All Risk coverage includes protection against theft, damage, loss, and other perils except those specifically excluded. Exclusions include: inherent vice, wear and tear, improper packaging.',
      NAMED_PERILS: 'Named Perils coverage includes: fire, lightning, explosion, collision, overturn, theft, and water damage. Other losses are not covered.',
      TOTAL_LOSS: 'Total Loss Only coverage provides protection only in the event of complete destruction or loss of the entire shipment. Partial damage is not covered.',
    };
    return terms[coverageType] || terms.ALL_RISK;
  }

  private static generatePolicyNumber(): string {
    const prefix = 'IFC';
    const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `${prefix}-${date}-${random}`;
  }

  private static generateClaimNumber(): string {
    const prefix = 'CLM';
    const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `${prefix}-${date}-${random}`;
  }

  private static async notifyClaimsDepartment(claim: any) {
    // In production, send email/SMS notification
    console.log(`Claim ${claim.claimNumber} filed and awaiting review`);
  }
}
