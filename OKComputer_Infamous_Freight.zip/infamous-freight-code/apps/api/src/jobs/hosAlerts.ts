import { PrismaClient, HosStatus } from '@prisma/client';
import { logger } from '../utils/logger';

const prisma = new PrismaClient();

// FMCSA HOS Limits
const HOS_LIMITS = {
  DAILY_DRIVING: 11, // 11 hours daily driving
  DAILY_DUTY: 14, // 14 hours daily duty
  WEEKLY: 60, // 60 hours in 7 days
  BIWEEKLY: 70, // 70 hours in 8 days
  REST_BREAK: 0.5, // 30 minutes after 8 hours
};

export class HosAlertJob {
  async run(): Promise<void> {
    logger.info('Starting HOS alert job');

    try {
      // Check daily driving limits
      await this.checkDailyDrivingLimits();

      // Check daily duty limits
      await this.checkDailyDutyLimits();

      // Check weekly limits
      await this.checkWeeklyLimits();

      // Check rest break requirements
      await this.checkRestBreaks();

      // Update driver HOS status
      await this.updateDriverStatuses();

      logger.info('HOS alert job completed');
    } catch (error) {
      logger.error({ error }, 'HOS alert job failed');
      throw error;
    }
  }

  private async checkDailyDrivingLimits(): Promise<void> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const drivers = await prisma.driver.findMany({
      where: {
        status: { in: ['ON_DUTY', 'IN_TRANSIT'] },
      },
      include: {
        hosLogs: {
          where: {
            date: today,
            dutyStatus: 'D',
          },
        },
        user: true,
      },
    });

    for (const driver of drivers) {
      const drivingHours = driver.hosLogs.reduce(
        (sum, log) => sum + log.hours,
        0
      );

      const remaining = HOS_LIMITS.DAILY_DRIVING - drivingHours;

      if (remaining <= 1 && remaining > 0) {
        // Warning: Approaching limit
        await this.createAlert(
          driver,
          'WARNING',
          'Daily Driving Limit',
          `You have ${remaining.toFixed(1)} hours of driving time remaining today`
        );
      } else if (remaining <= 0) {
        // Violation: Exceeded limit
        await this.createAlert(
          driver,
          'VIOLATION',
          'Daily Driving Limit Exceeded',
          `You have exceeded the 11-hour daily driving limit. Stop driving immediately.`
        );

        // Update driver status
        await prisma.driver.update({
          where: { id: driver.id },
          data: { status: 'OFF_DUTY' },
        });
      }
    }
  }

  private async checkDailyDutyLimits(): Promise<void> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const drivers = await prisma.driver.findMany({
      where: {
        status: { in: ['ON_DUTY', 'IN_TRANSIT'] },
      },
      include: {
        hosLogs: {
          where: {
            date: today,
            dutyStatus: { in: ['D', 'ON_DUTY'] },
          },
        },
        user: true,
      },
    });

    for (const driver of drivers) {
      const dutyHours = driver.hosLogs.reduce((sum, log) => sum + log.hours, 0);
      const remaining = HOS_LIMITS.DAILY_DUTY - dutyHours;

      if (remaining <= 1 && remaining > 0) {
        await this.createAlert(
          driver,
          'WARNING',
          'Daily Duty Limit',
          `You have ${remaining.toFixed(1)} hours of duty time remaining today`
        );
      } else if (remaining <= 0) {
        await this.createAlert(
          driver,
          'VIOLATION',
          'Daily Duty Limit Exceeded',
          `You have exceeded the 14-hour daily duty limit. Stop all work immediately.`
        );
      }
    }
  }

  private async checkWeeklyLimits(): Promise<void> {
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const drivers = await prisma.driver.findMany({
      include: {
        hosLogs: {
          where: {
            date: { gte: sevenDaysAgo },
            dutyStatus: { in: ['D', 'ON_DUTY'] },
          },
        },
        user: true,
      },
    });

    for (const driver of drivers) {
      const weeklyHours = driver.hosLogs.reduce(
        (sum, log) => sum + log.hours,
        0
      );
      const remaining = HOS_LIMITS.WEEKLY - weeklyHours;

      if (remaining <= 5 && remaining > 0) {
        await this.createAlert(
          driver,
          'WARNING',
          'Weekly Hour Limit',
          `You have ${remaining.toFixed(1)} hours remaining in your 60-hour weekly limit`
        );
      } else if (remaining <= 0) {
        await this.createAlert(
          driver,
          'VIOLATION',
          'Weekly Hour Limit Exceeded',
          `You have exceeded the 60-hour weekly limit. You must take 34 hours off duty.`
        );
      }
    }
  }

  private async checkRestBreaks(): Promise<void> {
    const eightHoursAgo = new Date();
    eightHoursAgo.setHours(eightHoursAgo.getHours() - 8);

    const drivers = await prisma.driver.findMany({
      where: {
        status: 'IN_TRANSIT',
      },
      include: {
        hosLogs: {
          where: {
            dutyStatus: 'D',
            startTime: { gte: eightHoursAgo },
          },
          orderBy: { startTime: 'desc' },
        },
        user: true,
      },
    });

    for (const driver of drivers) {
      const recentDriving = driver.hosLogs[0];
      if (recentDriving) {
        const drivingSinceBreak =
          (new Date().getTime() - new Date(recentDriving.startTime!).getTime()) /
          (1000 * 60 * 60);

        if (drivingSinceBreak >= 8) {
          await this.createAlert(
            driver,
            'WARNING',
            'Rest Break Required',
            `You have been driving for ${drivingSinceBreak.toFixed(1)} hours. A 30-minute break is required.`
          );
        }
      }
    }
  }

  private async updateDriverStatuses(): Promise<void> {
    // Update current HOS status based on recent logs
    const drivers = await prisma.driver.findMany({
      include: {
        hosLogs: {
          orderBy: { startTime: 'desc' },
          take: 1,
        },
      },
    });

    for (const driver of drivers) {
      const lastLog = driver.hosLogs[0];
      if (lastLog) {
        await prisma.driver.update({
          where: { id: driver.id },
          data: {
            currentHosStatus: lastLog.dutyStatus,
            lastHosUpdate: lastLog.startTime || new Date(),
          },
        });
      }
    }
  }

  private async createAlert(
    driver: any,
    severity: 'WARNING' | 'VIOLATION',
    title: string,
    message: string
  ): Promise<void> {
    // Create notification for driver
    await prisma.notification.create({
      data: {
        userId: driver.userId,
        organizationId: driver.organizationId,
        type: severity === 'VIOLATION' ? 'ERROR' : 'WARNING',
        title,
        message,
        entityType: 'DRIVER',
        entityId: driver.id,
      },
    });

    // Create HOS alert record
    await prisma.hosAlert.create({
      data: {
        driverId: driver.id,
        organizationId: driver.organizationId,
        severity,
        title,
        message,
        status: 'ACTIVE',
      },
    });

    // Notify dispatchers
    const dispatchers = await prisma.user.findMany({
      where: {
        organizationId: driver.organizationId,
        role: { in: ['ADMIN', 'MANAGER', 'DISPATCHER'] },
      },
    });

    for (const dispatcher of dispatchers) {
      await prisma.notification.create({
        data: {
          userId: dispatcher.id,
          organizationId: driver.organizationId,
          type: severity === 'VIOLATION' ? 'ERROR' : 'WARNING',
          title: `HOS ${severity}: ${driver.user.firstName} ${driver.user.lastName}`,
          message,
          entityType: 'DRIVER',
          entityId: driver.id,
        },
      });
    }

    logger.info(
      { driverId: driver.id, severity, title },
      'HOS alert created'
    );
  }
}

// Run job if called directly
if (require.main === module) {
  const job = new HosAlertJob();
  job
    .run()
    .then(() => process.exit(0))
    .catch((error) => {
      console.error(error);
      process.exit(1);
    });
}
