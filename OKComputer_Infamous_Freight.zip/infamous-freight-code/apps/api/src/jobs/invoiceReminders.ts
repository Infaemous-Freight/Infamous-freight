import { PrismaClient, InvoiceStatus } from '@prisma/client';
import { logger } from '../utils/logger';

const prisma = new PrismaClient();

interface ReminderConfig {
  daysBeforeDue: number[];
  daysAfterDue: number[];
}

const DEFAULT_CONFIG: ReminderConfig = {
  daysBeforeDue: [7, 3, 1],
  daysAfterDue: [1, 7, 14, 30],
};

export class InvoiceReminderJob {
  private config: ReminderConfig;

  constructor(config: ReminderConfig = DEFAULT_CONFIG) {
    this.config = config;
  }

  async run(): Promise<void> {
    logger.info('Starting invoice reminder job');

    try {
      // Send reminders for upcoming due dates
      await this.sendUpcomingReminders();

      // Send reminders for overdue invoices
      await this.sendOverdueReminders();

      // Update invoice statuses
      await this.updateOverdueStatuses();

      logger.info('Invoice reminder job completed');
    } catch (error) {
      logger.error({ error }, 'Invoice reminder job failed');
      throw error;
    }
  }

  private async sendUpcomingReminders(): Promise<void> {
    const now = new Date();

    for (const days of this.config.daysBeforeDue) {
      const targetDate = new Date(now);
      targetDate.setDate(targetDate.getDate() + days);

      const invoices = await prisma.invoice.findMany({
        where: {
          status: {
            in: [InvoiceStatus.SENT, InvoiceStatus.VIEWED],
          },
          dueDate: {
            gte: new Date(targetDate.setHours(0, 0, 0, 0)),
            lt: new Date(targetDate.setHours(23, 59, 59, 999)),
          },
        },
        include: {
          organization: true,
          shipment: {
            include: {
              customer: true,
            },
          },
        },
      });

      for (const invoice of invoices) {
        await this.sendReminder(invoice, 'UPCOMING', days);
      }

      logger.info(
        { count: invoices.length, days },
        'Sent upcoming payment reminders'
      );
    }
  }

  private async sendOverdueReminders(): Promise<void> {
    const now = new Date();

    for (const days of this.config.daysAfterDue) {
      const targetDate = new Date(now);
      targetDate.setDate(targetDate.getDate() - days);

      const invoices = await prisma.invoice.findMany({
        where: {
          status: {
            in: [InvoiceStatus.SENT, InvoiceStatus.VIEWED, InvoiceStatus.PARTIAL],
          },
          dueDate: {
            gte: new Date(targetDate.setHours(0, 0, 0, 0)),
            lt: new Date(targetDate.setHours(23, 59, 59, 999)),
          },
        },
        include: {
          organization: true,
          shipment: {
            include: {
              customer: true,
            },
          },
        },
      });

      for (const invoice of invoices) {
        await this.sendReminder(invoice, 'OVERDUE', days);
      }

      logger.info(
        { count: invoices.length, days },
        'Sent overdue payment reminders'
      );
    }
  }

  private async updateOverdueStatuses(): Promise<void> {
    const now = new Date();

    const overdueInvoices = await prisma.invoice.findMany({
      where: {
        status: {
          in: [InvoiceStatus.SENT, InvoiceStatus.VIEWED, InvoiceStatus.PARTIAL],
        },
        dueDate: {
          lt: now,
        },
      },
    });

    for (const invoice of overdueInvoices) {
      await prisma.invoice.update({
        where: { id: invoice.id },
        data: { status: InvoiceStatus.OVERDUE },
      });

      // Create activity log
      await prisma.activityLog.create({
        data: {
          organizationId: invoice.organizationId,
          entityType: 'INVOICE',
          entityId: invoice.id,
          action: 'STATUS_CHANGE',
          description: `Invoice marked as OVERDUE`,
          metadata: {
            previousStatus: invoice.status,
            newStatus: 'OVERDUE',
            daysOverdue: Math.floor(
              (now.getTime() - invoice.dueDate.getTime()) / (1000 * 60 * 60 * 24)
            ),
          },
        },
      });
    }

    logger.info(
      { count: overdueInvoices.length },
      'Updated overdue invoice statuses'
    );
  }

  private async sendReminder(
    invoice: any,
    type: 'UPCOMING' | 'OVERDUE',
    days: number
  ): Promise<void> {
    // Check if reminder was already sent today
    const existingReminder = await prisma.invoiceReminder.findFirst({
      where: {
        invoiceId: invoice.id,
        type,
        days,
        sentAt: {
          gte: new Date(new Date().setHours(0, 0, 0, 0)),
        },
      },
    });

    if (existingReminder) {
      return;
    }

    // Create reminder record
    await prisma.invoiceReminder.create({
      data: {
        invoiceId: invoice.id,
        organizationId: invoice.organizationId,
        type,
        days,
        sentAt: new Date(),
      },
    });

    // Send email notification (placeholder)
    await this.sendEmailNotification(invoice, type, days);

    // Send in-app notification
    await this.sendInAppNotification(invoice, type, days);
  }

  private async sendEmailNotification(
    invoice: any,
    type: 'UPCOMING' | 'OVERDUE',
    days: number
  ): Promise<void> {
    // In production, integrate with email service
    const subject =
      type === 'UPCOMING'
        ? `Payment Reminder: Invoice ${invoice.invoiceNumber} due in ${days} days`
        : `OVERDUE: Invoice ${invoice.invoiceNumber} is ${days} days past due`;

    logger.info(
      { invoiceId: invoice.id, subject },
      'Email notification queued'
    );
  }

  private async sendInAppNotification(
    invoice: any,
    type: 'UPCOMING' | 'OVERDUE',
    days: number
  ): Promise<void> {
    const title =
      type === 'UPCOMING'
        ? 'Upcoming Payment Due'
        : 'Overdue Invoice';

    const message =
      type === 'UPCOMING'
        ? `Invoice ${invoice.invoiceNumber} is due in ${days} days`
        : `Invoice ${invoice.invoiceNumber} is ${days} days overdue`;

    // Create notification for organization users
    const users = await prisma.user.findMany({
      where: {
        organizationId: invoice.organizationId,
        role: {
          in: ['ADMIN', 'MANAGER', 'ACCOUNTANT'],
        },
      },
    });

    for (const user of users) {
      await prisma.notification.create({
        data: {
          userId: user.id,
          organizationId: invoice.organizationId,
          type: type === 'UPCOMING' ? 'INFO' : 'WARNING',
          title,
          message,
          entityType: 'INVOICE',
          entityId: invoice.id,
        },
      });
    }
  }
}

// Run job if called directly
if (require.main === module) {
  const job = new InvoiceReminderJob();
  job
    .run()
    .then(() => process.exit(0))
    .catch((error) => {
      console.error(error);
      process.exit(1);
    });
}
