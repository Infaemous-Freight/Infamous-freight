#!/bin/bash

# Infamous Freight - Rollback Script
# Quickly rollback to a previous stable version

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

ENVIRONMENT=${1:-production}
VERSION=${2:-}

print_header() {
    echo -e "${BLUE}"
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║        Infamous Freight - Rollback Script                      ║"
    echo "║        Environment: $ENVIRONMENT                               "
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Confirm rollback
confirm_rollback() {
    print_warning "You are about to rollback the $ENVIRONMENT environment!"
    if [ -n "$VERSION" ]; then
        print_info "Target version: $VERSION"
    fi
    
    read -p "Are you sure you want to proceed? (yes/no): " confirm
    if [[ $confirm != "yes" ]]; then
        echo "Rollback cancelled."
        exit 0
    fi
}

# Rollback API on Fly.io
rollback_api() {
    print_info "Rolling back API on Fly.io..."
    
    cd apps/api
    
    # List recent releases
    echo "Recent releases:"
    flyctl releases list --app infamous-freight-api --limit 5
    
    if [ -n "$VERSION" ]; then
        # Rollback to specific version
        flyctl deploy --image registry.fly.io/infamous-freight-api:$VERSION --app infamous-freight-api
    else
        # Interactive rollback
        read -p "Enter release version to rollback to (or press Enter for previous): " target_version
        if [ -n "$target_version" ]; then
            flyctl releases rollback --app infamous-freight-api $target_version
        else
            flyctl releases rollback --app infamous-freight-api
        fi
    fi
    
    cd ../..
    
    # Verify rollback
    print_info "Verifying API rollback..."
    sleep 30
    
    if curl -sf https://infamous-freight-api.fly.dev/api/health > /dev/null 2>&1; then
        print_success "API rollback successful"
    else
        print_error "API rollback verification failed"
        exit 1
    fi
}

# Rollback Web on Vercel
rollback_web() {
    print_info "Rolling back Web on Vercel..."
    
    cd apps/web
    
    # List recent deployments
    echo "Recent deployments:"
    vercel list --limit 5
    
    if [ -n "$VERSION" ]; then
        # Rollback to specific deployment
        vercel rollback $VERSION
    else
        # Interactive rollback
        read -p "Enter deployment URL to rollback to (or press Enter for previous): " target_url
        if [ -n "$target_url" ]; then
            vercel rollback $target_url
        else
            vercel rollback
        fi
    fi
    
    cd ../..
    
    # Verify rollback
    print_info "Verifying Web rollback..."
    sleep 30
    
    if curl -sf https://infamous-freight-enterprises.vercel.app > /dev/null 2>&1; then
        print_success "Web rollback successful"
    else
        print_error "Web rollback verification failed"
        exit 1
    fi
}

# Send notification
send_notification() {
    if [ -n "$SLACK_WEBHOOK_URL" ]; then
        curl -X POST -H 'Content-type: application/json' \
            --data "{
                \"text\": \"⚠️ Infamous Freight Rollback Completed\",
                \"blocks\": [
                    {
                        \"type\": \"header\",
                        \"text\": {
                            \"type\": \"plain_text\",
                            \"text\": \"⚠️ Rollback Completed\"
                        }
                    },
                    {
                        \"type\": \"section\",
                        \"fields\": [
                            {
                                \"type\": \"mrkdwn\",
                                \"text\": \"*Environment:* $ENVIRONMENT\"
                            },
                            {
                                \"type\": \"mrkdwn\",
                                \"text\": \"*Version:* $VERSION\"
                            }
                        ]
                    }
                ]
            }" \
            "$SLACK_WEBHOOK_URL" 2>/dev/null || true
    fi
}

# Main execution
main() {
    print_header
    confirm_rollback
    
    rollback_api
    rollback_web
    send_notification
    
    print_success "Rollback completed successfully!"
}

# Show usage
usage() {
    echo "Usage: $0 [environment] [version]"
    echo ""
    echo "Arguments:"
    echo "  environment    Target environment (production, staging) - default: production"
    echo "  version        Specific version to rollback to - default: previous version"
    echo ""
    echo "Examples:"
    echo "  $0                              # Rollback production to previous version"
    echo "  $0 staging                      # Rollback staging to previous version"
    echo "  $0 production v2.1.0            # Rollback production to v2.1.0"
}

# Parse arguments
if [ "$1" == "--help" ] || [ "$1" == "-h" ]; then
    usage
    exit 0
fi

main
