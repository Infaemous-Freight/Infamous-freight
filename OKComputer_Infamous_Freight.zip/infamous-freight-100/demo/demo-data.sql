-- Infamous Freight Demo Data
-- Run this script to populate your database with realistic sample data

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Insert demo organizations
INSERT INTO "Organization" (id, name, slug, plan, status, created_at, updated_at) VALUES
('org-demo-001', 'Demo Trucking LLC', 'demo-trucking', 'PRO', 'ACTIVE', NOW(), NOW()),
('org-demo-002', 'Midwest Logistics Inc', 'midwest-logistics', 'ENTERPRISE', 'ACTIVE', NOW(), NOW()),
('org-demo-003', 'Solo Hauler', 'solo-hauler', 'FREE', 'ACTIVE', NOW(), NOW());

-- Insert demo users
INSERT INTO "User" (id, email, name, role, organization_id, status, created_at, updated_at) VALUES
('user-demo-001', 'demo@infamousfreight.com', 'Demo Driver', 'DRIVER', 'org-demo-001', 'ACTIVE', NOW(), NOW()),
('user-demo-002', 'fleet@midwestlogistics.com', 'Sarah Mitchell', 'FLEET_MANAGER', 'org-demo-002', 'ACTIVE', NOW(), NOW()),
('user-demo-003', 'marcus@lonestartrucking.com', 'Marcus Johnson', 'DRIVER', 'org-demo-003', 'ACTIVE', NOW(), NOW()),
('user-demo-004', 'admin@infamousfreight.com', 'Admin User', 'ADMIN', 'org-demo-001', 'ACTIVE', NOW(), NOW());

-- Insert demo drivers
INSERT INTO "Driver" (id, user_id, license_number, phone, status, current_location, current_latitude, current_longitude, rating, total_miles, home_address, emergency_contact, created_at, updated_at) VALUES
('driver-001', 'user-demo-001', 'CDL12345678', '+1-555-0101', 'ON_DUTY', 'Chicago, IL', 41.8781, -87.6298, 4.8, 150000, '123 Main St, Chicago, IL', '+1-555-0199', NOW(), NOW()),
('driver-002', NULL, 'CDL87654321', '+1-555-0102', 'AVAILABLE', 'Dallas, TX', 32.7767, -96.7970, 4.9, 230000, '456 Oak Ave, Dallas, TX', '+1-555-0198', NOW(), NOW()),
('driver-003', 'user-demo-003', 'CDL11223344', '+1-555-0103', 'OFF_DUTY', 'Atlanta, GA', 33.7490, -84.3880, 4.7, 89000, '789 Pine Rd, Atlanta, GA', '+1-555-0197', NOW(), NOW()),
('driver-004', NULL, 'CDL55667788', '+1-555-0104', 'ON_DUTY', 'Denver, CO', 39.7392, -104.9903, 4.6, 175000, '321 Elm St, Denver, CO', '+1-555-0196', NOW(), NOW());

-- Insert demo vehicles
INSERT INTO "Vehicle" (id, driver_id, organization_id, vin, make, model, year, plate_number, status, mileage, fuel_type, last_maintenance_date, next_maintenance_date, last_maintenance_mileage, created_at, updated_at) VALUES
('vehicle-001', 'driver-001', 'org-demo-001', '1HGBH41JXMN109186', 'Freightliner', 'Cascadia', 2022, 'IL-TRUCK1', 'ACTIVE', 150000, 'DIESEL', '2025-01-15', '2025-04-15', 145000, NOW(), NOW()),
('vehicle-002', 'driver-002', 'org-demo-002', '1HGBH41JXMN109187', 'Peterbilt', '579', 2023, 'TX-TRUCK2', 'ACTIVE', 89000, 'DIESEL', '2025-02-01', '2025-05-01', 85000, NOW(), NOW()),
('vehicle-003', 'driver-003', 'org-demo-003', '1HGBH41JXMN109188', 'Kenworth', 'T680', 2021, 'GA-TRUCK3', 'MAINTENANCE', 230000, 'DIESEL', '2025-01-20', '2025-02-20', 228000, NOW(), NOW()),
('vehicle-004', 'driver-004', 'org-demo-002', '1HGBH41JXMN109189', 'Volvo', 'VNL 860', 2023, 'CO-TRUCK4', 'ACTIVE', 67000, 'DIESEL', '2025-01-10', '2025-04-10', 62000, NOW(), NOW());

-- Insert demo shipments
INSERT INTO "Shipment" (id, organization_id, shipper_name, shipper_address, shipper_city, shipper_state, shipper_zip, consignee_name, consignee_address, consignee_city, consignee_state, consignee_zip, pickup_latitude, pickup_longitude, delivery_latitude, delivery_longitude, pickup_date, delivery_date, status, weight, distance, rate, driver_id, vehicle_id, bol_number, reference_number, notes, created_at, updated_at) VALUES
('shipment-001', 'org-demo-001', 'ABC Manufacturing', '123 Industrial Way', 'Chicago', 'IL', '60601', 'XYZ Distribution', '456 Commerce St', 'Detroit', 'MI', '48201', 41.8781, -87.6298, 42.3314, -83.0458, '2025-02-25 08:00:00', '2025-02-25 16:00:00', 'IN_TRANSIT', 45000, 283, 850.00, 'driver-001', 'vehicle-001', 'BOL-2025-001', 'REF-001', 'Electronics shipment', NOW(), NOW()),
('shipment-002', 'org-demo-002', 'Global Foods Inc', '789 Warehouse Blvd', 'Dallas', 'TX', '75201', 'Fresh Market', '321 Grocery Lane', 'Houston', 'TX', '77001', 32.7767, -96.7970, 29.7604, -95.3698, '2025-02-24 06:00:00', '2025-02-24 14:00:00', 'DELIVERED', 32000, 240, 620.00, 'driver-002', 'vehicle-002', 'BOL-2025-002', 'REF-002', 'Perishable goods', NOW(), NOW()),
('shipment-003', 'org-demo-002', 'Steel Works Co', '555 Factory Rd', 'Pittsburgh', 'PA', '15201', 'Construction Depot', '888 Building Ave', 'Cleveland', 'OH', '44101', 40.4406, -79.9959, 41.4993, -81.6944, '2025-02-26 07:00:00', '2025-02-26 18:00:00', 'PENDING', 48000, 135, 450.00, NULL, NULL, 'BOL-2025-003', 'REF-003', 'Steel beams', NOW(), NOW()),
('shipment-004', 'org-demo-001', 'Electronics Plus', '999 Tech Park', 'San Jose', 'CA', '95101', 'Retail Giant', '111 Storefront St', 'Los Angeles', 'CA', '90001', 37.3382, -121.8863, 34.0522, -118.2437, '2025-02-23 09:00:00', '2025-02-25 15:00:00', 'DELIVERED', 12000, 382, 1200.00, 'driver-001', 'vehicle-001', 'BOL-2025-004', 'REF-004', 'Consumer electronics', NOW(), NOW()),
('shipment-005', 'org-demo-003', 'Farm Fresh', '222 Rural Route', 'Des Moines', 'IA', '50301', 'City Market', '333 Urban Ave', 'Minneapolis', 'MN', '55401', 41.5868, -93.6250, 44.9778, -93.2650, '2025-02-27 05:00:00', '2025-02-27 16:00:00', 'PENDING', 28000, 244, 580.00, NULL, NULL, 'BOL-2025-005', 'REF-005', 'Agricultural products', NOW(), NOW()),
('shipment-006', 'org-demo-002', 'Auto Parts Direct', '444 Auto Plaza', 'Denver', 'CO', '80201', 'Car Care Center', '777 Service Rd', 'Colorado Springs', 'CO', '80901', 39.7392, -104.9903, 38.8339, -104.8214, '2025-02-25 10:00:00', '2025-02-25 14:00:00', 'IN_TRANSIT', 8500, 70, 280.00, 'driver-004', 'vehicle-004', 'BOL-2025-006', 'REF-006', 'Auto parts delivery', NOW(), NOW());

-- Insert demo invoices
INSERT INTO "Invoice" (id, shipment_id, organization_id, amount, status, due_date, paid_date, invoice_number, notes, created_at, updated_at) VALUES
('invoice-001', 'shipment-002', 'org-demo-002', 620.00, 'PAID', '2025-03-10', '2025-03-05', 'INV-2025-001', 'Paid via ACH', NOW(), NOW()),
('invoice-002', 'shipment-004', 'org-demo-001', 1200.00, 'PAID', '2025-03-12', '2025-03-08', 'INV-2025-002', 'Paid via wire transfer', NOW(), NOW()),
('invoice-003', 'shipment-001', 'org-demo-001', 850.00, 'PENDING', '2025-03-15', NULL, 'INV-2025-003', 'Net 15 terms', NOW(), NOW()),
('invoice-004', 'shipment-003', 'org-demo-002', 450.00, 'DRAFT', '2025-03-20', NULL, 'INV-2025-004', 'Pending pickup confirmation', NOW(), NOW()),
('invoice-005', 'shipment-006', 'org-demo-002', 280.00, 'PENDING', '2025-03-10', NULL, 'INV-2025-005', 'Local delivery', NOW(), NOW());

-- Insert demo tracking events
INSERT INTO "TrackingEvent" (id, shipment_id, event_type, location, latitude, longitude, notes, created_at) VALUES
('event-001', 'shipment-001', 'PICKUP', 'Chicago, IL', 41.8781, -87.6298, 'Load picked up on time', NOW() - INTERVAL '6 hours'),
('event-002', 'shipment-001', 'IN_TRANSIT', 'Gary, IN', 41.5934, -87.3369, 'Passing through Indiana', NOW() - INTERVAL '4 hours'),
('event-003', 'shipment-001', 'IN_TRANSIT', 'Toledo, OH', 41.6528, -83.5379, 'Approaching Michigan border', NOW() - INTERVAL '2 hours'),
('event-004', 'shipment-002', 'PICKUP', 'Dallas, TX', 32.7767, -96.7970, 'Load secured', NOW() - INTERVAL '24 hours'),
('event-005', 'shipment-002', 'DELIVERED', 'Houston, TX', 29.7604, -95.3698, 'Delivery completed successfully', NOW() - INTERVAL '12 hours'),
('event-006', 'shipment-006', 'PICKUP', 'Denver, CO', 39.7392, -104.9903, 'Auto parts loaded', NOW() - INTERVAL '2 hours'),
('event-007', 'shipment-006', 'IN_TRANSIT', 'Castle Rock, CO', 39.3722, -104.8561, 'En route to Colorado Springs', NOW() - INTERVAL '30 minutes');

-- Insert demo AI events
INSERT INTO "AiEvent" (id, user_id, organization_id, event_type, prompt, response, tokens_used, processing_time_ms, created_at) VALUES
('ai-001', 'user-demo-001', 'org-demo-001', 'LOAD_RECOMMENDATION', 'Find me the best paying load from Chicago', '{"loads": [{"id": "shipment-003", "rate": 450, "distance": 135, "rpm": 3.33, "destination": "Cleveland, OH"}]}', 150, 850, NOW() - INTERVAL '2 hours'),
('ai-002', 'user-demo-002', 'org-demo-002', 'ROUTE_OPTIMIZATION', 'Optimize route for 5 deliveries in Texas', '{"optimized_route": ["Dallas", "Houston", "Austin", "San Antonio"], "total_distance": 892, "savings": 127, "time_saved": "2.5 hours"}', 200, 1200, NOW() - INTERVAL '1 hour'),
('ai-003', 'user-demo-003', 'org-demo-003', 'PROFITABILITY_ANALYSIS', 'What was my profit last week?', '{"total_revenue": 2050, "total_expenses": 890, "net_profit": 1160, "margin": 56.6, "miles_driven": 1850, "rpm": 1.11}', 180, 650, NOW()),
('ai-004', 'user-demo-002', 'org-demo-002', 'DRIVER_ASSIGNMENT', 'Who should I assign to the Pittsburgh load?', '{"recommended_driver": "driver-004", "reason": "Closest available driver with HOS compliance", "estimated_arrival": "2025-02-26 06:30:00"}', 165, 920, NOW() - INTERVAL '30 minutes');

-- Insert demo maintenance records
INSERT INTO "MaintenanceRecord" (id, vehicle_id, organization_id, service_type, description, cost, service_date, next_service_date, service_mileage, next_service_mileage, status, provider_name, created_at, updated_at) VALUES
('maint-001', 'vehicle-001', 'org-demo-001', 'OIL_CHANGE', 'Regular oil change and filter replacement', 125.00, '2025-01-15', '2025-04-15', 145000, 155000, 'COMPLETED', 'Quick Lube Express', NOW(), NOW()),
('maint-002', 'vehicle-002', 'org-demo-002', 'TIRE_ROTATION', 'Tire rotation and alignment check', 85.00, '2025-02-01', '2025-05-01', 85000, 95000, 'COMPLETED', 'Big O Tires', NOW(), NOW()),
('maint-003', 'vehicle-003', 'org-demo-003', 'BRAKE_REPLACEMENT', 'Brake pad and rotor replacement', 450.00, '2025-01-20', '2025-07-20', 228000, 238000, 'SCHEDULED', 'Midas', NOW(), NOW()),
('maint-004', 'vehicle-004', 'org-demo-002', 'INSPECTION', 'DOT annual inspection', 75.00, '2025-01-10', '2026-01-10', 62000, 162000, 'COMPLETED', 'Certified Truck Inspection', NOW(), NOW());

-- Insert demo compliance records
INSERT INTO "ComplianceRecord" (id, driver_id, organization_id, record_type, status, issue_date, expiration_date, document_url, notes, created_at, updated_at) VALUES
('comp-001', 'driver-001', 'org-demo-001', 'CDL', 'VALID', '2022-03-15', '2027-03-15', 'https://docs.infamousfreight.com/cdl/demo-1.pdf', 'Class A CDL with Hazmat endorsement', NOW(), NOW()),
('comp-002', 'driver-001', 'org-demo-001', 'MEDICAL_CARD', 'VALID', '2024-08-20', '2026-08-20', 'https://docs.infamousfreight.com/medical/demo-1.pdf', 'DOT medical certificate', NOW(), NOW()),
('comp-003', 'driver-002', 'org-demo-002', 'CDL', 'VALID', '2023-01-10', '2028-01-10', 'https://docs.infamousfreight.com/cdl/demo-2.pdf', 'Class A CDL', NOW(), NOW()),
('comp-004', 'driver-001', 'org-demo-001', 'HAZMAT_ENDORSEMENT', 'VALID', '2022-03-15', '2027-03-15', 'https://docs.infamousfreight.com/hazmat/demo-1.pdf', 'Hazmat endorsement valid', NOW(), NOW()),
('comp-005', 'driver-004', 'org-demo-002', 'TWIC', 'VALID', '2024-06-01', '2029-06-01', 'https://docs.infamousfreight.com/twic/demo-4.pdf', 'Transportation Worker Identification Credential', NOW(), NOW());

-- Insert demo HOS logs
INSERT INTO "HosLog" (id, driver_id, date, drive_hours, on_duty_hours, off_duty_hours, sleeper_berth_hours, status, created_at, updated_at) VALUES
('hos-001', 'driver-001', '2025-02-24', 8.5, 11.0, 10.0, 2.5, 'COMPLIANT', NOW(), NOW()),
('hos-002', 'driver-002', '2025-02-24', 7.0, 10.5, 11.5, 2.0, 'COMPLIANT', NOW(), NOW()),
('hos-003', 'driver-001', '2025-02-23', 9.0, 12.0, 9.0, 3.0, 'COMPLIANT', NOW(), NOW()),
('hos-004', 'driver-004', '2025-02-24', 6.5, 9.0, 13.0, 2.0, 'COMPLIANT', NOW(), NOW());

-- Create demo dashboard summary view
CREATE OR REPLACE VIEW demo_dashboard_summary AS
SELECT
  (SELECT COUNT(*) FROM "Shipment" WHERE status IN ('IN_TRANSIT', 'PENDING')) as active_shipments,
  (SELECT COUNT(*) FROM "Shipment" WHERE status = 'DELIVERED' AND created_at > NOW() - INTERVAL '30 days') as deliveries_this_month,
  (SELECT COUNT(*) FROM "Driver" WHERE status = 'AVAILABLE') as available_drivers,
  (SELECT COUNT(*) FROM "Vehicle" WHERE status = 'ACTIVE') as active_vehicles,
  (SELECT COALESCE(SUM(rate), 0) FROM "Shipment" WHERE status = 'DELIVERED' AND created_at > NOW() - INTERVAL '30 days') as revenue_this_month,
  (SELECT ROUND(AVG(rating), 2) FROM "Driver") as average_driver_rating,
  (SELECT COALESCE(SUM(distance), 0) FROM "Shipment" WHERE status = 'DELIVERED') as total_miles_driven,
  (SELECT COUNT(*) FROM "Shipment" WHERE status = 'PENDING') as pending_shipments,
  (SELECT COUNT(*) FROM "Invoice" WHERE status = 'PENDING') as pending_invoices,
  (SELECT COALESCE(SUM(amount), 0) FROM "Invoice" WHERE status = 'PAID' AND created_at > NOW() - INTERVAL '30 days') as collected_revenue_this_month;

-- Create indexes for demo queries
CREATE INDEX IF NOT EXISTS idx_shipment_status ON "Shipment"(status);
CREATE INDEX IF NOT EXISTS idx_shipment_driver ON "Shipment"(driver_id);
CREATE INDEX IF NOT EXISTS idx_shipment_organization ON "Shipment"(organization_id);
CREATE INDEX IF NOT EXISTS idx_tracking_event_shipment ON "TrackingEvent"(shipment_id);
CREATE INDEX IF NOT EXISTS idx_invoice_status ON "Invoice"(status);

-- Output summary
SELECT 'Demo data loaded successfully!' as message;
SELECT * FROM demo_dashboard_summary;
