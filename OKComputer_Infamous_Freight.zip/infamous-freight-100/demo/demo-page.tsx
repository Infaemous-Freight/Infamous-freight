'use client';

import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import {
  Box,
  Container,
  Heading,
  Text,
  SimpleGrid,
  Card,
  CardBody,
  CardHeader,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  Badge,
  Button,
  Flex,
  Stack,
  HStack,
  VStack,
  Progress,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  IconButton,
  useColorModeValue,
  Alert,
  AlertIcon,
  AlertTitle,
  AlertDescription,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
  Avatar,
  AvatarGroup,
  Tooltip,
  Divider,
  Link,
  Icon
} from '@chakra-ui/react';
import {
  Truck,
  MapPin,
  DollarSign,
  TrendingUp,
  Users,
  Package,
  Activity,
  Star,
  Clock,
  CheckCircle,
  AlertCircle,
  Navigation,
  BarChart3,
  MessageSquare,
  Mic,
  Shield,
  Zap,
  ArrowRight,
  Play,
  Pause,
  Phone,
  Mail,
  ExternalLink
} from 'lucide-react';

// Demo data
const DEMO_STATS = {
  activeShipments: 3,
  deliveriesThisMonth: 47,
  availableDrivers: 12,
  activeVehicles: 15,
  revenueThisMonth: 48520,
  averageRating: 4.8,
  totalMiles: 125000,
  pendingInvoices: 5,
  collectedRevenue: 42150
};

const DEMO_SHIPMENTS = [
  {
    id: 'SH-2025-001',
    shipper: 'ABC Manufacturing',
    origin: 'Chicago, IL',
    destination: 'Detroit, MI',
    status: 'in_transit',
    driver: 'John D.',
    vehicle: 'FL-2022-001',
    rate: 850,
    distance: 283,
    pickupDate: '2025-02-25T08:00:00',
    deliveryDate: '2025-02-25T16:00:00',
    progress: 65
  },
  {
    id: 'SH-2025-002',
    shipper: 'Global Foods Inc',
    origin: 'Dallas, TX',
    destination: 'Houston, TX',
    status: 'delivered',
    driver: 'Mike R.',
    vehicle: 'PB-2023-002',
    rate: 620,
    distance: 240,
    pickupDate: '2025-02-24T06:00:00',
    deliveryDate: '2025-02-24T14:00:00',
    progress: 100
  },
  {
    id: 'SH-2025-003',
    shipper: 'Steel Works Co',
    origin: 'Pittsburgh, PA',
    destination: 'Cleveland, OH',
    status: 'pending',
    driver: 'Unassigned',
    vehicle: 'Unassigned',
    rate: 450,
    distance: 135,
    pickupDate: '2025-02-26T07:00:00',
    deliveryDate: '2025-02-26T18:00:00',
    progress: 0
  },
  {
    id: 'SH-2025-006',
    shipper: 'Auto Parts Direct',
    origin: 'Denver, CO',
    destination: 'Colorado Springs, CO',
    status: 'in_transit',
    driver: 'David K.',
    vehicle: 'VL-2023-004',
    rate: 280,
    distance: 70,
    pickupDate: '2025-02-25T10:00:00',
    deliveryDate: '2025-02-25T14:00:00',
    progress: 80
  }
];

const DEMO_DRIVERS = [
  { id: 1, name: 'John D.', status: 'on_duty', rating: 4.8, miles: 150000, location: 'Toledo, OH', avatar: 'JD' },
  { id: 2, name: 'Mike R.', status: 'available', rating: 4.9, miles: 230000, location: 'Houston, TX', avatar: 'MR' },
  { id: 3, name: 'Sarah K.', status: 'off_duty', rating: 4.7, miles: 89000, location: 'Atlanta, GA', avatar: 'SK' },
  { id: 4, name: 'David K.', status: 'on_duty', rating: 4.6, miles: 175000, location: 'Castle Rock, CO', avatar: 'DK' }
];

const AI_SUGGESTIONS = [
  { type: 'load', message: 'High-paying load available: $3.45/mile from your current location', priority: 'high' },
  { type: 'route', message: 'Traffic alert on I-94. Alternative route saves 23 minutes.', priority: 'medium' },
  { type: 'maintenance', message: 'Vehicle FL-2022-001 due for oil change in 500 miles', priority: 'low' }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'in_transit': return 'blue';
    case 'delivered': return 'green';
    case 'pending': return 'yellow';
    case 'on_duty': return 'blue';
    case 'available': return 'green';
    case 'off_duty': return 'gray';
    default: return 'gray';
  }
};

const getStatusText = (status: string) => {
  return status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
};

export default function DemoPage() {
  const [activeTab, setActiveTab] = useState(0);
  const [isListening, setIsListening] = useState(false);
  const [aiResponse, setAiResponse] = useState('');
  const bgColor = useColorModeValue('gray.50', 'gray.900');
  const cardBg = useColorModeValue('white', 'gray.800');

  const handleVoiceCommand = () => {
    setIsListening(true);
    setTimeout(() => {
      setIsListening(false);
      setAiResponse('I found 3 loads within 50 miles. The best option pays $3.45/mile going to Detroit. Would you like me to book it?');
    }, 2000);
  };

  return (
    <Box minH="100vh" bg={bgColor}>
      <Head>
        <title>Infamous Freight - Live Demo</title>
        <meta name="description" content="Experience the future of freight management with our interactive demo" />
      </Head>

      {/* Demo Banner */}
      <Box bgGradient="linear(to-r, blue.600, purple.600)" color="white" py={3} px={4} textAlign="center">
        <Text fontSize="sm" fontWeight="medium">
          🎉 This is a live demo environment with sample data.{" "}
          <Link href="/signup" color="blue.200" textDecoration="underline" _hover={{ color: 'blue.100' }}>
            Start your free trial →
          </Link>
        </Text>
      </Box>

      {/* Header */}
      <Box bg={cardBg} borderBottom="1px" borderColor="gray.200" position="sticky" top={0} zIndex={50}>
        <Container maxW="7xl">
          <Flex justify="space-between" align="center" h={16}>
            <Flex align="center" gap={4}>
              <Flex align="center" gap={2}>
                <Icon as={Truck} boxSize={8} color="blue.600" />
                <Heading size="md">Infamous Freight</Heading>
              </Flex>
              <Badge colorScheme="blue" variant="solid">Demo</Badge>
            </Flex>
            
            <Tabs index={activeTab} onChange={setActiveTab} variant="line" colorScheme="blue">
              <TabList>
                <Tab>Dashboard</Tab>
                <Tab>Shipments</Tab>
                <Tab>Drivers</Tab>
                <Tab>Analytics</Tab>
              </TabList>
            </Tabs>

            <Button
              leftIcon={<Mic size={16} />}
              colorScheme={isListening ? 'red' : 'blue'}
              onClick={handleVoiceCommand}
              isLoading={isListening}
              loadingText="Listening..."
            >
              {isListening ? 'Listening...' : 'Voice Command'}
            </Button>
          </Flex>
        </Container>
      </Box>

      {/* AI Response */}
      {aiResponse && (
        <Container maxW="7xl" mt={6}>
          <Alert status="info" variant="subtle" borderRadius="lg">
            <AlertIcon as={Zap} color="purple.500" />
            <Box flex="1">
              <AlertTitle>Genesis AI</AlertTitle>
              <AlertDescription>{aiResponse}</AlertDescription>
            </Box>
            <IconButton
              aria-label="Close"
              icon={<Box>×</Box>}
              size="sm"
              variant="ghost"
              onClick={() => setAiResponse('')}
            />
          </Alert>
        </Container>
      )}

      {/* Main Content */}
      <Container maxW="7xl" py={8}>
        <TabPanels index={activeTab}>
          {/* Dashboard Tab */}
          <TabPanel p={0}>
            <VStack spacing={8} align="stretch">
              {/* Stats Grid */}
              <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
                <Card bg={cardBg}>
                  <CardBody>
                    <Stat>
                      <Flex justify="space-between" align="center">
                        <Box>
                          <StatLabel color="gray.500">Active Shipments</StatLabel>
                          <StatNumber fontSize="3xl">{DEMO_STATS.activeShipments}</StatNumber>
                        </Box>
                        <Box p={3} bg="blue.100" borderRadius="lg">
                          <Icon as={Package} boxSize={6} color="blue.600" />
                        </Box>
                      </Flex>
                      <StatHelpText>
                        <StatArrow type="increase" />
                        12% vs last month
                      </StatHelpText>
                    </Stat>
                  </CardBody>
                </Card>

                <Card bg={cardBg}>
                  <CardBody>
                    <Stat>
                      <Flex justify="space-between" align="center">
                        <Box>
                          <StatLabel color="gray.500">Monthly Revenue</StatLabel>
                          <StatNumber fontSize="3xl">${DEMO_STATS.revenueThisMonth.toLocaleString()}</StatNumber>
                        </Box>
                        <Box p={3} bg="green.100" borderRadius="lg">
                          <Icon as={DollarSign} boxSize={6} color="green.600" />
                        </Box>
                      </Flex>
                      <StatHelpText>
                        <StatArrow type="increase" />
                        23% vs last month
                      </StatHelpText>
                    </Stat>
                  </CardBody>
                </Card>

                <Card bg={cardBg}>
                  <CardBody>
                    <Stat>
                      <Flex justify="space-between" align="center">
                        <Box>
                          <StatLabel color="gray.500">Available Drivers</StatLabel>
                          <StatNumber fontSize="3xl">{DEMO_STATS.availableDrivers}</StatNumber>
                        </Box>
                        <Box p={3} bg="purple.100" borderRadius="lg">
                          <Icon as={Users} boxSize={6} color="purple.600" />
                        </Box>
                      </Flex>
                      <StatHelpText>
                        <Icon as={CheckCircle} boxSize={3} color="green.500" mr={1} />
                        All HOS compliant
                      </StatHelpText>
                    </Stat>
                  </CardBody>
                </Card>

                <Card bg={cardBg}>
                  <CardBody>
                    <Stat>
                      <Flex justify="space-between" align="center">
                        <Box>
                          <StatLabel color="gray.500">Avg Driver Rating</StatLabel>
                          <StatNumber fontSize="3xl">{DEMO_STATS.averageRating}</StatNumber>
                        </Box>
                        <Box p={3} bg="yellow.100" borderRadius="lg">
                          <Icon as={Star} boxSize={6} color="yellow.600" />
                        </Box>
                      </Flex>
                      <StatHelpText>Based on 127 reviews</StatHelpText>
                    </Stat>
                  </CardBody>
                </Card>
              </SimpleGrid>

              {/* AI Suggestions */}
              <Card bg={cardBg}>
                <CardHeader>
                  <Flex align="center" gap={2}>
                    <Icon as={Zap} color="purple.500" />
                    <Heading size="md">AI-Powered Insights</Heading>
                  </Flex>
                </CardHeader>
                <CardBody>
                  <Stack spacing={3}>
                    {AI_SUGGESTIONS.map((suggestion, index) => (
                      <Alert
                        key={index}
                        status={suggestion.priority === 'high' ? 'error' : suggestion.priority === 'medium' ? 'warning' : 'info'}
                        variant="left-accent"
                        borderRadius="md"
                      >
                        <AlertIcon as={AlertCircle} />
                        <Box flex="1">
                          <Text>{suggestion.message}</Text>
                        </Box>
                        <Button size="sm" colorScheme="blue" variant="ghost">
                          {suggestion.type === 'load' ? 'View Load' : suggestion.type === 'route' ? 'View Route' : 'Schedule'}
                        </Button>
                      </Alert>
                    ))}
                  </Stack>
                </CardBody>
              </Card>

              {/* Active Shipments */}
              <Card bg={cardBg}>
                <CardHeader>
                  <Flex justify="space-between" align="center">
                    <Heading size="md">Active Shipments</Heading>
                    <Button variant="link" colorScheme="blue">View All</Button>
                  </Flex>
                </CardHeader>
                <CardBody>
                  <Stack spacing={4}>
                    {DEMO_SHIPMENTS.filter(s => s.status !== 'delivered').map((shipment) => (
                      <Box
                        key={shipment.id}
                        p={4}
                        borderWidth="1px"
                        borderRadius="lg"
                        borderColor="gray.200"
                        _hover={{ bg: 'gray.50' }}
                      >
                        <Flex justify="space-between" align="center">
                          <Box flex={1}>
                            <Flex align="center" gap={3} mb={2}>
                              <Text fontWeight="bold">{shipment.id}</Text>
                              <Badge colorScheme={getStatusColor(shipment.status)}>
                                {getStatusText(shipment.status)}
                              </Badge>
                            </Flex>
                            <Flex gap={6} fontSize="sm" color="gray.600" wrap="wrap">
                              <Flex align="center" gap={1}>
                                <Icon as={MapPin} boxSize={4} />
                                {shipment.origin} → {shipment.destination}
                              </Flex>
                              <Flex align="center" gap={1}>
                                <Icon as={Truck} boxSize={4} />
                                {shipment.driver}
                              </Flex>
                              <Flex align="center" gap={1}>
                                <Icon as={DollarSign} boxSize={4} />
                                ${shipment.rate}
                              </Flex>
                              <Flex align="center" gap={1}>
                                <Icon as={Navigation} boxSize={4} />
                                {shipment.distance} miles
                              </Flex>
                            </Flex>
                          </Box>
                          <Box w="32">
                            <Flex justify="space-between" fontSize="xs" color="gray.500" mb={1}>
                              <Text>Progress</Text>
                              <Text>{shipment.progress}%</Text>
                            </Flex>
                            <Progress value={shipment.progress} size="sm" colorScheme="blue" borderRadius="full" />
                          </Box>
                        </Flex>
                      </Box>
                    ))}
                  </Stack>
                </CardBody>
              </Card>
            </VStack>
          </TabPanel>

          {/* Shipments Tab */}
          <TabPanel p={0}>
            <Card bg={cardBg}>
              <CardHeader>
                <Heading size="md">All Shipments</Heading>
              </CardHeader>
              <CardBody>
                <Table variant="simple">
                  <Thead>
                    <Tr>
                      <Th>ID</Th>
                      <Th>Shipper</Th>
                      <Th>Route</Th>
                      <Th>Status</Th>
                      <Th>Rate</Th>
                      <Th>Actions</Th>
                    </Tr>
                  </Thead>
                  <Tbody>
                    {DEMO_SHIPMENTS.map((shipment) => (
                      <Tr key={shipment.id} _hover={{ bg: 'gray.50' }}>
                        <Td fontWeight="medium">{shipment.id}</Td>
                        <Td>{shipment.shipper}</Td>
                        <Td>{shipment.origin} → {shipment.destination}</Td>
                        <Td>
                          <Badge colorScheme={getStatusColor(shipment.status)}>
                            {getStatusText(shipment.status)}
                          </Badge>
                        </Td>
                        <Td>${shipment.rate}</Td>
                        <Td>
                          <Button size="sm" variant="link" colorScheme="blue">
                            View Details
                          </Button>
                        </Td>
                      </Tr>
                    ))}
                  </Tbody>
                </Table>
              </CardBody>
            </Card>
          </TabPanel>

          {/* Drivers Tab */}
          <TabPanel p={0}>
            <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
              {DEMO_DRIVERS.map((driver) => (
                <Card key={driver.id} bg={cardBg}>
                  <CardBody>
                    <Flex align="center" gap={4} mb={4}>
                      <Avatar name={driver.avatar} size="lg" bg="blue.500" />
                      <Box>
                        <Heading size="sm">{driver.name}</Heading>
                        <Badge colorScheme={getStatusColor(driver.status)} mt={1}>
                          {getStatusText(driver.status)}
                        </Badge>
                      </Box>
                    </Flex>
                    <Stack spacing={2} fontSize="sm" color="gray.600">
                      <Flex align="center" gap={2}>
                        <Icon as={Star} boxSize={4} color="yellow.500" />
                        Rating: {driver.rating}/5.0
                      </Flex>
                      <Flex align="center" gap={2}>
                        <Icon as={Activity} boxSize={4} color="blue.500" />
                        {driver.miles.toLocaleString()} miles driven
                      </Flex>
                      <Flex align="center" gap={2}>
                        <Icon as={MapPin} boxSize={4} color="green.500" />
                        {driver.location}
                      </Flex>
                    </Stack>
                  </CardBody>
                </Card>
              ))}
            </SimpleGrid>
          </TabPanel>

          {/* Analytics Tab */}
          <TabPanel p={0}>
            <VStack spacing={6} align="stretch">
              <Card bg={cardBg}>
                <CardHeader>
                  <Heading size="md">Revenue Analytics</Heading>
                </CardHeader>
                <CardBody>
                  <Flex align="end" justify="around" h="64" gap={2}>
                    {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'].map((month, index) => (
                      <Box key={month} textAlign="center" flex={1}>
                        <Box
                          bg="blue.600"
                          borderTopRadius="md"
                          transition="all 0.3s"
                          _hover={{ bg: 'blue.700' }}
                          h={`${(index + 1) * 40 + 60}px`}
                        />
                        <Text fontSize="sm" color="gray.500" mt={2}>{month}</Text>
                      </Box>
                    ))}
                  </Flex>
                </CardBody>
              </Card>

              <SimpleGrid columns={{ base: 1, md: 2 }} spacing={6}>
                <Card bg={cardBg}>
                  <CardHeader>
                    <Heading size="md">Performance Metrics</Heading>
                  </CardHeader>
                  <CardBody>
                    <Stack spacing={4}>
                      <Box>
                        <Flex justify="space-between" fontSize="sm" mb={1}>
                          <Text color="gray.500">On-Time Delivery</Text>
                          <Text fontWeight="medium">94%</Text>
                        </Flex>
                        <Progress value={94} size="sm" colorScheme="green" borderRadius="full" />
                      </Box>
                      <Box>
                        <Flex justify="space-between" fontSize="sm" mb={1}>
                          <Text color="gray.500">Customer Satisfaction</Text>
                          <Text fontWeight="medium">4.8/5</Text>
                        </Flex>
                        <Progress value={96} size="sm" colorScheme="blue" borderRadius="full" />
                      </Box>
                      <Box>
                        <Flex justify="space-between" fontSize="sm" mb={1}>
                          <Text color="gray.500">Fleet Utilization</Text>
                          <Text fontWeight="medium">87%</Text>
                        </Flex>
                        <Progress value={87} size="sm" colorScheme="purple" borderRadius="full" />
                      </Box>
                    </Stack>
                  </CardBody>
                </Card>

                <Card bg={cardBg}>
                  <CardHeader>
                    <Heading size="md">Cost Breakdown</Heading>
                  </CardHeader>
                  <CardBody>
                    <Stack spacing={3}>
                      {[
                        { label: 'Fuel', value: '42%', color: 'blue.500' },
                        { label: 'Driver Pay', value: '35%', color: 'green.500' },
                        { label: 'Maintenance', value: '12%', color: 'yellow.500' },
                        { label: 'Insurance', value: '8%', color: 'red.500' },
                        { label: 'Other', value: '3%', color: 'gray.500' }
                      ].map((item) => (
                        <Flex key={item.label} justify="space-between" align="center">
                          <Flex align="center" gap={2}>
                            <Box w={3} h={3} borderRadius="full" bg={item.color} />
                            <Text fontSize="sm" color="gray.600">{item.label}</Text>
                          </Flex>
                          <Text fontWeight="medium">{item.value}</Text>
                        </Flex>
                      ))}
                    </Stack>
                  </CardBody>
                </Card>
              </SimpleGrid>
            </VStack>
          </TabPanel>
        </TabPanels>
      </Container>

      {/* CTA Section */}
      <Box bg="gray.900" color="white" py={16}>
        <Container maxW="7xl" textAlign="center">
          <Heading size="xl" mb={4}>Ready to Transform Your Freight Operations?</Heading>
          <Text fontSize="xl" color="gray.300" mb={8} maxW="2xl" mx="auto">
            Join thousands of carriers and drivers already using Infamous Freight to maximize profitability.
          </Text>
          <Flex justify="center" gap={4} wrap="wrap">
            <Button
              as={Link}
              href="/signup"
              size="lg"
              colorScheme="blue"
              rightIcon={<ArrowRight size={20} />}
            >
              Start Free Trial
            </Button>
            <Button
              as={Link}
              href="/contact"
              size="lg"
              variant="outline"
              borderColor="white"
              color="white"
              _hover={{ bg: 'white', color: 'gray.900' }}
            >
              Talk to Sales
            </Button>
          </Flex>
          <Text fontSize="sm" color="gray.400" mt={4}>No credit card required. 14-day free trial.</Text>
        </Container>
      </Box>
    </Box>
  );
}
