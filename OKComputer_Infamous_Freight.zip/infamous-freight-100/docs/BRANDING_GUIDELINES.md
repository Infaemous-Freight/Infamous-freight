# Infamous Freight Branding Guidelines

## Official Brand Standards

---

## Brand Name

### ✅ Correct Usage

**Primary Name**: `Infamous Freight`

- Capital "I" in Infamous
- Capital "F" in Freight
- No special characters

### ❌ Incorrect Usage

| Incorrect | Reason |
|-----------|--------|
| `infamous freight` | All lowercase |
| `INFAMOUS FREIGHT` | All uppercase |
| `Infamous-Freight` | Hyphenated |
| `InfamousFreight` | No space |
| `Infamous Freight Enterprises` | Old company name |
| `Infamous Freight Enterprises LLC` | Old legal name |

---

## Brand Assets

### Logo Colors
- Primary Blue: `#2563EB`
- Dark Blue: `#1E40AF`
- Accent Purple: `#7C3AED`

### Typography
- **Primary Font**: Inter
- **Monospace Font**: JetBrains Mono

### Color Palette

| Color | Hex | Usage |
|-------|-----|-------|
| Primary Blue | `#2563EB` | Buttons, links |
| Dark Blue | `#1E40AF` | Headers |
| Accent Purple | `#7C3AED` | AI features |
| Success Green | `#10B981` | Success states |
| Warning Yellow | `#F59E0B` | Warnings |
| Error Red | `#EF4444` | Errors |

---

## Brand Voice

### Tone
- Professional but approachable
- Confident
- Innovative
- Empathetic

### Taglines
**Primary**: "The AI-Native Freight Intelligence Platform"

**Secondary**:
- "Maximize Profitability. Minimize Complexity."
- "The Operating System for Freight"
- "73% Faster Than Legacy TMS"

---

## Code & Technical

### Package Names

```json
{
  "name": "@infamous-freight/shared",
  "name": "@infamous-freight/api",
  "name": "@infamous-freight/web",
  "name": "@infamous-freight/mobile"
}
```

### Environment Variables

```bash
INFAMOUS_FREIGHT_API_URL=https://api.infamousfreight.com
INFAMOUS_FREIGHT_API_KEY=xxx
```

### Docker Images

```bash
ghcr.io/infamous-freight/api:latest
ghcr.io/infamous-freight/web:latest
```

---

## Domain Names

### Primary Domains

| Domain | Purpose | Status |
|--------|---------|--------|
| `infamousfreight.com` | Primary website | ✅ Active |
| `infamousfreight.io` | API & developer docs | ✅ Active |
| `infamousfreight.app` | Mobile app deep links | ✅ Active |

---

## Contact

- **Brand Questions**: marketing@infamousfreight.com
- **Legal/Trademark**: legal@infamousfreight.com

---

*© 2025 Infamous Freight. All Rights Reserved.*
