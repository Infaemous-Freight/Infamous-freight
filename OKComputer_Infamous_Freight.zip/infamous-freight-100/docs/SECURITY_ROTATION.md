# Security Advisory: Deploy Key Rotation

## ⚠️ URGENT: Deploy Key Exposed

**Date**: February 24, 2025  
**Severity**: HIGH  
**Status**: Action Required

---

## Summary

A deploy key was exposed in documentation. This key must be rotated immediately.

---

## Immediate Actions Required

### Step 1: Revoke the Exposed Key (URGENT)

1. Go to GitHub Repository Settings
2. Navigate to **Deploy keys**
3. Find and delete the exposed key

### Step 2: Generate New Deploy Key

```bash
# Generate new SSH key pair
ssh-keygen -t ed25519 -a 100 -f infamous-freight-deploy-key -C "deploy@infamousfreight.com"
```

### Step 3: Add New Key to GitHub

1. Go to GitHub Repository Settings → Deploy keys
2. Click **Add deploy key**
3. Paste the public key contents
4. Enable **Allow write access** if needed

### Step 4: Update GitHub Secrets

```bash
# Add new private key to GitHub Secrets
gh secret set DEPLOY_PRIVATE_KEY < infamous-freight-deploy-key
```

### Step 5: Update CI/CD Workflows

Update `.github/workflows/ci-cd.yml`:

```yaml
- name: Setup SSH
  uses: webfactory/ssh-agent@v0.9.0
  with:
    ssh-private-key: ${{ secrets.DEPLOY_PRIVATE_KEY }}
```

### Step 6: Verify Deployment

```bash
# Trigger test deployment
gh workflow run ci-cd.yml --ref main
gh run watch
```

---

## Prevention Measures

### Pre-commit Hooks

Add to `.husky/pre-commit`:

```bash
#!/bin/sh
# Scan for SSH keys
if git diff --cached --name-only | xargs grep -l "ssh-rsa\|ssh-ed25519\|BEGIN OPENSSH PRIVATE KEY" 2>/dev/null; then
  echo "ERROR: Potential SSH key detected in commit!"
  exit 1
fi
```

### GitHub Secret Scanning

Enable in Repository Settings → Security → Secret scanning

---

## Contact

- **Security Team**: security@infamousfreight.com
- **Emergency**: +1-555-SECURITY

---

*Last Updated: February 24, 2025*
