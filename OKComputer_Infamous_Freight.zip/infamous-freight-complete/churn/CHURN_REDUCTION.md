# Churn Reduction Strategy

## Reduce Monthly Churn from 6% to <3%

---

## Current State Analysis

| Metric | Current | Target | Impact |
|--------|---------|--------|--------|
| Monthly Churn | 6% | <3% | +50% retention |
| Annual Churn | 52% | 30% | +$500K ARR |
| Activation Rate (7-day) | 45% | 80% | +35 points |
| NPS Score | 45 | 70 | +25 points |

---

## 1. Onboarding Flow (Activation)

### Goal: 80% of users complete key actions within 7 days

### Onboarding Steps

```
Step 1: Welcome (Day 0)
  ↓ Complete profile (90% target)
Step 2: First Load Search (Day 0-1)
  ↓ Use AI load finder (70% target)
Step 3: First Shipment Created (Day 1-3)
  ↓ Create shipment (50% target)
Step 4: First Invoice Sent (Day 3-7)
  ↓ Send invoice (40% target)
Step 5: Value Realized (Day 7)
  ↓ Complete onboarding (80% target)
```

### Implementation

#### Onboarding Service

```typescript
// apps/api/src/services/onboarding.service.ts

interface OnboardingStep {
  id: string;
  name: string;
  description: string;
  action: string;
  completed: boolean;
  completedAt?: Date;
}

const ONBOARDING_STEPS: OnboardingStep[] = [
  {
    id: 'profile_complete',
    name: 'Complete Your Profile',
    description: 'Add your truck details and preferences',
    action: '/onboarding/profile',
    completed: false
  },
  {
    id: 'first_load_search',
    name: 'Find Your First Load',
    description: 'Use AI to find the best-paying loads',
    action: '/loads/search',
    completed: false
  },
  {
    id: 'first_shipment',
    name: 'Create a Shipment',
    description: 'Track your first load with our system',
    action: '/shipments/new',
    completed: false
  },
  {
    id: 'first_invoice',
    name: 'Send Your First Invoice',
    description: 'Get paid faster with automated invoicing',
    action: '/invoices/new',
    completed: false
  },
  {
    id: 'value_realized',
    name: 'You're All Set!',
    description: 'Start maximizing your profits',
    action: '/dashboard',
    completed: false
  }
];

export class OnboardingService {
  async getOnboardingProgress(userId: string): Promise<{
    steps: OnboardingStep[];
    progress: number;
    isComplete: boolean;
  }> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { onboardingProgress: true }
    });

    const steps = ONBOARDING_STEPS.map(step => ({
      ...step,
      completed: user.onboardingProgress?.completedSteps?.includes(step.id) || false,
      completedAt: user.onboardingProgress?.stepTimestamps?.[step.id]
    }));

    const completedCount = steps.filter(s => s.completed).length;
    const progress = (completedCount / steps.length) * 100;

    return {
      steps,
      progress,
      isComplete: progress === 100
    };
  }

  async completeStep(userId: string, stepId: string): Promise<void> {
    await prisma.onboardingProgress.upsert({
      where: { userId },
      create: {
        userId,
        completedSteps: [stepId],
        stepTimestamps: { [stepId]: new Date() }
      },
      update: {
        completedSteps: { push: stepId },
        stepTimestamps: { [stepId]: new Date() }
      }
    });

    // Check if onboarding is complete
    const progress = await this.getOnboardingProgress(userId);
    if (progress.isComplete) {
      await this.onOnboardingComplete(userId);
    }
  }

  private async onOnboardingComplete(userId: string): Promise<void> {
    // Send congratulations email
    await emailService.send({
      to: userId,
      template: 'onboarding-complete',
      data: {
        reward: '$25 account credit'
      }
    });

    // Grant reward
    await prisma.user.update({
      where: { id: userId },
      data: { accountCredits: { increment: 25 } }
    });

    // Track event
    analytics.track('Onboarding Completed', { userId });
  }

  async sendNudges(): Promise<void> {
    // Find users who haven't completed onboarding
    const incompleteUsers = await prisma.user.findMany({
      where: {
        createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
        onboardingProgress: {
          isComplete: false
        }
      },
      include: { onboardingProgress: true }
    });

    for (const user of incompleteUsers) {
      const daysSinceSignup = Math.floor(
        (Date.now() - user.createdAt.getTime()) / (24 * 60 * 60 * 1000)
      );

      // Send contextual nudges based on progress
      if (daysSinceSignup === 1 && !user.onboardingProgress?.completedSteps?.includes('profile_complete')) {
        await this.sendNudge(user, 'complete-profile');
      } else if (daysSinceSignup === 3 && !user.onboardingProgress?.completedSteps?.includes('first_load_search')) {
        await this.sendNudge(user, 'first-load-search');
      } else if (daysSinceSignup === 5 && !user.onboardingProgress?.completedSteps?.includes('first_shipment')) {
        await this.sendNudge(user, 'first-shipment');
      }
    }
  }

  private async sendNudge(user: User, type: string): Promise<void> {
    await emailService.send({
      to: user.id,
      template: `nudge-${type}`,
      data: {
        firstName: user.name?.split(' ')[0],
        progress: await this.getOnboardingProgress(user.id)
      }
    });
  }
}
```

#### Onboarding UI Component

```tsx
// apps/web/components/OnboardingWizard.tsx

export function OnboardingWizard() {
  const { user } = useAuth();
  const [progress, setProgress] = useState<OnboardingProgress | null>(null);
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    fetchOnboardingProgress().then(setProgress);
  }, []);

  if (!progress) return <Skeleton height="400px" />;
  if (progress.isComplete) return null;

  const currentStepData = progress.steps[currentStep];

  return (
    <Card borderColor="blue.500" borderWidth={2}>
      <CardHeader bg="blue.50">
        <VStack align="stretch" spacing={2}>
          <Flex justify="space-between" align="center">
            <Heading size="md">Welcome to Infamous Freight!</Heading>
            <Badge colorScheme="blue">{Math.round(progress.progress)}% Complete</Badge>
          </Flex>
          <Progress value={progress.progress} size="sm" colorScheme="blue" />
        </VStack>
      </CardHeader>
      <CardBody>
        <VStack spacing={6} align="stretch">
          {/* Step List */}
          <SimpleGrid columns={5} spacing={2}>
            {progress.steps.map((step, index) => (
              <Box
                key={step.id}
                p={2}
                textAlign="center"
                borderRadius="md"
                bg={step.completed ? 'green.100' : index === currentStep ? 'blue.100' : 'gray.100'}
                cursor={step.completed ? 'default' : 'pointer'}
                onClick={() => !step.completed && setCurrentStep(index)}
              >
                <Icon
                  as={step.completed ? CheckCircle : index === currentStep ? Play : Circle}
                  color={step.completed ? 'green.500' : index === currentStep ? 'blue.500' : 'gray.400'}
                />
                <Text fontSize="xs" mt={1}>{step.name}</Text>
              </Box>
            ))}
          </SimpleGrid>

          {/* Current Step */}
          <Box p={6} bg="gray.50" borderRadius="lg">
            <VStack spacing={4} align="stretch">
              <Heading size="lg">{currentStepData.name}</Heading>
              <Text color="gray.600">{currentStepData.description}</Text>
              
              {currentStepData.id === 'profile_complete' && <ProfileForm />}
              {currentStepData.id === 'first_load_search' && <LoadSearchDemo />}
              {currentStepData.id === 'first_shipment' && <ShipmentForm />}
              {currentStepData.id === 'first_invoice' && <InvoiceForm />}
              {currentStepData.id === 'value_realized' && <ValueCelebration />}
            </VStack>
          </Box>

          {/* Navigation */}
          <Flex justify="space-between">
            <Button
              variant="ghost"
              isDisabled={currentStep === 0}
              onClick={() => setCurrentStep(currentStep - 1)}
            >
              Previous
            </Button>
            <Button
              colorScheme="blue"
              onClick={() => {
                completeStep(currentStepData.id);
                if (currentStep < progress.steps.length - 1) {
                  setCurrentStep(currentStep + 1);
                }
              }}
            >
              {currentStep === progress.steps.length - 1 ? 'Get Started' : 'Next'}
            </Button>
          </Flex>
        </VStack>
      </CardBody>
    </Card>
  );
}
```

---

## 2. Health Scoring (Churn Prediction)

### Goal: Predict churn 30 days before it happens

### Health Score Model

```typescript
// apps/api/src/services/healthScore.service.ts

interface HealthScoreFactors {
  loginFrequency: number;      // 25% weight
  featureUsage: number;        // 25% weight
  dataCompleteness: number;    // 15% weight
  supportTickets: number;      // 15% weight
  paymentHistory: number;      // 10% weight
  engagementTrend: number;     // 10% weight
}

interface HealthScore {
  score: number; // 0-100
  risk: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  factors: HealthScoreFactors;
  recommendations: string[];
}

export class HealthScoreService {
  async calculateHealthScore(userId: string): Promise<HealthScore> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        shipments: true,
        invoices: true,
        activityLogs: true,
        supportTickets: true
      }
    });

    const factors: HealthScoreFactors = {
      loginFrequency: this.calculateLoginFrequency(user),
      featureUsage: this.calculateFeatureUsage(user),
      dataCompleteness: this.calculateDataCompleteness(user),
      supportTickets: this.calculateSupportScore(user),
      paymentHistory: this.calculatePaymentScore(user),
      engagementTrend: this.calculateEngagementTrend(user)
    };

    const score = this.weightedScore(factors);
    const risk = this.scoreToRisk(score);
    const recommendations = this.generateRecommendations(factors);

    // Store health score
    await prisma.healthScore.create({
      data: {
        userId,
        score,
        risk,
        factors,
        recommendations,
        calculatedAt: new Date()
      }
    });

    // Trigger alerts for at-risk users
    if (risk === 'HIGH' || risk === 'CRITICAL') {
      await this.triggerChurnPrevention(userId, score, risk);
    }

    return { score, risk, factors, recommendations };
  }

  private calculateLoginFrequency(user: User): number {
    const last30Days = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const logins = user.activityLogs.filter(
      log => log.type === 'LOGIN' && log.createdAt >= last30Days
    ).length;
    
    // Score: 0-10 logins = 0-100
    return Math.min(logins * 10, 100);
  }

  private calculateFeatureUsage(user: User): number {
    const features = new Set();
    
    // Check which features they've used
    if (user.shipments.length > 0) features.add('shipments');
    if (user.invoices.length > 0) features.add('invoices');
    if (user.activityLogs.some(l => l.type === 'AI_COMMAND')) features.add('ai');
    if (user.activityLogs.some(l => l.type === 'VOICE_COMMAND')) features.add('voice');
    if (user.activityLogs.some(l => l.type === 'REPORT_VIEWED')) features.add('reports');
    
    // Score based on feature diversity
    return (features.size / 5) * 100;
  }

  private calculateDataCompleteness(user: User): number {
    const requiredFields = ['name', 'email', 'phone', 'company'];
    const completedFields = requiredFields.filter(field => user[field]).length;
    
    return (completedFields / requiredFields.length) * 100;
  }

  private calculateSupportScore(user: User): number {
    const openTickets = user.supportTickets.filter(t => t.status === 'OPEN').length;
    
    // Penalize for open tickets
    return Math.max(100 - openTickets * 20, 0);
  }

  private calculatePaymentScore(user: User): number {
    const failedPayments = user.invoices.filter(i => i.paymentStatus === 'FAILED').length;
    
    return Math.max(100 - failedPayments * 25, 0);
  }

  private calculateEngagementTrend(user: User): number {
    const last7Days = user.activityLogs.filter(
      l => l.createdAt >= new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    ).length;
    
    const previous7Days = user.activityLogs.filter(
      l => l.createdAt >= new Date(Date.now() - 14 * 24 * 60 * 60 * 1000) &&
           l.createdAt < new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    ).length;
    
    if (previous7Days === 0) return last7Days > 0 ? 100 : 50;
    
    const trend = (last7Days / previous7Days) * 100;
    return Math.min(trend, 100);
  }

  private weightedScore(factors: HealthScoreFactors): number {
    return (
      factors.loginFrequency * 0.25 +
      factors.featureUsage * 0.25 +
      factors.dataCompleteness * 0.15 +
      factors.supportTickets * 0.15 +
      factors.paymentHistory * 0.10 +
      factors.engagementTrend * 0.10
    );
  }

  private scoreToRisk(score: number): 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' {
    if (score >= 80) return 'LOW';
    if (score >= 60) return 'MEDIUM';
    if (score >= 40) return 'HIGH';
    return 'CRITICAL';
  }

  private generateRecommendations(factors: HealthScoreFactors): string[] {
    const recommendations: string[] = [];
    
    if (factors.loginFrequency < 50) {
      recommendations.push('User has low login frequency - send re-engagement email');
    }
    if (factors.featureUsage < 40) {
      recommendations.push('User not using key features - offer product training');
    }
    if (factors.supportTickets < 60) {
      recommendations.push('User has open support tickets - prioritize resolution');
    }
    if (factors.engagementTrend < 70) {
      recommendations.push('Engagement declining - schedule check-in call');
    }
    
    return recommendations;
  }

  private async triggerChurnPrevention(userId: string, score: number, risk: string): Promise<void> {
    // Send to customer success team
    await slack.notify({
      channel: '#customer-success',
      text: `🚨 At-risk customer: ${userId}`,
      attachments: [{
        fields: [
          { title: 'Health Score', value: score, short: true },
          { title: 'Risk Level', value: risk, short: true }
        ]
      }]
    });

    // Send personalized retention email
    await emailService.send({
      to: userId,
      template: 'retention-checkin',
      data: { score, risk }
    });

    // Create task for CSM
    await prisma.task.create({
      data: {
        type: 'CHURN_PREVENTION',
        userId,
        priority: risk === 'CRITICAL' ? 'HIGH' : 'MEDIUM',
        dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000)
      }
    });
  }
}
```

### Health Score Dashboard

```tsx
// apps/web/components/HealthScoreWidget.tsx

export function HealthScoreWidget({ userId }: { userId: string }) {
  const [healthScore, setHealthScore] = useState<HealthScore | null>(null);

  useEffect(() => {
    fetchHealthScore(userId).then(setHealthScore);
  }, [userId]);

  if (!healthScore) return <Skeleton height="200px" />;

  const riskColors = {
    LOW: 'green',
    MEDIUM: 'yellow',
    HIGH: 'orange',
    CRITICAL: 'red'
  };

  return (
    <Card>
      <CardHeader>
        <Flex justify="space-between" align="center">
          <Heading size="md">Customer Health Score</Heading>
          <Badge colorScheme={riskColors[healthScore.risk]} size="lg">
            {healthScore.risk} RISK
          </Badge>
        </Flex>
      </CardHeader>
      <CardBody>
        <VStack spacing={4} align="stretch">
          {/* Score Gauge */}
          <Box textAlign="center" py={4}>
            <CircularProgress
              value={healthScore.score}
              size="120px"
              thickness="8px"
              color={riskColors[healthScore.risk] + '.500'}
            >
              <CircularProgressLabel fontSize="2xl" fontWeight="bold">
                {Math.round(healthScore.score)}
              </CircularProgressLabel>
            </CircularProgress>
          </Box>

          {/* Factor Breakdown */}
          <VStack spacing={2} align="stretch">
            {Object.entries(healthScore.factors).map(([factor, value]) => (
              <Box key={factor}>
                <Flex justify="space-between" fontSize="sm">
                  <Text textTransform="capitalize">{factor.replace(/([A-Z])/g, ' $1')}</Text>
                  <Text fontWeight="medium">{Math.round(value)}/100</Text>
                </Flex>
                <Progress value={value} size="sm" colorScheme={value > 60 ? 'green' : 'red'} />
              </Box>
            ))}
          </VStack>

          {/* Recommendations */}
          {healthScore.recommendations.length > 0 && (
            <Alert status="warning">
              <AlertIcon />
              <Box>
                <AlertTitle>Recommended Actions</AlertTitle>
                <VStack align="start" mt={2}>
                  {healthScore.recommendations.map((rec, i) => (
                    <Text key={i} fontSize="sm">• {rec}</Text>
                  ))}
                </VStack>
              </Box>
            </Alert>
          )}
        </VStack>
      </CardBody>
    </Card>
  );
}
```

---

## 3. Win-Back Campaign

### Goal: Re-activate 15% of churned customers

### Campaign Flow

```
Day 0: Churn detected
  ↓
Day 1: "We miss you" email
  ↓ (no response)
Day 3: "What's holding you back?" survey
  ↓ (no response)
Day 7: "50% off for 3 months" offer
  ↓ (no response)
Day 14: Personal outreach from CSM
  ↓ (no response)
Day 30: "Your data will be deleted" final notice
```

### Implementation

```typescript
// apps/api/src/services/winback.service.ts

export class WinBackService {
  async startWinBackCampaign(userId: string): Promise<void> {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    
    // Schedule win-back sequence
    await this.scheduleEmail(userId, 'we-miss-you', 1);
    await this.scheduleEmail(userId, 'feedback-survey', 3);
    await this.scheduleEmail(userId, 'winback-offer', 7);
    await this.scheduleTask(userId, 'personal-outreach', 14);
    await this.scheduleEmail(userId, 'final-notice', 30);
  }

  async sendWinBackEmail(userId: string, type: string): Promise<void> {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    
    const templates: Record<string, EmailTemplate> = {
      'we-miss-you': {
        subject: 'We miss you at Infamous Freight',
        body: `Hi ${user.name},

We noticed you haven't logged in recently. Is everything okay?

We're here to help if you're facing any challenges. Reply to this email and let us know how we can assist.

Best,
The Infamous Freight Team`
      },
      'feedback-survey': {
        subject: 'Help us improve - 2 minute survey',
        body: `Hi ${user.name},

We'd love to understand what we could do better. Your feedback helps us improve.

[Take 2-Minute Survey]

As a thank you, we'll add $10 to your account.

Best,
The Infamous Freight Team`
      },
      'winback-offer': {
        subject: '50% off for 3 months - Come back to Infamous Freight',
        body: `Hi ${user.name},

We want you back! Here's an exclusive offer:

🎁 50% OFF for 3 months
🎁 Free onboarding session
🎁 Priority support

Use code: COMEBACK50

[Reactivate My Account]

This offer expires in 7 days.

Best,
The Infamous Freight Team`
      },
      'final-notice': {
        subject: 'Final notice: Your account will be deleted',
        body: `Hi ${user.name},

This is our final attempt to reach you. Your account and data will be permanently deleted in 7 days.

If you'd like to keep your account, simply log in:
[Log In Now]

If we don't hear from you, we'll proceed with account deletion as per our data retention policy.

Best,
The Infamous Freight Team`
      }
    };

    const template = templates[type];
    if (!template) return;

    await emailService.send({
      to: user.email,
      subject: template.subject,
      body: template.body
    });

    // Track send
    await prisma.winBackEmail.create({
      data: {
        userId,
        type,
        sentAt: new Date()
      }
    });
  }

  async processWinBackResponse(userId: string, response: string): Promise<void> {
    // Cancel remaining win-back emails
    await prisma.scheduledEmail.deleteMany({
      where: { userId, type: { startsWith: 'winback' } }
    });

    // Reactivate account
    await prisma.user.update({
      where: { id: userId },
      data: { status: 'ACTIVE', reactivatedAt: new Date() }
    });

    // Track reactivation
    analytics.track('Customer Reactivated', { userId, response });

    // Send welcome back email
    await emailService.send({
      to: userId,
      template: 'welcome-back',
      data: { response }
    });
  }
}
```

---

## 4. Annual Prepay Discount

### Goal: 20% of customers choose annual billing

### Implementation

```typescript
// apps/api/src/services/billing.service.ts

export class BillingService {
  async getPricingOptions(organizationId: string): Promise<PricingOption[]> {
    const org = await prisma.organization.findUnique({
      where: { id: organizationId }
    });

    const currentTier = PRICING_TIERS[org.pricingTier];

    return [
      {
        period: 'monthly',
        price: currentTier.basePrice,
        savings: 0,
        savingsPercent: 0
      },
      {
        period: 'annual',
        price: currentTier.basePrice * 10, // 2 months free
        savings: currentTier.basePrice * 2,
        savingsPercent: 17,
        badge: 'BEST VALUE'
      },
      {
        period: 'biennial',
        price: currentTier.basePrice * 18, // 6 months free
        savings: currentTier.basePrice * 6,
        savingsPercent: 25,
        badge: 'MAXIMUM SAVINGS'
      }
    ];
  }

  async upgradeToAnnual(userId: string): Promise<void> {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    
    // Apply discount
    await prisma.organization.update({
      where: { id: user.organizationId },
      data: {
        billingPeriod: 'ANNUAL',
        annualDiscountApplied: true
      }
    });

    // Grant immediate benefit
    await prisma.user.update({
      where: { id: userId },
      data: { accountCredits: { increment: 50 } }
    });

    // Send confirmation
    await emailService.send({
      to: userId,
      template: 'annual-upgrade-confirmation',
      data: {
        savings: '2 months free',
        credit: '$50 account credit'
      }
    });
  }
}
```

---

## Expected Impact

| Initiative | Churn Reduction | Revenue Impact |
|------------|-----------------|----------------|
| Onboarding Flow | -1.5% | +$150K ARR |
| Health Scoring | -1.0% | +$100K ARR |
| Win-Back Campaign | -0.5% | +$75K ARR |
| Annual Prepay | -0.5% | +$50K ARR |
| **Total** | **-3.5%** | **+$375K ARR** |

**New Monthly Churn: 2.5%** (vs current 6%)
**Annual Retention: 74%** (vs current 48%)

---

*Document Owner: Customer Success Team*  
*Last Updated: February 24, 2025*
