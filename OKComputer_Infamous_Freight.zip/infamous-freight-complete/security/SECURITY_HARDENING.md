# Security Hardening Guide

## Comprehensive Security Enhancements

---

## 1. Bug Bounty Program

### Program Setup

**Platform**: HackerOne or Bugcrowd  
**Budget**: $5,000/month  
**Scope**: *.infamousfreight.com, API, mobile apps

### Reward Structure

| Severity | Reward Range | Examples |
|----------|--------------|----------|
| Critical | $2,000 - $5,000 | RCE, SQL injection, auth bypass |
| High | $500 - $2,000 | XSS, IDOR, sensitive data exposure |
| Medium | $100 - $500 | CSRF, information disclosure |
| Low | $50 - $100 | Best practices, minor issues |

### Policy Template

```markdown
# Infamous Freight Bug Bounty Program

## Scope

### In Scope
- https://infamousfreight.com
- https://api.infamousfreight.com
- Mobile applications (iOS/Android)
- API endpoints

### Out of Scope
- Third-party services
- Social engineering
- Physical attacks
- DoS/DDoS attacks

## Rules
1. Do not access data that doesn't belong to you
2. Do not modify data without explicit permission
3. Report vulnerabilities within 24 hours of discovery
4. Allow 90 days for remediation before public disclosure

## Safe Harbor
We will not take legal action against researchers who:
- Follow this policy
- Report in good faith
- Do not cause harm

## Contact
security@infamousfreight.com
```

### Implementation

```typescript
// apps/api/src/routes/security.ts

import { Router } from 'express';

const router = Router();

// Security.txt (RFC 9116)
router.get('/.well-known/security.txt', (req, res) => {
  res.type('text/plain');
  res.send(`Contact: security@infamousfreight.com
Acknowledgments: https://infamousfreight.com/security/hall-of-fame
Policy: https://infamousfreight.com/security/policy
Preferred-Languages: en
Canonical: https://infamousfreight.com/.well-known/security.txt
`);
});

// Vulnerability report endpoint
router.post('/report', async (req, res) => {
  const { title, description, severity, steps, impact } = req.body;

  // Create security ticket
  const ticket = await prisma.securityTicket.create({
    data: {
      title,
      description,
      severity,
      steps,
      impact,
      status: 'NEW',
      reportedAt: new Date()
    }
  });

  // Notify security team
  await slack.notify({
    channel: '#security',
    text: `🔒 New security report: ${title}`,
    attachments: [{
      fields: [
        { title: 'Severity', value: severity, short: true },
        { title: 'Ticket', value: ticket.id, short: true }
      ]
    }]
  });

  // Send confirmation to reporter
  await emailService.send({
    to: req.body.reporterEmail,
    template: 'security-report-confirmation',
    data: { ticketId: ticket.id }
  });

  res.status(201).json({ ticketId: ticket.id });
});

export default router;
```

---

## 2. Web Application Firewall (WAF)

### Cloudflare WAF Rules

```yaml
# waf-rules.yaml

rules:
  # SQL Injection Protection
  - name: "SQL Injection"
    expression: |
      (http.request.uri.query contains "union select" or
       http.request.uri.query contains "' or '1'='1" or
       http.request.uri.query contains "; drop table")
    action: block
    severity: critical

  # XSS Protection
  - name: "Cross-Site Scripting"
    expression: |
      (http.request.uri.query contains "<script>" or
       http.request.uri.query contains "javascript:" or
       http.request.uri.query contains "onerror=")
    action: block
    severity: critical

  # Rate Limiting
  - name: "API Rate Limit"
    expression: |
      (http.request.uri.path contains "/api/" and
       cf.threat_score > 10)
    action: challenge
    rate_limit:
      requests: 100
      period: 60

  # Bot Protection
  - name: "Bad Bots"
    expression: |
      (http.user_agent contains "scrapy" or
       http.user_agent contains "curl" or
       http.user_agent contains "wget")
    action: challenge

  # Geographic Blocking
  - name: "High-Risk Countries"
    expression: |
      (ip.geoip.country in {"CN" "RU" "KP" "IR"})
    action: challenge

  # Custom Rules
  - name: "Protect Admin Endpoints"
    expression: |
      (http.request.uri.path contains "/admin/" and
       not ip.src in $admin_ips)
    action: block
```

### Implementation

```typescript
// apps/api/src/middleware/security.ts

import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import cors from 'cors';

// Rate limiting
export const apiRateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100, // 100 requests per minute
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip,
  handler: (req, res) => {
    res.status(429).json({
      error: 'Too many requests',
      retryAfter: Math.ceil(req.rateLimit.resetTime / 1000)
    });
  }
});

// Stricter rate limit for auth endpoints
export const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 attempts
  skipSuccessfulRequests: true,
  handler: (req, res) => {
    res.status(429).json({
      error: 'Too many login attempts. Please try again later.'
    });
  }
});

// Security headers
export const securityHeaders = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "https://api.infamousfreight.com"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: []
    }
  },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  },
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' }
});

// CORS configuration
export const corsOptions = cors({
  origin: (origin, callback) => {
    const allowedOrigins = [
      'https://infamousfreight.com',
      'https://app.infamousfreight.com',
      'http://localhost:3000'
    ];
    
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
});
```

---

## 3. Secrets Scanning

### GitHub Advanced Security

```yaml
# .github/secret-scanning.yml

# Enable secret scanning
secret_scanning:
  enabled: true
  push_protection:
    enabled: true

# Custom patterns
custom_patterns:
  - name: "Infamous Freight API Key"
    pattern: "iff_[a-zA-Z0-9]{32}"
    description: "Infamous Freight API key"

  - name: "Database Connection String"
    pattern: "postgresql://[^:]+:[^@]+@"
    description: "PostgreSQL connection string"

  - name: "JWT Secret"
    pattern: "JWT_SECRET[=:]\s*['\"]?[a-zA-Z0-9]{32,}"
    description: "JWT secret key"
```

### Pre-commit Hooks

```yaml
# .pre-commit-config.yaml

repos:
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.5.0
    hooks:
      - id: detect-private-key
      - id: check-added-large-files
      - id: check-merge-conflict

  - repo: https://github.com/Yelp/detect-secrets
    rev: v1.4.0
    hooks:
      - id: detect-secrets
        args: ['--baseline', '.secrets.baseline']

  - repo: https://github.com/gitleaks/gitleaks
    rev: v8.18.0
    hooks:
      - id: gitleaks

  - repo: local
    hooks:
      - id: custom-secret-scan
        name: Custom Secret Scanner
        entry: scripts/scan-secrets.sh
        language: script
        files: \.(ts|js|json|env)$
```

```bash
#!/bin/bash
# scripts/scan-secrets.sh

# Patterns to detect
PATTERNS=(
  "sk-[a-zA-Z0-9]{48}"           # OpenAI API key
  "ghp_[a-zA-Z0-9]{36}"          # GitHub token
  "AKIA[0-9A-Z]{16}"             # AWS access key
  "postgresql://"                # Database URL
  "JWT_SECRET[=:]