# Revenue Optimization Strategy

## Complete Implementation Guide

---

## 1. Usage-Based Pricing Model

### Overview
Add per-shipment fees on top of SaaS subscription for additional revenue stream.

### Pricing Tiers

| Tier | Monthly Fee | Per Shipment | Best For |
|------|-------------|--------------|----------|
| **Free** | $0 | $2.00 | 1-5 shipments/month |
| **Pro** | $99 | $0.50 | 20-100 shipments/month |
| **Business** | $299 | $0.25 | 100-500 shipments/month |
| **Enterprise** | Custom | Custom | 500+ shipments/month |

### Implementation

#### Database Schema Update

```sql
-- Add pricing tier to organizations
ALTER TABLE "Organization" ADD COLUMN pricing_tier VARCHAR(20) DEFAULT 'FREE';
ALTER TABLE "Organization" ADD COLUMN shipment_count_monthly INTEGER DEFAULT 0;
ALTER TABLE "Organization" ADD COLUMN per_shipment_rate DECIMAL(10,2);

-- Create billing records table
CREATE TABLE "BillingRecord" (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID REFERENCES "Organization"(id),
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  base_amount DECIMAL(10,2) NOT NULL,
  shipment_count INTEGER DEFAULT 0,
  shipment_fees DECIMAL(10,2) DEFAULT 0,
  total_amount DECIMAL(10,2) NOT NULL,
  status VARCHAR(20) DEFAULT 'PENDING',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Add indexes
CREATE INDEX idx_billing_org_period ON "BillingRecord"(organization_id, period_start);
```

#### Billing Calculation Service

```typescript
// apps/api/src/services/billing.service.ts

interface PricingTier {
  name: string;
  basePrice: number;
  perShipmentRate: number;
  includedShipments: number;
}

const PRICING_TIERS: Record<string, PricingTier> = {
  FREE: { name: 'Free', basePrice: 0, perShipmentRate: 2.00, includedShipments: 0 },
  PRO: { name: 'Pro', basePrice: 99, perShipmentRate: 0.50, includedShipments: 0 },
  BUSINESS: { name: 'Business', basePrice: 299, perShipmentRate: 0.25, includedShipments: 0 },
  ENTERPRISE: { name: 'Enterprise', basePrice: 0, perShipmentRate: 0, includedShipments: 0 },
};

export class BillingService {
  async calculateMonthlyBill(organizationId: string, periodStart: Date, periodEnd: Date): Promise<BillingRecord> {
    const org = await prisma.organization.findUnique({
      where: { id: organizationId },
      include: { shipments: true }
    });

    const tier = PRICING_TIERS[org.pricingTier];
    const shipmentCount = await this.countShipmentsInPeriod(organizationId, periodStart, periodEnd);
    
    const shipmentFees = shipmentCount * tier.perShipmentRate;
    const totalAmount = tier.basePrice + shipmentFees;

    return prisma.billingRecord.create({
      data: {
        organizationId,
        periodStart,
        periodEnd,
        baseAmount: tier.basePrice,
        shipmentCount,
        shipmentFees,
        totalAmount,
        status: 'PENDING'
      }
    });
  }

  private async countShipmentsInPeriod(orgId: string, start: Date, end: Date): Promise<number> {
    return prisma.shipment.count({
      where: {
        organizationId: orgId,
        createdAt: { gte: start, lte: end },
        status: { not: 'CANCELLED' }
      }
    });
  }
}
```

### Expected Impact
- **25% increase in ARR** from per-shipment fees
- **Improved unit economics** - customers pay for value received
- **Natural upsell path** - growth drives upgrades

---

## 2. Referral Program

### Program Structure

| Action | Reward |
|--------|--------|
| Referrer (existing user) | $100 account credit |
| Referee (new user) | $100 account credit |
| Referrer milestone (5 referrals) | Free Pro tier for 6 months |
| Referrer milestone (10 referrals) | Free Pro tier for 12 months |

### Implementation

#### Database Schema

```sql
-- Create referral tracking table
CREATE TABLE "Referral" (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  referrer_id UUID REFERENCES "User"(id) NOT NULL,
  referee_email VARCHAR(255) NOT NULL,
  referral_code VARCHAR(20) UNIQUE NOT NULL,
  status VARCHAR(20) DEFAULT 'PENDING', -- PENDING, CONVERTED, EXPIRED
  converted_at TIMESTAMP,
  reward_claimed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW(),
  expires_at TIMESTAMP DEFAULT NOW() + INTERVAL '30 days'
);

-- Add referral code to users
ALTER TABLE "User" ADD COLUMN referral_code VARCHAR(20) UNIQUE;
ALTER TABLE "User" ADD COLUMN referral_count INTEGER DEFAULT 0;
ALTER TABLE "User" ADD COLUMN referral_credits DECIMAL(10,2) DEFAULT 0;

-- Create indexes
CREATE INDEX idx_referral_code ON "Referral"(referral_code);
CREATE INDEX idx_referral_referrer ON "Referral"(referrer_id);
```

#### Referral Service

```typescript
// apps/api/src/services/referral.service.ts

export class ReferralService {
  async generateReferralCode(userId: string): Promise<string> {
    const code = this.generateUniqueCode();
    await prisma.user.update({
      where: { id: userId },
      data: { referralCode: code }
    });
    return code;
  }

  async trackReferral(referralCode: string, refereeEmail: string): Promise<void> {
    const referrer = await prisma.user.findFirst({
      where: { referralCode }
    });

    if (!referrer) throw new Error('Invalid referral code');

    await prisma.referral.create({
      data: {
        referrerId: referrer.id,
        refereeEmail,
        referralCode,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
      }
    });
  }

  async convertReferral(referralCode: string, newUserId: string): Promise<void> {
    const referral = await prisma.referral.findFirst({
      where: { referralCode, status: 'PENDING' }
    });

    if (!referral || referral.expiresAt < new Date()) {
      throw new Error('Referral expired or invalid');
    }

    // Update referral status
    await prisma.referral.update({
      where: { id: referral.id },
      data: { status: 'CONVERTED', convertedAt: new Date() }
    });

    // Credit referrer
    await prisma.user.update({
      where: { id: referral.referrerId },
      data: {
        referralCredits: { increment: 100 },
        referralCount: { increment: 1 }
      }
    });

    // Credit new user
    await prisma.user.update({
      where: { id: newUserId },
      data: { referralCredits: 100 }
    });

    // Check for milestone rewards
    await this.checkMilestoneRewards(referral.referrerId);
  }

  private async checkMilestoneRewards(userId: string): Promise<void> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { referralCount: true }
    });

    if (user.referralCount === 5) {
      // Grant 6 months free Pro
      await this.grantFreeTier(userId, 'PRO', 6);
    } else if (user.referralCount === 10) {
      // Grant 12 months free Pro
      await this.grantFreeTier(userId, 'PRO', 12);
    }
  }

  private generateUniqueCode(): string {
    return 'IFF' + Math.random().toString(36).substring(2, 8).toUpperCase();
  }
}
```

### Referral Widget (Web)

```tsx
// apps/web/components/ReferralWidget.tsx

export function ReferralWidget() {
  const { user } = useAuth();
  const referralLink = `https://infamousfreight.com/signup?ref=${user.referralCode}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(referralLink);
    toast.success('Referral link copied!');
  };

  return (
    <Card>
      <CardHeader>
        <Heading size="md">Refer & Earn $100</Heading>
      </CardHeader>
      <CardBody>
        <VStack spacing={4} align="stretch">
          <Text>
            Share your unique link with other drivers. You'll both get 
            <Badge colorScheme="green" ml={1}>$100 credit</Badge>
          </Text>
          
          <InputGroup>
            <Input value={referralLink} isReadOnly />
            <InputRightElement>
              <Button size="sm" onClick={copyToClipboard}>
                Copy
              </Button>
            </InputRightElement>
          </InputGroup>

          <HStack justify="space-between">
            <Stat>
              <StatLabel>Referrals</StatLabel>
              <StatNumber>{user.referralCount}</StatNumber>
            </Stat>
            <Stat>
              <StatLabel>Credits Earned</StatLabel>
              <StatNumber>${user.referralCredits}</StatNumber>
            </Stat>
          </HStack>

          {user.referralCount >= 5 && (
            <Alert status="success">
              <AlertIcon />
              <Box>
                <AlertTitle>Milestone Unlocked!</AlertTitle>
                <AlertDescription>
                  You've earned free Pro tier. Keep referring for more rewards!
                </AlertDescription>
              </Box>
            </Alert>
          )}
        </VStack>
      </CardBody>
    </Card>
  );
}
```

### Expected Impact
- **-20% CAC** - referrals are cheapest acquisition channel
- **Higher LTV** - referred customers have 16% higher retention
- **Viral growth** - each user brings 1.2 new users on average

---

## 3. Factoring Revenue

### Service Overview
Offer same-day payment on invoices at 2-3% fee (vs industry standard 5%).

### Implementation

#### Factoring Service

```typescript
// apps/api/src/services/factoring.service.ts

interface FactoringTerms {
  feePercent: number; // 2.0% - 3.0%
  advancePercent: number; // 85% - 95%
  reservePercent: number; // 5% - 15%
}

const FACTORING_TERMS: Record<string, FactoringTerms> = {
  STANDARD: { feePercent: 3.0, advancePercent: 85, reservePercent: 15 },
  PREFERRED: { feePercent: 2.5, advancePercent: 90, reservePercent: 10 },
  PREMIUM: { feePercent: 2.0, advancePercent: 95, reservePercent: 5 },
};

export class FactoringService {
  async createFactoringRequest(invoiceId: string, userId: string): Promise<FactoringRequest> {
    const invoice = await prisma.invoice.findUnique({
      where: { id: invoiceId },
      include: { shipment: true }
    });

    if (invoice.status !== 'PENDING') {
      throw new Error('Invoice must be pending to factor');
    }

    const user = await prisma.user.findUnique({ where: { id: userId } });
    const terms = this.determineTerms(user);

    const advanceAmount = (invoice.amount * terms.advancePercent) / 100;
    const feeAmount = (invoice.amount * terms.feePercent) / 100;
    const reserveAmount = (invoice.amount * terms.reservePercent) / 100;

    const factoringRequest = await prisma.factoringRequest.create({
      data: {
        invoiceId,
        userId,
        originalAmount: invoice.amount,
        advanceAmount,
        feeAmount,
        reserveAmount,
        feePercent: terms.feePercent,
        status: 'PENDING_APPROVAL'
      }
    });

    // Auto-approve for trusted users
    if (user.factoringTrustScore > 80) {
      await this.approveFactoring(factoringRequest.id);
    }

    return factoringRequest;
  }

  async approveFactoring(requestId: string): Promise<void> {
    const request = await prisma.factoringRequest.findUnique({
      where: { id: requestId }
    });

    // Process payment via Stripe/ACH
    await this.processPayment(request.userId, request.advanceAmount);

    await prisma.factoringRequest.update({
      where: { id: requestId },
      data: { 
        status: 'FUNDED',
        fundedAt: new Date()
      }
    });

    await prisma.invoice.update({
      where: { id: request.invoiceId },
      data: { status: 'FACTORED' }
    });
  }

  async releaseReserve(requestId: string): Promise<void> {
    const request = await prisma.factoringRequest.findUnique({
      where: { id: requestId }
    });

    // Check if invoice was paid by shipper
    const invoice = await prisma.invoice.findUnique({
      where: { id: request.invoiceId }
    });

    if (invoice.status === 'PAID') {
      await this.processPayment(request.userId, request.reserveAmount);
      
      await prisma.factoringRequest.update({
        where: { id: requestId },
        data: { status: 'COMPLETE', reserveReleasedAt: new Date() }
      });
    }
  }

  private determineTerms(user: User): FactoringTerms {
    if (user.factoringTrustScore > 90) return FACTORING_TERMS.PREMIUM;
    if (user.factoringTrustScore > 70) return FACTORING_TERMS.PREFERRED;
    return FACTORING_TERMS.STANDARD;
  }

  private async processPayment(userId: string, amount: number): Promise<void> {
    // Integrate with Stripe Connect or bank transfer API
    // Implementation depends on payment provider
  }
}
```

### Factoring UI Component

```tsx
// apps/web/components/FactoringWidget.tsx

export function FactoringWidget({ invoice }: { invoice: Invoice }) {
  const [terms, setTerms] = useState<FactoringTerms | null>(null);

  useEffect(() => {
    fetchFactoringTerms(invoice.id).then(setTerms);
  }, [invoice.id]);

  if (!terms) return <Skeleton height="200px" />;

  const advanceAmount = (invoice.amount * terms.advancePercent) / 100;
  const feeAmount = (invoice.amount * terms.feePercent) / 100;
  const reserveAmount = (invoice.amount * terms.reservePercent) / 100;

  return (
    <Card borderColor="green.500" borderWidth={2}>
      <CardHeader bg="green.50">
        <Flex align="center" gap={2}>
          <DollarSign className="text-green-600" />
          <Heading size="md">Get Paid Today</Heading>
        </Flex>
      </CardHeader>
      <CardBody>
        <VStack spacing={4} align="stretch">
          <Text>
            Factor this invoice and receive <strong>${advanceAmount.toFixed(2)}</strong> today!
          </Text>

          <SimpleGrid columns={3} spacing={4}>
            <Box textAlign="center" p={3} bg="green.50" borderRadius="md">
              <Text fontSize="2xl" fontWeight="bold" color="green.600">
                ${advanceAmount.toFixed(0)}
              </Text>
              <Text fontSize="sm" color="gray.600">Today ({terms.advancePercent}%)</Text>
            </Box>
            <Box textAlign="center" p={3} bg="gray.50" borderRadius="md">
              <Text fontSize="2xl" fontWeight="bold" color="gray.600">
                ${reserveAmount.toFixed(0)}
              </Text>
              <Text fontSize="sm" color="gray.600">Reserve ({terms.reservePercent}%)</Text>
            </Box>
            <Box textAlign="center" p={3} bg="red.50" borderRadius="md">
              <Text fontSize="2xl" fontWeight="bold" color="red.600">
                ${feeAmount.toFixed(0)}
              </Text>
              <Text fontSize="sm" color="gray.600">Fee ({terms.feePercent}%)</Text>
            </Box>
          </SimpleGrid>

          <Alert status="info" size="sm">
            <AlertIcon />
            <Text fontSize="sm">
              Your reserve will be released when the shipper pays (typically 15-30 days)
            </Text>
          </Alert>

          <Button colorScheme="green" size="lg">
            Get Paid Now - ${advanceAmount.toFixed(2)}
          </Button>

          <Text fontSize="xs" color="gray.500" textAlign="center">
            Save 2-3% vs traditional factoring (industry standard: 5%)
          </Text>
        </VStack>
      </CardBody>
    </Card>
  );
}
```

### Expected Impact
- **+40% margins** on factoring revenue
- **$200K-$500K ARR** at scale (assuming 10% of invoices factored)
- **Higher retention** - customers who factor stay 3x longer

---

## 4. Insurance Partnerships

### Partnership Model

| Insurance Type | Partner | Commission | Target |
|----------------|---------|------------|--------|
| Cargo Insurance | Progressive, CoverWallet | 10-15% | $100K/year |
| Liability | Progressive Commercial | 10-15% | $75K/year |
| Occupational Accident | Occupational Accident | 15-20% | $50K/year |
| Equipment | National Interstate | 10-12% | $25K/year |

### Implementation

```typescript
// apps/api/src/services/insurance.service.ts

interface InsuranceQuote {
  type: string;
  coverageAmount: number;
  deductible: number;
  premium: number;
  term: string;
  partner: string;
}

export class InsuranceService {
  private partners: Map<string, InsurancePartner> = new Map();

  constructor() {
    this.partners.set('progressive', new ProgressivePartner());
    this.partners.set('coverwallet', new CoverWalletPartner());
  }

  async getQuotes(userId: string, type: string): Promise<InsuranceQuote[]> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { driver: true, organization: true }
    });

    const quotes: InsuranceQuote[] = [];

    for (const [name, partner] of this.partners) {
      try {
        const quote = await partner.getQuote(user, type);
        quotes.push(quote);
      } catch (error) {
        console.error(`Failed to get quote from ${name}:`, error);
      }
    }

    return quotes.sort((a, b) => a.premium - b.premium);
  }

  async purchasePolicy(userId: string, quote: InsuranceQuote): Promise<Policy> {
    const partner = this.partners.get(quote.partner.toLowerCase());
    if (!partner) throw new Error('Invalid insurance partner');

    const policy = await partner.purchasePolicy(userId, quote);

    // Track commission
    await this.trackCommission(userId, quote);

    return policy;
  }

  private async trackCommission(userId: string, quote: InsuranceQuote): Promise<void> {
    const commissionRate = this.getCommissionRate(quote.type);
    const commissionAmount = (quote.premium * commissionRate) / 100;

    await prisma.insuranceCommission.create({
      data: {
        userId,
        partner: quote.partner,
        policyType: quote.type,
        premiumAmount: quote.premium,
        commissionRate,
        commissionAmount,
        status: 'PENDING'
      }
    });
  }

  private getCommissionRate(type: string): number {
    const rates: Record<string, number> = {
      'cargo': 12,
      'liability': 12,
      'occupational-accident': 18,
      'equipment': 11
    };
    return rates[type] || 10;
  }
}
```

### Insurance Widget

```tsx
// apps/web/components/InsuranceWidget.tsx

export function InsuranceWidget() {
  const [quotes, setQuotes] = useState<InsuranceQuote[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchInsuranceQuotes().then(quotes => {
      setQuotes(quotes);
      setLoading(false);
    });
  }, []);

  return (
    <Card>
      <CardHeader>
        <Heading size="md">Insurance Quotes</Heading>
        <Text fontSize="sm" color="gray.600">
          Compare quotes from top providers
        </Text>
      </CardHeader>
      <CardBody>
        {loading ? (
          <VStack spacing={4}>
            <Skeleton height="80px" />
            <Skeleton height="80px" />
          </VStack>
        ) : (
          <VStack spacing={4} align="stretch">
            {quotes.map((quote, index) => (
              <Box
                key={index}
                p={4}
                borderWidth={1}
                borderRadius="md"
                borderColor={index === 0 ? 'green.500' : 'gray.200'}
                bg={index === 0 ? 'green.50' : 'white'}
              >
                <Flex justify="space-between" align="center">
                  <Box>
                    <Text fontWeight="bold">{quote.partner}</Text>
                    <Text fontSize="sm" color="gray.600">
                      {quote.coverageAmount > 0 && `$${quote.coverageAmount.toLocaleString()} coverage`}
                      {quote.deductible > 0 && ` • $${quote.deductible} deductible`}
                    </Text>
                  </Box>
                  <Box textAlign="right">
                    <Text fontSize="2xl" fontWeight="bold" color="green.600">
                      ${quote.premium}/mo
                    </Text>
                    {index === 0 && (
                      <Badge colorScheme="green">Best Price</Badge>
                    )}
                  </Box>
                </Flex>
              </Box>
            ))}

            <Button colorScheme="blue" size="lg">
              Compare All Quotes
            </Button>
          </VStack>
        )}
      </CardBody>
    </Card>
  );
}
```

### Expected Impact
- **+$250K/year** in commission revenue
- **Higher LTV** - customers with insurance stay 40% longer
- **Competitive advantage** - one-stop shop for trucking needs

---

## Revenue Projection

### 12-Month Revenue Model

| Revenue Stream | Month 1 | Month 6 | Month 12 |
|----------------|---------|---------|----------|
| **SaaS Subscriptions** | $50K | $150K | $400K |
| **Per-Shipment Fees** | $5K | $35K | $120K |
| **Factoring Revenue** | $2K | $25K | $80K |
| **Insurance Commissions** | $0 | $10K | $25K |
| **Referral Credits (net)** | -$5K | $0 | $15K |
| **Total MRR** | **$52K** | **$220K** | **$640K** |
| **Annual Run Rate** | **$624K** | **$2.64M** | **$7.68M** |

### Key Metrics

| Metric | Target |
|--------|--------|
| ARPU (Average Revenue Per User) | $150/month |
| LTV (Lifetime Value) | $2,700 |
| CAC (Customer Acquisition Cost) | $85 |
| LTV/CAC Ratio | 32x |
| Gross Margin | 75% |
| Net Revenue Retention | 120% |

---

## Implementation Checklist

### Week 1-2: Usage-Based Pricing
- [ ] Create database migrations
- [ ] Implement billing service
- [ ] Add pricing page to website
- [ ] Update subscription management UI
- [ ] Test billing calculations

### Week 3-4: Referral Program
- [ ] Create referral tracking tables
- [ ] Implement referral service
- [ ] Build referral widget
- [ ] Create referral landing page
- [ ] Launch email campaign

### Month 2: Factoring
- [ ] Integrate with payment provider (Stripe Connect)
- [ ] Build factoring service
- [ ] Create factoring UI components
- [ ] Set up reserve management
- [ ] Launch beta with 10 customers

### Month 3: Insurance
- [ ] Partner with 2-3 insurance providers
- [ ] Build insurance quote API
- [ ] Create insurance widget
- [ ] Set up commission tracking
- [ ] Launch to all customers

---

*Document Owner: Revenue Team*  
*Last Updated: February 24, 2025*  
*Next Review: March 24, 2025*
