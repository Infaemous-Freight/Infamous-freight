# Growth Hacking Tactics

## Viral Loops & Channel Expansion

---

## 1. Viral Loops

### Load Sharing Feature

```typescript
// apps/api/src/services/loadSharing.service.ts

interface SharedLoad {
  id: string;
  originalShipmentId: string;
  sharedBy: string;
  sharedWith: string[];
  message?: string;
  expiresAt: Date;
  claimedBy?: string;
  claimedAt?: Date;
}

export class LoadSharingService {
  async shareLoad(
    shipmentId: string,
    sharedBy: string,
    recipients: string[],
    message?: string
  ): Promise<SharedLoad> {
    const shipment = await prisma.shipment.findUnique({
      where: { id: shipmentId }
    });

    // Create share record
    const sharedLoad = await prisma.sharedLoad.create({
      data: {
        originalShipmentId: shipmentId,
        sharedBy,
        sharedWith: recipients,
        message,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
      }
    });

    // Send notifications to recipients
    for (const recipientId of recipients) {
      await this.notifyRecipient(recipientId, sharedLoad, shipment);
    }

    // Track share
    analytics.track('Load Shared', {
      shipmentId,
      sharedBy,
      recipientCount: recipients.length
    });

    return sharedLoad;
  }

  async claimLoad(sharedLoadId: string, claimedBy: string): Promise<void> {
    const sharedLoad = await prisma.sharedLoad.findUnique({
      where: { id: sharedLoadId }
    });

    if (sharedLoad.claimedBy) {
      throw new Error('Load already claimed');
    }

    if (sharedLoad.expiresAt < new Date()) {
      throw new Error('Load share expired');
    }

    // Mark as claimed
    await prisma.sharedLoad.update({
      where: { id: sharedLoadId },
      data: { claimedBy, claimedAt: new Date() }
    });

    // Create new shipment for claimer
    const originalShipment = await prisma.shipment.findUnique({
      where: { id: sharedLoad.originalShipmentId }
    });

    await prisma.shipment.create({
      data: {
        ...originalShipment,
        id: undefined,
        driverId: claimedBy,
        status: 'ASSIGNED',
        source: 'SHARED'
      }
    });

    // Reward original sharer
    await this.rewardSharer(sharedLoad.sharedBy);

    // Track claim
    analytics.track('Load Claimed', {
      sharedLoadId,
      claimedBy,
      sharedBy: sharedLoad.sharedBy
    });
  }

  private async rewardSharer(userId: string): Promise<void> {
    // Add credits
    await prisma.user.update({
      where: { id: userId },
      data: { accountCredits: { increment: 10 } }
    });

    // Check for milestone
    const shareCount = await prisma.sharedLoad.count({
      where: { sharedBy: userId, claimedBy: { not: null } }
    });

    if (shareCount === 10) {
      await prisma.user.update({
        where: { id: userId },
        data: { accountCredits: { increment: 100 } }
      });

      await emailService.send({
        to: userId,
        template: 'share-milestone',
        data: { milestone: 10, reward: 100 }
      });
    }
  }
}
```

### Fleet Leaderboards

```tsx
// apps/web/components/Leaderboard.tsx

export function Leaderboard() {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [timeframe, setTimeframe] = useState<'week' | 'month' | 'all'>('month');

  useEffect(() => {
    fetchLeaderboard(timeframe).then(setLeaderboard);
  }, [timeframe]);

  return (
    <Card>
      <CardHeader>
        <Flex justify="space-between" align="center">
          <Heading size="md">🏆 Driver Leaderboard</Heading>
          <Select
            value={timeframe}
            onChange={(e) => setTimeframe(e.target.value as any)}
            w="150px"
          >
            <option value="week">This Week</option>
            <option value="month">This Month</option>
            <option value="all">All Time</option>
          </Select>
        </Flex>
      </CardHeader>
      <CardBody>
        <VStack spacing={3} align="stretch">
          {leaderboard.map((entry, index) => (
            <Flex
              key={entry.userId}
              p={3}
              bg={index < 3 ? 'yellow.50' : 'gray.50'}
              borderRadius="md"
              align="center"
              gap={4}
            >
              <Box w="40px" textAlign="center">
                {index === 0 && <Text fontSize="2xl">🥇</Text>}
                {index === 1 && <Text fontSize="2xl">🥈</Text>}
                {index === 2 && <Text fontSize="2xl">🥉</Text>}
                {index > 2 && <Text fontWeight="bold">#{index + 1}</Text>}
              </Box>

              <Avatar name={entry.name} src={entry.avatar} />

              <Box flex={1}>
                <Text fontWeight="bold">{entry.name}</Text>
                <Text fontSize="sm" color="gray.600">
                  {entry.shipments} shipments • ${entry.revenue.toLocaleString()}
                </Text>
              </Box>

              <Badge colorScheme={index < 3 ? 'yellow' : 'gray'}>
                {entry.points.toLocaleString()} pts
              </Badge>
            </Flex>
          ))}
        </VStack>

        <Alert status="info" mt={4}>
          <AlertIcon />
          <Box>
            <AlertTitle>Earn Points</AlertTitle>
            <AlertDescription>
              +10 pts per shipment • +5 pts per $100 revenue • +20 pts for on-time delivery
            </AlertDescription>
          </Box>
        </Alert>
      </CardBody>
    </Card>
  );
}
```

---

## 2. Channel Expansion

### TikTok Ads

**Budget**: $3,000/month  
**Target CAC**: $35

```typescript
// apps/marketing/tiktok-campaign.ts

interface TikTokAd {
  hook: string; // First 3 seconds
  problem: string; // 5-10 seconds
  solution: string; // 10-20 seconds
  cta: string; // 20-30 seconds
}

const TIKTOK_ADS: TikTokAd[] = [
  {
    hook: "POV: You just found out brokers take 30% of your pay 💀",
    problem: "I was making $1.85/mile while brokers laughed to the bank",
    solution: "Then I found this app that uses AI to find $3+/mile loads",
    cta: "Link in bio - first month free"
  },
  {
    hook: "Day in the life of a truck driver using AI 📱",
    problem: "Used to spend 3 hours on load boards every morning",
    solution: "Now the AI finds me the best loads in 30 seconds",
    cta: "Try it free - link in bio"
  },
  {
    hook: "How I went from $3,200 to $8,900/month 💰",
    problem: "Was barely making ends meet as an owner-operator",
    solution: "This app helped me find better paying loads and cut deadhead",
    cta: "Start your free trial today"
  }
];
```

### Podcast Sponsorships

**Target Podcasts**:
- "Trucking For Millennials" (50K listeners)
- "The Trucking Entrepreneur" (30K listeners)
- "Red Eye Radio" (100K listeners)

**Budget**: $5,000/month  
**Ad Read Script**:

```
"If you're an owner-operator tired of brokers taking 30% and giving you 
garbage loads, listen up. Infamous Freight is an AI-powered load finder 
that scores every load by profit per mile—not just the total pay.

Our drivers are averaging $2.67 per mile, up from $1.85 before using 
the app. That's an extra $68,000 in profit per year for a single truck.

The app is free to try for 14 days—no credit card required. Just download 
Infamous Freight from the App Store or Google Play, or visit 
infamousfreight.com.

Stop letting brokers eat your lunch. Start finding the loads you deserve."
```

### Truck Stop Billboards

**Locations**:
- Pilot Flying J (Top 20 locations)
- Love's Travel Stops
- TA Petro

**Budget**: $8,000/month  
**Design**:

```
┌─────────────────────────────────────┐
│                                     │
│   🚛  STOP OVERPAYING BROKERS       │
│                                     │
│   Find $3+/mile loads with AI       │
│                                     │
│   [QR CODE]  infamousfreight.com    │
│                                     │
│   "I made $68K more this year"      │
│   — Marcus J., Dallas TX            │
│                                     │
└─────────────────────────────────────┘
```

---

## 3. Influencer Partnerships

### Micro-Influencer Program

**Criteria**:
- 10K-100K followers
- Trucking/lifestyle content
- 3%+ engagement rate

**Partnership Terms**:
- Free Pro subscription
- $500/month retainer
- $50 per qualified signup
- Exclusive discount code

**Tracking**:

```typescript
// apps/api/src/services/influencer.service.ts

export class InfluencerService {
  async trackInfluencerSignup(code: string, userId: string): Promise<void> {
    const influencer = await prisma.influencer.findUnique({
      where: { referralCode: code }
    });

    if (!influencer) return;

    // Track conversion
    await prisma.influencerConversion.create({
      data: {
        influencerId: influencer.id,
        userId,
        commissionAmount: 50,
        status: 'PENDING' // Paid after 30 days if user stays
      }
    });

    // Update stats
    await prisma.influencer.update({
      where: { id: influencer.id },
      data: {
        totalSignups: { increment: 1 },
        pendingCommission: { increment: 50 }
      }
    });
  }

  async payCommissions(): Promise<void> {
    const pendingConversions = await prisma.influencerConversion.findMany({
      where: {
        status: 'PENDING',
        createdAt: { lte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) }
      },
      include: { influencer: true }
    });

    for (const conversion of pendingConversions) {
      // Check if user is still active
      const user = await prisma.user.findUnique({
        where: { id: conversion.userId }
      });

      if (user.status === 'ACTIVE') {
        // Pay commission
        await this.processPayment(conversion.influencer.payoutMethod, 50);

        await prisma.influencerConversion.update({
          where: { id: conversion.id },
          data: { status: 'PAID', paidAt: new Date() }
        });

        await prisma.influencer.update({
          where: { id: conversion.influencerId },
          data: {
            pendingCommission: { decrement: 50 },
            totalCommission: { increment: 50 }
          }
        });
      } else {
        // User churned, cancel commission
        await prisma.influencerConversion.update({
          where: { id: conversion.id },
          data: { status: 'CANCELLED' }
        });

        await prisma.influencer.update({
          where: { id: conversion.influencerId },
          data: { pendingCommission: { decrement: 50 } }
        });
      }
    }
  }
}
```

---

## 4. Expected Results

### Channel Performance

| Channel | Monthly Budget | Expected CAC | Expected Signups |
|---------|---------------|--------------|------------------|
| Facebook/Instagram | $5,000 | $45 | 111 |
| Google Ads | $3,000 | $55 | 55 |
| YouTube | $2,000 | $60 | 33 |
| TikTok | $3,000 | $35 | 86 |
| Podcasts | $5,000 | $65 | 77 |
| Billboards | $8,000 | $120 | 67 |
| Influencers | $4,000 | $45 | 89 |
| **Total** | **$30,000** | **$55 avg** | **518** |

### Viral Metrics

| Metric | Target |
|--------|--------|
| Viral Coefficient (K) | 0.3 |
| Load Shares / Month | 500 |
| Leaderboard Engagement | 40% DAU |
| Referral Conversion | 12% |

---

*Document Owner: Growth Team*  
*Last Updated: February 24, 2025*
