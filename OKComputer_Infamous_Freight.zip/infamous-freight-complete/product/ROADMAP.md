# Product Roadmap 2025

## 6-Month Development Plan

---

## Q1 2025 (January - March)

### 1. Real-Time ETA Predictions

**Description**: ML-based arrival time predictions using traffic, weather, and historical data.

**Implementation**:

```typescript
// apps/api/src/services/eta.service.ts

interface ETAPrediction {
  estimatedArrival: Date;
  confidence: number; // 0-100
  factors: ETAFactor[];
  alternativeRoutes: AlternativeRoute[];
}

interface ETAFactor {
  type: 'traffic' | 'weather' | 'construction' | 'historical';
  impact: number; // minutes added/subtracted
  description: string;
}

export class ETAService {
  async predictETA(shipmentId: string): Promise<ETAPrediction> {
    const shipment = await prisma.shipment.findUnique({
      where: { id: shipmentId },
      include: { trackingEvents: true }
    });

    // Get current location
    const currentLocation = await this.getCurrentLocation(shipment);
    
    // Get route data
    const route = await this.getRouteData(
      currentLocation,
      { lat: shipment.deliveryLatitude, lng: shipment.deliveryLongitude }
    );

    // Calculate base ETA
    const baseETA = new Date(Date.now() + route.duration * 1000);

    // Apply ML model factors
    const factors = await this.calculateFactors(route, shipment);
    
    // Adjust ETA based on factors
    const totalImpact = factors.reduce((sum, f) => sum + f.impact, 0);
    const adjustedETA = new Date(baseETA.getTime() + totalImpact * 60 * 1000);

    // Calculate confidence
    const confidence = this.calculateConfidence(factors);

    // Get alternative routes
    const alternativeRoutes = await this.getAlternativeRoutes(route);

    return {
      estimatedArrival: adjustedETA,
      confidence,
      factors,
      alternativeRoutes
    };
  }

  private async calculateFactors(route: Route, shipment: Shipment): Promise<ETAFactor[]> {
    const factors: ETAFactor[] = [];

    // Traffic factor
    const trafficData = await this.getTrafficData(route);
    if (trafficData.delay > 0) {
      factors.push({
        type: 'traffic',
        impact: trafficData.delay,
        description: `Heavy traffic: ${trafficData.severity}`
      });
    }

    // Weather factor
    const weather = await this.getWeatherForecast(route);
    if (weather.impact > 0) {
      factors.push({
        type: 'weather',
        impact: weather.impact,
        description: `${weather.condition}: ${weather.description}`
      });
    }

    // Historical factor
    const historical = await this.getHistoricalData(shipment);
    if (historical.avgDelay > 0) {
      factors.push({
        type: 'historical',
        impact: historical.avgDelay,
        description: `Historical delays on this route: ${historical.avgDelay} min avg`
      });
    }

    return factors;
  }

  private calculateConfidence(factors: ETAFactor[]): number {
    // More factors = lower confidence
    const baseConfidence = 95;
    const confidencePenalty = factors.length * 5;
    return Math.max(baseConfidence - confidencePenalty, 60);
  }
}
```

**Success Metrics**:
- ETA accuracy within 15 minutes: 85%
- Customer satisfaction with predictions: >4.5/5

---

### 2. Document Scanning (OCR)

**Description**: AI-powered document scanning for BOLs, receipts, and compliance documents.

**Implementation**:

```typescript
// apps/api/src/services/document.service.ts

import { Textract } from '@aws-sdk/client-textract';

export class DocumentService {
  private textract = new Textract({ region: 'us-east-1' });

  async processDocument(file: Buffer, type: string): Promise<ProcessedDocument> {
    // Upload to S3
    const s3Key = await this.uploadToS3(file);

    // Process with Textract
    const result = await this.textract.analyzeDocument({
      Document: { S3Object: { Bucket: 'infamous-docs', Name: s3Key } },
      FeatureTypes: ['FORMS', 'TABLES']
    });

    // Extract relevant data based on document type
    const extractedData = this.extractData(result, type);

    // Store processed document
    const document = await prisma.document.create({
      data: {
        s3Key,
        type,
        extractedData,
        confidence: result.Blocks?.[0]?.Confidence || 0,
        status: 'PROCESSED'
      }
    });

    return document;
  }

  private extractData(result: AnalyzeDocumentResponse, type: string): any {
    const blocks = result.Blocks || [];
    const keyValues = this.extractKeyValuePairs(blocks);

    switch (type) {
      case 'BOL':
        return {
          bolNumber: keyValues['BOL#'] || keyValues['BOL Number'],
          shipper: keyValues['Shipper'] || keyValues['From'],
          consignee: keyValues['Consignee'] || keyValues['To'],
          weight: this.parseWeight(keyValues['Weight']),
          pieces: this.parseNumber(keyValues['Pieces']),
          date: this.parseDate(keyValues['Date'])
        };

      case 'RECEIPT':
        return {
          vendor: keyValues['Vendor'] || keyValues['Merchant'],
          amount: this.parseAmount(keyValues['Total'] || keyValues['Amount']),
          date: this.parseDate(keyValues['Date']),
          category: this.categorizeExpense(keyValues)
        };

      case 'FUEL_RECEIPT':
        return {
          station: keyValues['Station'] || keyValues['Location'],
          gallons: this.parseNumber(keyValues['Gallons']),
          pricePerGallon: this.parseAmount(keyValues['Price/Gal']),
          total: this.parseAmount(keyValues['Total']),
          date: this.parseDate(keyValues['Date'])
        };

      default:
        return keyValues;
    }
  }

  private extractKeyValuePairs(blocks: Block[]): Record<string, string> {
    const keyValues: Record<string, string> = {};
    
    // Implementation to extract key-value pairs from Textract blocks
    // This is simplified - actual implementation would be more complex
    
    return keyValues;
  }
}
```

**Mobile Implementation**:

```tsx
// apps/mobile/src/components/DocumentScanner.tsx

export function DocumentScanner({ type, onCapture }: DocumentScannerProps) {
  const [hasPermission, setHasPermission] = useState(false);
  const [scanning, setScanning] = useState(false);
  const camera = useRef<Camera>(null);

  const takePicture = async () => {
    if (!camera.current) return;

    setScanning(true);
    
    const photo = await camera.current.takePictureAsync({
      quality: 0.8,
      base64: true
    });

    // Auto-crop and enhance
    const processed = await processImage(photo.base64);
    
    // Upload and process
    const document = await uploadDocument(processed, type);
    
    setScanning(false);
    onCapture(document);
  };

  return (
    <View style={styles.container}>
      <Camera
        ref={camera}
        style={styles.camera}
        type={CameraType.back}
      >
        <View style={styles.overlay}>
          {/* Document frame guide */}
          <View style={styles.frame} />
          
          {/* Capture button */}
          <TouchableOpacity
            style={styles.captureButton}
            onPress={takePicture}
            disabled={scanning}
          >
            {scanning ? (
              <ActivityIndicator size="large" color="white" />
            ) : (
              <Ionicons name="camera" size={40} color="white" />
            )}
          </TouchableOpacity>
          
          <Text style={styles.hint}>
            Position document within frame
          </Text>
        </View>
      </Camera>
    </View>
  );
}
```

---

### 3. Fuel Card Integration

**Description**: Direct integration with EFS, Comdata, and WEX fuel cards.

**Implementation**:

```typescript
// apps/api/src/services/fuel.service.ts

interface FuelCardProvider {
  name: string;
  getTransactions(cardNumber: string, startDate: Date, endDate: Date): Promise<FuelTransaction[]>;
  getBalance(cardNumber: string): Promise<number>;
}

class EFSService implements FuelCardProvider {
  name = 'EFS';
  private apiUrl = 'https://api.efsllc.com/v1';

  async getTransactions(cardNumber: string, startDate: Date, endDate: Date): Promise<FuelTransaction[]> {
    const response = await fetch(`${this.apiUrl}/transactions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.EFS_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        cardNumber,
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString()
      })
    });

    const data = await response.json();
    return data.transactions.map(this.mapTransaction);
  }

  private mapTransaction(raw: any): FuelTransaction {
    return {
      id: raw.transactionId,
      date: new Date(raw.transactionDate),
      location: raw.merchantName,
      city: raw.merchantCity,
      state: raw.merchantState,
      gallons: raw.gallons,
      pricePerGallon: raw.pricePerGallon,
      total: raw.totalAmount,
      product: raw.productType
    };
  }
}

export class FuelService {
  private providers: Map<string, FuelCardProvider> = new Map([
    ['efs', new EFSService()],
    ['comdata', new ComdataService()],
    ['wex', new WEXService()]
  ]);

  async syncTransactions(userId: string): Promise<void> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { fuelCards: true }
    });

    for (const card of user.fuelCards) {
      const provider = this.providers.get(card.provider);
      if (!provider) continue;

      const lastSync = card.lastSync || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      
      const transactions = await provider.getTransactions(
        card.cardNumber,
        lastSync,
        new Date()
      );

      // Store transactions
      for (const tx of transactions) {
        await prisma.fuelTransaction.upsert({
          where: { externalId: tx.id },
          create: {
            externalId: tx.id,
            userId,
            fuelCardId: card.id,
            ...tx
          },
          update: tx
        });
      }

      // Update last sync
      await prisma.fuelCard.update({
        where: { id: card.id },
        data: { lastSync: new Date() }
      });
    }
  }

  async getFuelAnalytics(userId: string, period: string): Promise<FuelAnalytics> {
    const startDate = getPeriodStart(period);
    
    const transactions = await prisma.fuelTransaction.findMany({
      where: {
        userId,
        date: { gte: startDate }
      }
    });

    const totalGallons = transactions.reduce((sum, t) => sum + t.gallons, 0);
    const totalCost = transactions.reduce((sum, t) => sum + t.total, 0);
    const avgPricePerGallon = totalCost / totalGallons;

    // Calculate MPG if we have mileage data
    const mileage = await this.getMileage(userId, startDate);
    const mpg = mileage > 0 ? mileage / totalGallons : 0;

    return {
      totalGallons,
      totalCost,
      avgPricePerGallon,
      transactionCount: transactions.length,
      mpg,
      costPerMile: mileage > 0 ? totalCost / mileage : 0
    };
  }
}
```

---

## Q2 2025 (April - June)

### 4. Freight Marketplace

**Description**: Direct shipper-carrier matching platform.

**Key Features**:
- Shipper posts loads
- Carriers bid on loads
- AI-powered matching
- Escrow payments
- Rating system

**Revenue Model**:
- 3% transaction fee from shipper
- 2% transaction fee from carrier
- Premium listings: $25/load

---

### 5. Predictive Maintenance

**Description**: AI alerts for vehicle maintenance needs.

**Data Sources**:
- OBD-II telematics
- Historical maintenance records
- Manufacturer recommendations
- Weather conditions

**Alerts**:
- Oil change due
- Tire replacement needed
- Brake pad wear
- Engine diagnostics

---

### 6. Multi-Language Support

**Languages**: Spanish, Polish (top driver demographics)

**Implementation**:

```typescript
// apps/web/i18n/config.ts

import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

import en from './locales/en.json';
import es from './locales/es.json';
import pl from './locales/pl.json';

i18n
  .use(initReactI18next)
  .init({
    resources: {
      en: { translation: en },
      es: { translation: es },
      pl: { translation: pl }
    },
    lng: 'en',
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
```

---

## Q3 2025 (July - September)

### 7. ELD Integration

**Integrated Providers**:
- Samsara
- KeepTruckin
- Geotab
- Omnitracs

### 8. Blockchain BOLs

**Technology**: Ethereum or Polygon
**Use Case**: Immutable proof of delivery

### 9. API Marketplace

**Third-party integrations**:
- Accounting (QuickBooks, Xero)
- TMS (McLeod, TMW)
- Load boards (DAT, Truckstop)

---

## Success Metrics

| Quarter | Feature | Adoption Target |
|---------|---------|-----------------|
| Q1 | Real-Time ETA | 70% of active shipments |
| Q1 | Document OCR | 50% of documents scanned |
| Q1 | Fuel Integration | 30% of users connected |
| Q2 | Freight Marketplace | 100 loads posted/month |
| Q2 | Predictive Maintenance | 25% reduction in breakdowns |
| Q3 | ELD Integration | 5 providers integrated |
| Q3 | API Marketplace | 10 apps published |

---

*Document Owner: Product Team*  
*Last Updated: February 24, 2025*
