# Financial Model

## 3-Year Projections

---

## Assumptions

### Growth Assumptions

| Metric | Year 1 | Year 2 | Year 3 |
|--------|--------|--------|--------|
| Monthly Growth Rate | 20% | 15% | 10% |
| Customer Churn | 6% | 4% | 3% |
| Net Revenue Retention | 120% | 115% | 110% |

### Unit Economics

| Metric | Value |
|--------|-------|
| ARPU (Average Revenue Per User) | $150/month |
| CAC (Customer Acquisition Cost) | $85 → $50 (at scale) |
| LTV (Lifetime Value) | $2,700 |
| LTV/CAC Ratio | 32x |
| Gross Margin | 75% → 80% |

---

## Revenue Projections

### Monthly Recurring Revenue (MRR)

| Month | New Customers | Churned | Net Customers | MRR | Growth |
|-------|---------------|---------|---------------|-----|--------|
| Jan 2025 | 100 | 80 | 1,356 | $52,000 | - |
| Feb 2025 | 120 | 81 | 1,395 | $54,600 | 5% |
| Mar 2025 | 144 | 84 | 1,455 | $57,330 | 5% |
| Apr 2025 | 173 | 87 | 1,541 | $60,197 | 5% |
| May 2025 | 207 | 92 | 1,656 | $63,207 | 5% |
| Jun 2025 | 249 | 99 | 1,806 | $66,367 | 5% |
| Jul 2025 | 298 | 108 | 1,996 | $69,685 | 5% |
| Aug 2025 | 358 | 120 | 2,234 | $73,170 | 5% |
| Sep 2025 | 430 | 134 | 2,530 | $76,828 | 5% |
| Oct 2025 | 516 | 152 | 2,894 | $80,670 | 5% |
| Nov 2025 | 619 | 174 | 3,339 | $84,703 | 5% |
| Dec 2025 | 743 | 200 | 3,882 | $88,938 | 5% |
| **Year 1 Total** | **3,977** | **1,411** | **3,882** | **$1,067,125** | **-** |

### Annual Recurring Revenue (ARR)

| Year | Start ARR | End ARR | Growth |
|------|-----------|---------|--------|
| 2024 (Actual) | - | $624,000 | - |
| 2025 (Proj) | $624,000 | $7,680,000 | 1,130% |
| 2026 (Proj) | $7,680,000 | $14,400,000 | 88% |
| 2027 (Proj) | $14,400,000 | $25,200,000 | 75% |

---

## Revenue by Stream

### Year 1 (2025)

| Stream | Q1 | Q2 | Q3 | Q4 | Total |
|--------|-----|-----|-----|-----|-------|
| SaaS Subscriptions | $150K | $180K | $220K | $270K | $820K |
| Per-Shipment Fees | $15K | $35K | $60K | $90K | $200K |
| Factoring Revenue | $6K | $20K | $40K | $65K | $131K |
| Insurance Commissions | $0 | $5K | $15K | $30K | $50K |
| **Total Revenue** | **$171K** | **$240K** | **$335K** | **$455K** | **$1,201K** |

### Year 2 (2026)

| Stream | Q1 | Q2 | Q3 | Q4 | Total |
|--------|-----|-----|-----|-----|-------|
| SaaS Subscriptions | $300K | $360K | $430K | $520K | $1,610K |
| Per-Shipment Fees | $110K | $150K | $200K | $260K | $720K |
| Factoring Revenue | $80K | $110K | $150K | $200K | $540K |
| Insurance Commissions | $40K | $55K | $75K | $100K | $270K |
| **Total Revenue** | **$530K** | **$675K** | **$855K** | **$1,080K** | **$3,140K** |

### Year 3 (2027)

| Stream | Q1 | Q2 | Q3 | Q4 | Total |
|--------|-----|-----|-----|-----|-------|
| SaaS Subscriptions | $600K | $700K | $820K | $960K | $3,080K |
| Per-Shipment Fees | $300K | $360K | $430K | $520K | $1,610K |
| Factoring Revenue | $220K | $270K | $330K | $400K | $1,220K |
| Insurance Commissions | $120K | $150K | $190K | $240K | $700K |
| **Total Revenue** | **$1,240K** | **$1,480K** | **$1,770K** | **$2,120K** | **$6,610K** |

---

## Expense Projections

### Operating Expenses

| Category | Year 1 | Year 2 | Year 3 |
|----------|--------|--------|--------|
| **Personnel** | | | |
| Engineering (8 FTE) | $960K | $1,200K | $1,440K |
| Sales (5 FTE) | $450K | $600K | $750K |
| Marketing (2 FTE) | $180K | $240K | $300K |
| Customer Success (3 FTE) | $270K | $360K | $450K |
| G&A (2 FTE) | $180K | $240K | $300K |
| **Subtotal Personnel** | **$2,040K** | **$2,640K** | **$3,240K** |
| | | | |
| **Marketing Spend** | $360K | $600K | $900K |
| **Infrastructure** | $120K | $180K | $250K |
| **Tools & Software** | $60K | $80K | $100K |
| **Legal & Professional** | $50K | $75K | $100K |
| **Other** | $50K | $75K | $100K |
| **Total OpEx** | **$2,680K** | **$3,650K** | **$4,690K** |

### Gross Margin Calculation

| Year | Revenue | COGS | Gross Profit | Gross Margin |
|------|---------|------|--------------|--------------|
| 2025 | $1,201K | $300K | $901K | 75% |
| 2026 | $3,140K | $628K | $2,512K | 80% |
| 2027 | $6,610K | $1,322K | $5,288K | 80% |

---

## Profitability Projections

### Income Statement

| Line Item | Year 1 | Year 2 | Year 3 |
|-----------|--------|--------|--------|
| Revenue | $1,201K | $3,140K | $6,610K |
| COGS | ($300K) | ($628K) | ($1,322K) |
| **Gross Profit** | **$901K** | **$2,512K** | **$5,288K** |
| | | | |
| Operating Expenses | ($2,680K) | ($3,650K) | ($4,690K) |
| **Operating Income (EBIT)** | **($1,779K)** | **($1,138K)** | **$598K** |
| | | | |
| Interest & Other | ($50K) | ($75K) | ($100K) |
| Taxes | $0 | $0 | ($150K) |
| **Net Income** | **($1,829K)** | **($1,213K)** | **$348K** |

### Cash Flow

| Item | Year 1 | Year 2 | Year 3 |
|------|--------|--------|--------|
| Starting Cash | $500K | $4,171K | $5,358K |
| Net Income | ($1,829K) | ($1,213K) | $348K |
| Add: Depreciation | $20K | $30K | $40K |
| Less: CapEx | ($100K) | ($150K) | ($200K) |
| **Cash from Operations** | **($1,909K)** | **($1,333K)** | **$188K** |
| | | | |
| Financing (Series A) | $5,580K | $0 | $0 |
| **Ending Cash** | **$4,171K** | **$5,358K** | **$5,546K** |

---

## Key Metrics Dashboard

### Monthly Tracking

```typescript
interface FinancialMetrics {
  // Revenue
  mrr: number;
  arr: number;
  revenueGrowth: number; // MoM %
  
  // Customers
  totalCustomers: number;
  newCustomers: number;
  churnedCustomers: number;
  netRevenueRetention: number;
  
  // Unit Economics
  arpu: number;
  cac: number;
  ltv: number;
  ltvCacRatio: number;
  paybackPeriod: number; // months
  
  // Efficiency
  grossMargin: number;
  burnRate: number;
  runway: number; // months
}

const TARGETS = {
  mrr: 640000,        // $640K MRR by end of Year 1
  arr: 7680000,       // $7.68M ARR by end of Year 1
  revenueGrowth: 0.20, // 20% MoM
  churn: 0.03,        // 3% monthly
  nrr: 1.20,          // 120% NRR
  ltvCacRatio: 30,    // 30x LTV/CAC
  grossMargin: 0.80   // 80% gross margin
};
```

---

## Sensitivity Analysis

### Best Case (+20% performance)

| Metric | Base | Best Case |
|--------|------|-----------|
| Year 1 Revenue | $1.2M | $1.44M |
| Year 2 Revenue | $3.14M | $3.77M |
| Year 3 Revenue | $6.61M | $7.93M |
| Year 3 Net Income | $348K | $1.2M |

### Worst Case (-20% performance)

| Metric | Base | Worst Case |
|--------|------|------------|
| Year 1 Revenue | $1.2M | $960K |
| Year 2 Revenue | $3.14M | $2.51M |
| Year 3 Revenue | $6.61M | $5.29M |
| Year 3 Net Income | $348K | ($400K) |

---

*Document Owner: Finance Team*  
*Last Updated: February 24, 2025*
