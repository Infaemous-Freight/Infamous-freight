# Technical Architecture Improvements

## Performance & Scalability Enhancements

---

## 1. Redis Caching Layer

### Implementation

```typescript
// apps/api/src/config/redis.ts

import Redis from 'ioredis';

export const redis = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  password: process.env.REDIS_PASSWORD,
  retryStrategy: (times) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  maxRetriesPerRequest: 3
});

// Cache key patterns
export const CACHE_KEYS = {
  user: (id: string) => `user:${id}`,
  shipment: (id: string) => `shipment:${id}`,
  shipmentsList: (orgId: string, page: number) => `shipments:${orgId}:${page}`,
  driver: (id: string) => `driver:${id}`,
  driversList: (orgId: string) => `drivers:${orgId}`,
  analytics: (orgId: string, period: string) => `analytics:${orgId}:${period}`,
  aiResponse: (hash: string) => `ai:${hash}`,
  rateLimit: (key: string) => `ratelimit:${key}`
} as const;

// Cache TTLs (in seconds)
export const CACHE_TTL = {
  USER: 3600,           // 1 hour
  SHIPMENT: 300,        // 5 minutes
  SHIPMENTS_LIST: 60,   // 1 minute
  DRIVER: 1800,         // 30 minutes
  ANALYTICS: 300,       // 5 minutes
  AI_RESPONSE: 86400,   // 24 hours
  RATE_LIMIT: 60        // 1 minute
} as const;
```

```typescript
// apps/api/src/services/cache.service.ts

export class CacheService {
  async get<T>(key: string): Promise<T | null> {
    const data = await redis.get(key);
    return data ? JSON.parse(data) : null;
  }

  async set(key: string, value: any, ttl: number): Promise<void> {
    await redis.setex(key, ttl, JSON.stringify(value));
  }

  async delete(key: string): Promise<void> {
    await redis.del(key);
  }

  async deletePattern(pattern: string): Promise<void> {
    const keys = await redis.keys(pattern);
    if (keys.length > 0) {
      await redis.del(...keys);
    }
  }

  // Cache-aside pattern wrapper
  async getOrSet<T>(
    key: string,
    factory: () => Promise<T>,
    ttl: number
  ): Promise<T> {
    const cached = await this.get<T>(key);
    if (cached) return cached;

    const data = await factory();
    await this.set(key, data, ttl);
    return data;
  }

  // Invalidate cache on data changes
  async invalidateShipment(shipmentId: string): Promise<void> {
    await this.delete(CACHE_KEYS.shipment(shipmentId));
    // Invalidate list caches
    await this.deletePattern('shipments:*');
  }
}

export const cacheService = new CacheService();
```

### Usage in API Routes

```typescript
// apps/api/src/routes/shipments.ts

router.get('/', async (req, res) => {
  const { organizationId } = req.user;
  const { page = 1, limit = 20 } = req.query;
  
  const cacheKey = CACHE_KEYS.shipmentsList(organizationId, Number(page));
  
  const shipments = await cacheService.getOrSet(
    cacheKey,
    async () => {
      return prisma.shipment.findMany({
        where: { organizationId },
        skip: (Number(page) - 1) * Number(limit),
        take: Number(limit),
        orderBy: { createdAt: 'desc' }
      });
    },
    CACHE_TTL.SHIPMENTS_LIST
  );
  
  res.json(shipments);
});

router.post('/', async (req, res) => {
  const shipment = await prisma.shipment.create({
    data: req.body
  });
  
  // Invalidate cache
  await cacheService.invalidateShipment(shipment.id);
  
  res.status(201).json(shipment);
});
```

### Expected Impact
- **API Response Time**: P95 < 1s → P95 < 200ms
- **Database Load**: -60% read queries
- **Cost Savings**: -$500/month on database scaling

---

## 2. GraphQL API Layer

### Schema Definition

```typescript
// apps/api/src/graphql/schema.ts

export const typeDefs = gql`
  type Query {
    me: User
    organization(id: ID!): Organization
    shipments(
      organizationId: ID!
      status: ShipmentStatus
      limit: Int = 20
      offset: Int = 0
    ): ShipmentConnection
    shipment(id: ID!): Shipment
    drivers(organizationId: ID!): [Driver!]!
    analytics(organizationId: ID!, period: String!): Analytics
  }

  type Mutation {
    createShipment(input: CreateShipmentInput!): Shipment
    updateShipment(id: ID!, input: UpdateShipmentInput!): Shipment
    deleteShipment(id: ID!): Boolean
    createInvoice(input: CreateInvoiceInput!): Invoice
  }

  type Subscription {
    shipmentUpdated(organizationId: ID!): Shipment
    trackingEvent(shipmentId: ID!): TrackingEvent
  }

  type Shipment {
    id: ID!
    bolNumber: String!
    shipper: Shipper!
    consignee: Consignee!
    status: ShipmentStatus!
    driver: Driver
    vehicle: Vehicle
    pickup: Location!
    delivery: Location!
    rate: Float!
    distance: Float!
    trackingEvents: [TrackingEvent!]!
    createdAt: DateTime!
    updatedAt: DateTime!
  }

  type ShipmentConnection {
    edges: [ShipmentEdge!]!
    pageInfo: PageInfo!
    totalCount: Int!
  }

  type ShipmentEdge {
    node: Shipment!
    cursor: String!
  }

  type PageInfo {
    hasNextPage: Boolean!
    hasPreviousPage: Boolean!
    startCursor: String
    endCursor: String
  }

  enum ShipmentStatus {
    PENDING
    ASSIGNED
    IN_TRANSIT
    DELIVERED
    CANCELLED
  }

  input CreateShipmentInput {
    bolNumber: String!
    shipperName: String!
    shipperAddress: String!
    consigneeName: String!
    consigneeAddress: String!
    pickupDate: DateTime!
    deliveryDate: DateTime!
    weight: Float!
    rate: Float!
  }
`;
```

### Resolvers

```typescript
// apps/api/src/graphql/resolvers.ts

export const resolvers = {
  Query: {
    me: async (_, __, { user }) => {
      return cacheService.getOrSet(
        CACHE_KEYS.user(user.id),
        () => prisma.user.findUnique({ where: { id: user.id } }),
        CACHE_TTL.USER
      );
    },

    shipments: async (_, { organizationId, status, limit, offset }, { user }) => {
      // Verify access
      if (user.organizationId !== organizationId) {
        throw new AuthenticationError('Not authorized');
      }

      const where: any = { organizationId };
      if (status) where.status = status;

      const [shipments, totalCount] = await Promise.all([
        prisma.shipment.findMany({
          where,
          skip: offset,
          take: limit,
          orderBy: { createdAt: 'desc' },
          include: {
            driver: true,
            vehicle: true,
            trackingEvents: { orderBy: { createdAt: 'desc' }, take: 5 }
          }
        }),
        prisma.shipment.count({ where })
      ]);

      return {
        edges: shipments.map(shipment => ({
          node: shipment,
          cursor: Buffer.from(shipment.id).toString('base64')
        })),
        pageInfo: {
          hasNextPage: offset + limit < totalCount,
          hasPreviousPage: offset > 0,
          startCursor: shipments[0] ? Buffer.from(shipments[0].id).toString('base64') : null,
          endCursor: shipments[shipments.length - 1] ? Buffer.from(shipments[shipments.length - 1].id).toString('base64') : null
        },
        totalCount
      };
    },

    analytics: async (_, { organizationId, period }, { user }) => {
      const cacheKey = CACHE_KEYS.analytics(organizationId, period);
      
      return cacheService.getOrSet(
        cacheKey,
        async () => {
          const startDate = getPeriodStart(period);
          
          const [
            totalRevenue,
            shipmentCount,
            activeDrivers,
            onTimeDelivery
          ] = await Promise.all([
            prisma.invoice.aggregate({
              where: {
                organizationId,
                status: 'PAID',
                paidAt: { gte: startDate }
              },
              _sum: { amount: true }
            }),
            prisma.shipment.count({
              where: {
                organizationId,
                createdAt: { gte: startDate }
              }
            }),
            prisma.driver.count({
              where: {
                organizationId,
                status: { in: ['AVAILABLE', 'ON_DUTY'] }
              }
            }),
            prisma.shipment.count({
              where: {
                organizationId,
                status: 'DELIVERED',
                deliveryDate: { lte: prisma.shipment.fields.estimatedDeliveryDate },
                createdAt: { gte: startDate }
              }
            })
          ]);

          return {
            totalRevenue: totalRevenue._sum.amount || 0,
            shipmentCount,
            activeDrivers,
            onTimeDelivery,
            period
          };
        },
        CACHE_TTL.ANALYTICS
      );
    }
  },

  Mutation: {
    createShipment: async (_, { input }, { user }) => {
      const shipment = await prisma.shipment.create({
        data: {
          ...input,
          organizationId: user.organizationId
        }
      });

      // Invalidate cache
      await cacheService.deletePattern(`shipments:${user.organizationId}:*`);

      // Publish subscription event
      pubsub.publish('SHIPMENT_CREATED', {
        shipmentUpdated: shipment,
        organizationId: user.organizationId
      });

      return shipment;
    }
  },

  Subscription: {
    shipmentUpdated: {
      subscribe: (_, { organizationId }) => {
        return pubsub.asyncIterator(`SHIPMENT_UPDATED:${organizationId}`);
      }
    },
    
    trackingEvent: {
      subscribe: (_, { shipmentId }) => {
        return pubsub.asyncIterator(`TRACKING_EVENT:${shipmentId}`);
      }
    }
  }
};
```

### Apollo Server Setup

```typescript
// apps/api/src/graphql/server.ts

import { ApolloServer } from '@apollo/server';
import { expressMiddleware } from '@apollo/server/express4';
import { WebSocketServer } from 'ws';
import { useServer } from 'graphql-ws/lib/use/ws';

const server = new ApolloServer({
  typeDefs,
  resolvers,
  introspection: process.env.NODE_ENV !== 'production',
  plugins: [
    {
      async serverWillStart() {
        return {
          async drainServer() {
            subscriptionServer.close();
          }
        };
      }
    }
  ]
});

await server.start();

app.use('/graphql', 
  expressMiddleware(server, {
    context: async ({ req }) => {
      const token = req.headers.authorization?.replace('Bearer ', '');
      const user = await verifyToken(token);
      return { user };
    }
  })
);

// WebSocket server for subscriptions
const wsServer = new WebSocketServer({
  server: httpServer,
  path: '/graphql'
});

const subscriptionServer = useServer(
  { schema: makeExecutableSchema({ typeDefs, resolvers }) },
  wsServer
);
```

---

## 3. Database Optimization

### Index Strategy

```sql
-- Critical indexes for performance

-- Shipment queries (most frequent)
CREATE INDEX CONCURRENTLY idx_shipments_org_status_created 
  ON "Shipment"(organization_id, status, created_at DESC);

CREATE INDEX CONCURRENTLY idx_shipments_driver_status 
  ON "Shipment"(driver_id, status) 
  WHERE status IN ('ASSIGNED', 'IN_TRANSIT');

CREATE INDEX CONCURRENTLY idx_shipments_pickup_location 
  ON "Shipment" USING GIST (
    ll_to_earth(pickup_latitude, pickup_longitude)
  );

-- Tracking events (high write volume)
CREATE INDEX CONCURRENTLY idx_tracking_events_shipment_created 
  ON "TrackingEvent"(shipment_id, created_at DESC);

-- Driver availability
CREATE INDEX CONCURRENTLY idx_drivers_org_status 
  ON "Driver"(organization_id, status) 
  WHERE status IN ('AVAILABLE', 'ON_DUTY');

-- Invoice queries
CREATE INDEX CONCURRENTLY idx_invoices_org_status_due 
  ON "Invoice"(organization_id, status, due_date);

-- User activity
CREATE INDEX CONCURRENTLY idx_activity_logs_user_created 
  ON "ActivityLog"(user_id, created_at DESC);

-- AI events (for analytics)
CREATE INDEX CONCURRENTLY idx_ai_events_org_created 
  ON "AiEvent"(organization_id, created_at DESC);
```

### Query Optimization

```typescript
// Before: N+1 query problem
const shipments = await prisma.shipment.findMany();
for (const shipment of shipments) {
  shipment.driver = await prisma.driver.findUnique({
    where: { id: shipment.driverId }
  });
}

// After: Single query with includes
const shipments = await prisma.shipment.findMany({
  include: {
    driver: true,
    vehicle: true,
    trackingEvents: {
      orderBy: { createdAt: 'desc' },
      take: 5
    }
  }
});
```

### Connection Pooling

```typescript
// apps/api/src/config/database.ts

import { PrismaClient } from '@prisma/client';

export const prisma = new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['query', 'error'] : ['error'],
  datasources: {
    db: {
      url: process.env.DATABASE_URL
    }
  }
});

// Connection pool settings (in connection string)
// postgresql://user:pass@host:5432/db?connection_limit=20&pool_timeout=30
```

---

## 4. Mobile Performance

### Offline-First Architecture

```typescript
// apps/mobile/src/services/sync.service.ts

import AsyncStorage from '@react-native-async-storage/async-storage';
import NetInfo from '@react-native-community/netinfo';

export class SyncService {
  private syncQueue: SyncOperation[] = [];

  async queueOperation(operation: SyncOperation): Promise<void> {
    // Store locally first
    await this.storeLocally(operation);
    
    // Add to sync queue
    this.syncQueue.push(operation);
    
    // Try to sync immediately if online
    const netInfo = await NetInfo.fetch();
    if (netInfo.isConnected) {
      await this.sync();
    }
  }

  async sync(): Promise<void> {
    if (this.syncQueue.length === 0) return;

    const operations = [...this.syncQueue];
    this.syncQueue = [];

    for (const operation of operations) {
      try {
        await this.executeOperation(operation);
        await this.removeFromLocalStorage(operation.id);
      } catch (error) {
        // Re-queue failed operations
        this.syncQueue.push(operation);
        console.error('Sync failed:', error);
      }
    }
  }

  private async storeLocally(operation: SyncOperation): Promise<void> {
    const key = `sync:${operation.type}:${operation.id}`;
    await AsyncStorage.setItem(key, JSON.stringify(operation));
  }

  private async executeOperation(operation: SyncOperation): Promise<void> {
    switch (operation.type) {
      case 'CREATE_SHIPMENT':
        await api.shipments.create(operation.data);
        break;
      case 'UPDATE_HOS':
        await api.hos.update(operation.data);
        break;
      case 'ADD_TRACKING_EVENT':
        await api.tracking.addEvent(operation.data);
        break;
    }
  }
}

export const syncService = new SyncService();
```

### App Size Optimization

```javascript
// app.json
{
  "expo": {
    "name": "Infamous Freight",
    "slug": "infamous-freight-mobile",
    "version": "2.2.0",
    "orientation": "portrait",
    "icon": "./assets/icon.png",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain"
    },
    "assetBundlePatterns": [
      "**/*"
    ],
    "ios": {
      "supportsTablet": true,
      "bundleIdentifier": "com.infamousfreight.mobile"
    },
    "android": {
      "package": "com.infamousfreight.mobile",
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#2563EB"
      }
    },
    "web": {
      "favicon": "./assets/favicon.png"
    },
    "plugins": [
      [
        "expo-image-picker",
        {
          "photosPermission": "Allow access to photos for document uploads"
        }
      ]
    ]
  }
}
```

```javascript
// metro.config.js
const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Tree shaking for smaller bundles
config.transformer.minifierConfig = {
  keep_classnames: false,
  keep_fnames: false,
  mangle: true,
  compress: {
    drop_console: true,
    drop_debugger: true
  }
};

// Exclude unused modules
config.resolver.blockList = [
  /node_modules\/lodash\/fp/,
  /node_modules\/moment\/locale\/(?!en)/
];

module.exports = config;
```

---

## 5. CDN & Static Assets

### Cloudflare Configuration

```yaml
# cloudflare-config.yaml

# Page Rules
page_rules:
  - url: "*infamousfreight.com/static/*"
    settings:
      cache_level: cache_everything
      edge_cache_ttl: 2592000  # 30 days
      browser_cache_ttl: 86400  # 1 day

  - url: "*infamousfreight.com/api/*"
    settings:
      cache_level: bypass

# Caching Rules
caching:
  browser_cache_ttl: 14400  # 4 hours
  edge_cache_ttl: 7200      # 2 hours
  always_online: on
  development_mode: off

# Performance
performance:
  minify:
    css: on
    js: on
    html: on
  brotli: on
  image_optimization: on
  early_hints: on
```

### Next.js Image Optimization

```typescript
// apps/web/next.config.js

module.exports = {
  images: {
    domains: ['cdn.infamousfreight.com', 'images.unsplash.com'],
    formats: ['image/webp', 'image/avif'],
    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384]
  },
  
  // Enable static optimization
  output: 'standalone',
  
  // Compression
  compress: true,
  
  // Experimental features
  experimental: {
    optimizePackageImports: ['@chakra-ui/react', 'lodash']
  }
};
```

---

## Expected Performance Improvements

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| API P95 Response | 1,000ms | 200ms | **5x faster** |
| Database Read QPS | 10,000 | 4,000 | **-60%** |
| Mobile App Size | 45MB | 25MB | **-44%** |
| Page Load Time | 3.5s | 1.2s | **-66%** |
| Cache Hit Rate | 0% | 75% | **+75%** |
| CDN Cache Hit | N/A | 90% | **90%** |

---

*Document Owner: Engineering Team*  
*Last Updated: February 24, 2025*
