import { Router } from 'express';
import { authMiddleware, type AuthedRequest } from '../security/auth-middleware';
import { aiCommandSchema } from '@infamous/shared';
import { runAiCommand } from '../services/ai';
import { auditLog } from '../audit';

export const aiRouter = Router();

aiRouter.post('/command', authMiddleware, async (req: AuthedRequest, res) => {
  const parsed = aiCommandSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'INVALID_INPUT', details: parsed.error.flatten() });

  const result = await runAiCommand(parsed.data.command);

  await auditLog({
    organizationId: req.user!.orgId,
    actorUserId: req.user!.userId,
    action: 'AI_COMMAND',
    entityType: 'AI',
    metadata: { command: parsed.data.command },
  });

  return res.json(result);
});
