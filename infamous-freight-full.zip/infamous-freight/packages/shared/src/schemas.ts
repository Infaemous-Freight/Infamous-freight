import { z } from 'zod';

export const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  organizationName: z.string().min(2),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

export const createShipmentSchema = z.object({
  origin: z.string().min(2),
  destination: z.string().min(2),
  price: z.number().positive(),
});

export const updateShipmentStatusSchema = z.object({
  status: z.enum(['PENDING', 'IN_TRANSIT', 'DELIVERED']),
});

export const aiCommandSchema = z.object({
  command: z.string().min(2),
});

export const stripeCheckoutSchema = z.object({
  amountUsdCents: z.number().int().positive().max(5_000_000),
  description: z.string().min(2).max(120),
});
